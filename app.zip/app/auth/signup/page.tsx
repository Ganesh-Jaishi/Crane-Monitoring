"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { VideoBackground } from "@/components/auth/video-background"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useToast } from "@/components/ui/use-toast"
import { useAuth } from "@/contexts/auth-context"
import { Icons } from "@/components/icons"
import { Separator } from "@/components/ui/separator"
import { Checkbox } from "@/components/ui/checkbox"

export default function SignUpPage() {
  const router = useRouter()
  const { toast } = useToast()
  const { signUp, signInWithGoogle } = useAuth()
  const [isLoading, setIsLoading] = useState(false)
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [fullName, setFullName] = useState("")
  const [phoneNumber, setPhoneNumber] = useState("")
  const [passwordError, setPasswordError] = useState("")
  const [acceptTerms, setAcceptTerms] = useState(false)

  async function onSubmit(event: React.FormEvent) {
    event.preventDefault()
    setPasswordError("")
    setIsLoading(true)

    if (!fullName) {
      toast({
        variant: "destructive",
        title: "Full name required",
        description: "Please enter your full name.",
      })
      setIsLoading(false)
      return
    }

    if (password !== confirmPassword) {
      setPasswordError("Passwords do not match")
      setIsLoading(false)
      return
    }

    if (password.length < 8) {
      setPasswordError("Password must be at least 8 characters long")
      setIsLoading(false)
      return
    }

    if (!acceptTerms) {
      toast({
        variant: "destructive",
        title: "Terms & Conditions",
        description: "Please accept the terms and conditions to continue.",
      })
      setIsLoading(false)
      return
    }

    try {
      await signUp(email, password, { fullName, phone: phoneNumber })
      router.push("/crane-selection")
    } catch (error) {
      toast({
        title: "Error",
        description: "Something went wrong. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleGoogleSignIn = async () => {
    if (!acceptTerms) {
      toast({
        variant: "destructive",
        title: "Terms & Conditions",
        description: "Please accept the terms and conditions to continue.",
      })
      return
    }

    try {
      await signInWithGoogle()
      router.push("/crane-selection")
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to sign in with Google",
        variant: "destructive",
      })
    }
  }

  return (
    <div className="container relative min-h-screen flex-col items-center justify-center md:grid lg:max-w-none lg:grid-cols-2 lg:px-0">
      <div className="relative h-full flex-col bg-muted text-white lg:block">
        <VideoBackground />
      </div>
      <div className="flex min-h-screen items-center justify-center lg:p-8">
        <div className="w-full max-w-md space-y-6 bg-background/95 px-8 py-12 shadow-lg backdrop-blur-sm rounded-lg">
          <div className="space-y-2 text-center">
            <h2 className="text-3xl font-bold">Create an Account</h2>
            <p className="text-muted-foreground">
              Enter your information to get started
            </p>
          </div>

          <form onSubmit={onSubmit} className="space-y-5">
            <div className="space-y-2">
              <Label htmlFor="fullName">Full Name</Label>
              <Input
                id="fullName"
                placeholder="John Doe"
                type="text"
                autoCapitalize="none"
                autoComplete="name"
                autoCorrect="off"
                disabled={isLoading}
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                className="h-11"
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                placeholder="name@example.com"
                type="email"
                autoCapitalize="none"
                autoComplete="email"
                autoCorrect="off"
                disabled={isLoading}
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="h-11"
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="phoneNumber">Phone Number <span className="text-xs text-muted-foreground">(optional)</span></Label>
              <Input
                id="phoneNumber"
                placeholder="+1 (555) 123-4567"
                type="tel"
                autoCapitalize="none"
                autoComplete="tel"
                disabled={isLoading}
                value={phoneNumber}
                onChange={(e) => setPhoneNumber(e.target.value)}
                className="h-11"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="password">Create Password</Label>
              <Input
                id="password"
                type="password"
                autoCapitalize="none"
                autoComplete="new-password"
                disabled={isLoading}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="h-11"
                required
                minLength={8}
                placeholder="At least 8 characters"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="confirmPassword">Confirm Password</Label>
              <Input
                id="confirmPassword"
                type="password"
                autoCapitalize="none"
                autoComplete="new-password"
                disabled={isLoading}
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className="h-11"
                required
                placeholder="Re-enter your password"
              />
              {passwordError && (
                <p className="text-sm text-red-500 mt-1">{passwordError}</p>
              )}
            </div>

            <div className="flex items-center space-x-2">
              <Checkbox
                id="terms"
                checked={acceptTerms}
                onCheckedChange={(checked) => setAcceptTerms(checked as boolean)}
              />
              <label
                htmlFor="terms"
                className="text-sm text-muted-foreground"
              >
                I accept the{" "}
                <Link href="/terms" className="text-primary hover:underline">
                  Terms of Service
                </Link>{" "}
                and{" "}
                <Link href="/privacy" className="text-primary hover:underline">
                  Privacy Policy
                </Link>
              </label>
            </div>

            <Button disabled={isLoading} className="w-full h-11">
              {isLoading && (
                <Icons.spinner className="mr-2 h-4 w-4 animate-spin" />
              )}
              Create Account
            </Button>
          </form>

          <div className="relative my-8">
            <div className="absolute inset-0 flex items-center">
              <Separator className="w-full" />
            </div>
            <div className="relative flex justify-center text-xs uppercase">
              <span className="bg-background px-2 text-muted-foreground">
                Or continue with
              </span>
            </div>
          </div>

          <Button
            variant="outline" 
            disabled={isLoading} 
            onClick={handleGoogleSignIn}
            className="w-full h-11"
          >
            {isLoading ? (
              <Icons.spinner className="mr-2 h-4 w-4 animate-spin" />
            ) : (
              <Icons.google className="mr-2 h-4 w-4" />
            )}{" "}
            Google
          </Button>

          <div className="mt-6 text-center text-sm text-muted-foreground">
            <Link 
              href="/auth/login"
              className="text-primary hover:underline cursor-pointer"
            >
              Already have an account? Sign In
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
} 