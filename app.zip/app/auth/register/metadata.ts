import { Metadata } from "next"

export const metadata: Metadata = {
  title: "Register | Crane Monitoring System",
  description: "Create a new account to access the crane monitoring system",
} 