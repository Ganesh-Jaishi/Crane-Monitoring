"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { createBrowserClient } from '@supabase/ssr'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Icons } from "@/components/icons"
import { useToast } from "@/components/ui/use-toast"
import Link from "next/link"
import { Separator } from "@/components/ui/separator"
import { VideoBackground } from "@/components/auth/video-background"

export default function RegisterPage() {
  const [isLoading, setIsLoading] = useState(false)
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [fullName, setFullName] = useState("")
  const [phoneNumber, setPhoneNumber] = useState("")
  const router = useRouter()
  const { toast } = useToast()

  const supabase = createBrowserClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  )

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault()
    
    // Form validation
    if (!fullName) {
      toast({
        variant: "destructive",
        title: "Full name required",
        description: "Please enter your full name.",
      })
      return
    }
    
    if (!email) {
      toast({
        variant: "destructive",
        title: "Email required",
        description: "Please enter your email address.",
      })
      return
    }
    
    if (!password) {
      toast({
        variant: "destructive",
        title: "Password required",
        description: "Please enter your password.",
      })
      return
    }
    
    setIsLoading(true)

    try {
      const { error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            full_name: fullName,
            phone_number: phoneNumber,
          },
        },
      })

      if (error) {
        toast({
          variant: "destructive",
          title: "Registration failed",
          description: error.message,
        })
        setIsLoading(false)
        return
      }

      router.push("/crane-selection")
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "An error occurred while creating your account.",
      })
    } finally {
      setIsLoading(false)
    }
  }

  async function signUpWithGoogle() {
    setIsLoading(true)
    
    try {
      const { error } = await supabase.auth.signInWithOAuth({
        provider: 'google',
        options: {
          redirectTo: `${window.location.origin}/auth/callback`,
        },
      })
      
      if (error) {
        toast({
          variant: "destructive",
          title: "Error",
          description: error.message,
        })
      }
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "An error occurred while signing up with Google.",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="container relative min-h-screen flex-col items-center justify-center md:grid lg:max-w-none lg:grid-cols-2 lg:px-0">
      <div className="relative hidden h-full flex-col bg-muted p-10 text-white dark:border-r lg:flex">
        <VideoBackground />
        <div className="relative z-20 flex items-center text-lg font-medium">
          <Link href="/">Crane Monitoring System</Link>
        </div>
        <div className="relative z-20 mt-auto">
          <blockquote className="space-y-2">
            <p className="text-lg">
              &ldquo;Join our platform to enhance your crane operations with cutting-edge monitoring solutions.&rdquo;
            </p>
          </blockquote>
        </div>
      </div>
      <div className="flex min-h-screen items-center justify-center">
        <div className="w-full max-w-md px-6 py-8 rounded-lg bg-background/80 backdrop-blur-sm">
          <div className="space-y-2 mb-8">
            <h2 className="text-3xl font-bold">Create an Account</h2>
            <p className="text-muted-foreground">
              Enter your information to get started
            </p>
          </div>

          <form onSubmit={onSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="fullName">Full Name</Label>
              <Input
                id="fullName"
                placeholder="John Doe"
                type="text"
                autoCapitalize="none"
                autoComplete="name"
                autoCorrect="off"
                disabled={isLoading}
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                className="h-11"
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                placeholder="name@example.com"
                type="email"
                autoCapitalize="none"
                autoComplete="email"
                autoCorrect="off"
                disabled={isLoading}
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="h-11"
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="phoneNumber">Phone Number <span className="text-xs text-muted-foreground">(optional)</span></Label>
              <Input
                id="phoneNumber"
                placeholder="+1 (555) 123-4567"
                type="tel"
                autoCapitalize="none"
                autoComplete="tel"
                disabled={isLoading}
                value={phoneNumber}
                onChange={(e) => setPhoneNumber(e.target.value)}
                className="h-11"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                autoCapitalize="none"
                autoComplete="new-password"
                disabled={isLoading}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="h-11"
                required
              />
            </div>

            <Button disabled={isLoading} className="w-full h-11">
              {isLoading && (
                <Icons.spinner className="mr-2 h-4 w-4 animate-spin" />
              )}
              Create Account
            </Button>
          </form>

          <div className="relative my-6">
            <div className="absolute inset-0 flex items-center">
              <Separator className="w-full" />
            </div>
            <div className="relative flex justify-center text-xs uppercase">
              <span className="bg-background px-2 text-muted-foreground">
                Or continue with
              </span>
            </div>
          </div>

          <Button
            variant="outline" 
            disabled={isLoading} 
            onClick={signUpWithGoogle}
            className="w-full h-11"
          >
            {isLoading ? (
              <Icons.spinner className="mr-2 h-4 w-4 animate-spin" />
            ) : (
              <Icons.google className="mr-2 h-4 w-4" />
            )}{" "}
            Google
          </Button>

          <div className="mt-6 text-center text-sm text-muted-foreground">
            <a 
              href="/auth/login"
              className="text-primary hover:underline cursor-pointer"
            >
              Already have an account? Sign In
            </a>
          </div>
        </div>
      </div>
    </div>
  )
} 