import { Metadata } from "next"

export const metadata: Metadata = {
  title: "Login | Crane Monitoring System",
  description: "Login to your account to access the crane monitoring system",
} 