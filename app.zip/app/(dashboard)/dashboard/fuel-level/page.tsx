"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { CraneSelector } from "@/components/dashboard/crane-selector"
import { Battery, AlertTriangle, Clock } from "lucide-react"

export default function FuelLevelPage() {
  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-4 md:flex-row md:items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Fuel Level Monitoring</h1>
          <p className="text-muted-foreground">Track and manage fuel levels efficiently</p>
        </div>
        <CraneSelector />
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <Card>
          <CardHeader>
            <CardTitle>Current Fuel Level</CardTitle>
            <CardDescription>Real-time tank level</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">75%</div>
            <p className="text-sm text-muted-foreground mt-2">150 liters remaining</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Time to Refuel</CardTitle>
            <CardDescription>Estimated operation time</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">48 hours</div>
            <p className="text-sm text-muted-foreground mt-2">At current usage rate</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Daily Usage</CardTitle>
            <CardDescription>Average daily consumption</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">75L</div>
            <p className="text-sm text-muted-foreground mt-2">Based on 7-day average</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="history" className="space-y-4">
        <TabsList>
          <TabsTrigger value="history">Usage History</TabsTrigger>
          <TabsTrigger value="refueling">Refueling Schedule</TabsTrigger>
          <TabsTrigger value="alerts">Alerts & Notifications</TabsTrigger>
        </TabsList>

        <TabsContent value="history" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Fuel Level History</CardTitle>
              <CardDescription>7-day fuel level tracking</CardDescription>
            </CardHeader>
            <CardContent className="h-[400px]">
              {/* Add your fuel level history chart component here */}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="refueling" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Refueling Schedule</CardTitle>
              <CardDescription>Upcoming refueling events</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <Clock className="h-5 w-5 text-blue-500 mt-0.5" />
                  <div>
                    <p className="font-medium">Next Scheduled Refuel</p>
                    <p className="text-sm text-muted-foreground">
                      Thursday, March 21 - 08:00 AM
                    </p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <Battery className="h-5 w-5 text-green-500 mt-0.5" />
                  <div>
                    <p className="font-medium">Refuel Amount</p>
                    <p className="text-sm text-muted-foreground">
                      Estimated 150L needed
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="alerts" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Fuel Level Alerts</CardTitle>
              <CardDescription>Alert settings and history</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <AlertTriangle className="h-5 w-5 text-yellow-500 mt-0.5" />
                  <div>
                    <p className="font-medium">Low Fuel Alert</p>
                    <p className="text-sm text-muted-foreground">
                      Triggers when fuel level drops below 25%
                    </p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <AlertTriangle className="h-5 w-5 text-red-500 mt-0.5" />
                  <div>
                    <p className="font-medium">Critical Level Alert</p>
                    <p className="text-sm text-muted-foreground">
                      Triggers when fuel level drops below 10%
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
} 