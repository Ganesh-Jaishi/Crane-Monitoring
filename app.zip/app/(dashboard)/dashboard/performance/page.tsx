"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { getSupabaseClient } from "@/lib/supabase/client"
import { AlertCircle, BarChart3, Download, TrendingDown, TrendingUp } from "lucide-react"
import { CraneSelector } from "@/components/dashboard/crane-selector"
import { Line, LineChart, Bar, BarChart, ResponsiveContainer, XAxis, YAxis } from "recharts"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"

const CRANE_MODELS = [
  {
    id: "CRANE-001",
    name: "Rhino 90C",
    model: "Rhino 90C",
    location: "Port A"
  },
  {
    id: "CRANE-002",
    name: "STC 600C",
    model: "STC 600C",
    location: "Port B"
  },
  {
    id: "CRANE-003",
    name: "STC 600T5P",
    model: "STC 600T5P",
    location: "Port C"
  },
  {
    id: "CRANE-004",
    name: "STC 800C",
    model: "STC 800C",
    location: "Port D"
  }
];

export default function PerformancePage() {
  const [selectedCrane, setSelectedCrane] = useState<string | null>(null)
  const [cranes, setCranes] = useState<any[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [timeRange, setTimeRange] = useState<"day" | "week" | "month">("week")
  const [performanceData, setPerformanceData] = useState<any[]>([])
  const [efficiencyData, setEfficiencyData] = useState<any[]>([])
  const [comparisonData, setComparisonData] = useState<any[]>([])

  useEffect(() => {
    const fetchCranes = async () => {
      try {
        // Use the predefined crane models instead of fetching from database
        setCranes(CRANE_MODELS)
        if (CRANE_MODELS.length > 0) {
          setSelectedCrane(CRANE_MODELS[0].id)
        }
      } catch (error) {
        console.error("Error setting up cranes:", error)
      } finally {
        setIsLoading(false)
      }
    }

    fetchCranes()
  }, [])

  useEffect(() => {
    if (!selectedCrane) return

    // Generate mock performance data based on time range
    const generatePerformanceData = () => {
      let data: any[] = []
      const now = new Date()

      if (timeRange === "day") {
        // Generate hourly data for the last 24 hours
        data = Array.from({ length: 24 }, (_, i) => {
          const hour = new Date(now)
          hour.setHours(hour.getHours() - (23 - i))

          return {
            time: hour.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
            performance: Math.round(75 + Math.sin(i / 3) * 15 + Math.random() * 5),
            uptime: Math.round(95 + Math.sin(i / 4) * 3 + Math.random() * 2),
            temperature: Math.round(60 + Math.sin(i / 2) * 10 + Math.random() * 3),
          }
        })
      } else if (timeRange === "week") {
        // Generate daily data for the last 7 days
        const days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
        data = Array.from({ length: 7 }, (_, i) => {
          return {
            time: days[i],
            performance: Math.round(75 + Math.sin(i / 2) * 15 + Math.random() * 5),
            uptime: Math.round(95 + Math.sin(i / 3) * 3 + Math.random() * 2),
            temperature: Math.round(60 + Math.sin(i / 1.5) * 10 + Math.random() * 3),
          }
        })
      } else if (timeRange === "month") {
        // Generate weekly data for the last 4 weeks
        data = Array.from({ length: 4 }, (_, i) => {
          return {
            time: `Week ${i + 1}`,
            performance: Math.round(75 + Math.sin(i / 1) * 15 + Math.random() * 5),
            uptime: Math.round(95 + Math.sin(i / 1.5) * 3 + Math.random() * 2),
            temperature: Math.round(60 + Math.sin(i / 0.8) * 10 + Math.random() * 3),
          }
        })
      }

      setPerformanceData(data)
    }

    // Generate mock efficiency data
    const generateEfficiencyData = () => {
      const data = [
        { category: "Fuel Efficiency", value: 82, target: 90 },
        { category: "Energy Usage", value: 78, target: 85 },
        { category: "Operational Speed", value: 92, target: 95 },
        { category: "Maintenance Score", value: 88, target: 90 },
        { category: "Safety Rating", value: 95, target: 98 },
      ]

      setEfficiencyData(data)
    }

    // Generate mock comparison data
    const generateComparisonData = () => {
      const data = [
        { name: "Rhino 90C", performance: 85, efficiency: 82, uptime: 94 },
        { name: "STC 600C", performance: 78, efficiency: 75, uptime: 91 },
        { name: "STC 600T5P", performance: 82, efficiency: 80, uptime: 93 },
        { name: "STC 800C", performance: 88, efficiency: 86, uptime: 96 }
      ]

      setComparisonData(data)
    }

    generatePerformanceData()
    generateEfficiencyData()
    generateComparisonData()
  }, [selectedCrane, timeRange])

  const handleCraneChange = (craneId: string) => {
    setSelectedCrane(craneId)
  }

  if (isLoading) {
    return (
      <div className="flex h-full items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent" />
      </div>
    )
  }

  // Calculate performance metrics
  const calculateMetrics = () => {
    if (performanceData.length === 0) return { avgPerformance: 0, avgUptime: 0, avgTemp: 0 }

    const avgPerformance = performanceData.reduce((sum, item) => sum + item.performance, 0) / performanceData.length
    const avgUptime = performanceData.reduce((sum, item) => sum + item.uptime, 0) / performanceData.length
    const avgTemp = performanceData.reduce((sum, item) => sum + item.temperature, 0) / performanceData.length

    return { avgPerformance, avgUptime, avgTemp }
  }

  const metrics = calculateMetrics()

  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-4 md:flex-row md:items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Performance Analytics</h1>
          <p className="text-muted-foreground">Monitor and analyze crane performance metrics and efficiency</p>
        </div>
        <div className="flex items-center gap-2">
          <Select value={timeRange} onValueChange={(value) => setTimeRange(value as any)}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Select time range" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="day">Last 24 Hours</SelectItem>
              <SelectItem value="week">Last 7 Days</SelectItem>
              <SelectItem value="month">Last 30 Days</SelectItem>
            </SelectContent>
          </Select>
          <CraneSelector cranes={cranes} selectedCrane={selectedCrane} onChange={handleCraneChange} />
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Performance Score</CardTitle>
            <BarChart3 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{Math.round(metrics.avgPerformance)}%</div>
            <div className="mt-1 flex items-center text-xs text-muted-foreground">
              {metrics.avgPerformance > 80 ? (
                <>
                  <TrendingUp className="mr-1 h-3 w-3 text-green-500" />
                  <span className="text-green-500 font-medium">Good</span>
                  <span className="ml-1">performance level</span>
                </>
              ) : (
                <>
                  <TrendingDown className="mr-1 h-3 w-3 text-yellow-500" />
                  <span className="text-yellow-500 font-medium">Needs improvement</span>
                </>
              )}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Uptime</CardTitle>
            <BarChart3 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{Math.round(metrics.avgUptime)}%</div>
            <div className="mt-1 flex items-center text-xs text-muted-foreground">
              {metrics.avgUptime > 90 ? (
                <>
                  <TrendingUp className="mr-1 h-3 w-3 text-green-500" />
                  <span className="text-green-500 font-medium">Excellent</span>
                  <span className="ml-1">operational reliability</span>
                </>
              ) : (
                <>
                  <TrendingDown className="mr-1 h-3 w-3 text-red-500" />
                  <span className="text-red-500 font-medium">Below target</span>
                </>
              )}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Average Temperature</CardTitle>
            <BarChart3 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{Math.round(metrics.avgTemp)}°C</div>
            <div className="mt-1 flex items-center text-xs text-muted-foreground">
              {metrics.avgTemp < 65 ? (
                <>
                  <TrendingDown className="mr-1 h-3 w-3 text-green-500" />
                  <span className="text-green-500 font-medium">Normal</span>
                  <span className="ml-1">operating temperature</span>
                </>
              ) : (
                <>
                  <TrendingUp className="mr-1 h-3 w-3 text-yellow-500" />
                  <span className="text-yellow-500 font-medium">Elevated</span>
                  <span className="ml-1">monitor closely</span>
                </>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="performance" className="space-y-4">
        <TabsList>
          <TabsTrigger value="performance">Performance Trends</TabsTrigger>
          <TabsTrigger value="efficiency">Efficiency Metrics</TabsTrigger>
          <TabsTrigger value="comparison">Comparative Analysis</TabsTrigger>
        </TabsList>

        <TabsContent value="performance" className="space-y-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0">
              <div className="space-y-1">
                <CardTitle>Performance Metrics Over Time</CardTitle>
                <CardDescription>Key performance indicators tracked over time</CardDescription>
              </div>
              <Button variant="outline" size="sm">
                <Download className="mr-2 h-4 w-4" />
                Export
              </Button>
            </CardHeader>
            <CardContent>
              <div className="h-[400px]">
                <ChartContainer
                  config={{
                    performance: {
                      label: "Performance Score (%)",
                      color: "hsl(var(--chart-1))",
                    },
                    uptime: {
                      label: "Uptime (%)",
                      color: "hsl(var(--chart-2))",
                    },
                    temperature: {
                      label: "Temperature (°C)",
                      color: "hsl(var(--chart-3))",
                    },
                  }}
                  className="h-full"
                >
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={performanceData}>
                      <XAxis dataKey="time" stroke="#888888" fontSize={12} tickLine={false} axisLine={false} />
                      <YAxis
                        stroke="#888888"
                        fontSize={12}
                        tickLine={false}
                        axisLine={false}
                        tickFormatter={(value) => `${value}`}
                      />
                      <ChartTooltip content={<ChartTooltipContent />} />
                      <Line
                        type="monotone"
                        dataKey="performance"
                        stroke="var(--color-performance)"
                        strokeWidth={2}
                        dot={{ r: 4 }}
                        activeDot={{ r: 6 }}
                      />
                      <Line
                        type="monotone"
                        dataKey="uptime"
                        stroke="var(--color-uptime)"
                        strokeWidth={2}
                        dot={{ r: 4 }}
                        activeDot={{ r: 6 }}
                      />
                      <Line
                        type="monotone"
                        dataKey="temperature"
                        stroke="var(--color-temperature)"
                        strokeWidth={2}
                        dot={{ r: 4 }}
                        activeDot={{ r: 6 }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </ChartContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="efficiency" className="space-y-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0">
              <div className="space-y-1">
                <CardTitle>Efficiency Metrics</CardTitle>
                <CardDescription>Current efficiency metrics vs targets</CardDescription>
              </div>
              <Badge variant="outline">Current Period</Badge>
            </CardHeader>
            <CardContent>
              <div className="h-[400px]">
                <ChartContainer
                  config={{
                    value: {
                      label: "Current Value",
                      color: "hsl(var(--chart-1))",
                    },
                    target: {
                      label: "Target",
                      color: "hsl(var(--chart-2))",
                    },
                  }}
                  className="h-full"
                >
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={efficiencyData}
                      layout="vertical"
                      margin={{ top: 20, right: 30, left: 100, bottom: 5 }}
                    >
                      <XAxis type="number" domain={[0, 100]} />
                      <YAxis dataKey="category" type="category" width={100} />
                      <ChartTooltip content={<ChartTooltipContent />} />
                      <Bar dataKey="value" fill="var(--color-value)" radius={[0, 4, 4, 0]} />
                      <Bar dataKey="target" fill="var(--color-target)" radius={[0, 4, 4, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </ChartContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="comparison" className="space-y-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0">
              <div className="space-y-1">
                <CardTitle>Comparative Analysis</CardTitle>
                <CardDescription>Performance comparison between different crane models</CardDescription>
              </div>
              <Button variant="outline" size="sm">
                <Download className="mr-2 h-4 w-4" />
                Export
              </Button>
            </CardHeader>
            <CardContent>
              <div className="h-[400px]">
                <ChartContainer
                  config={{
                    performance: {
                      label: "Performance Score",
                      color: "hsl(var(--chart-1))",
                    },
                    efficiency: {
                      label: "Efficiency",
                      color: "hsl(var(--chart-2))",
                    },
                    uptime: {
                      label: "Uptime",
                      color: "hsl(var(--chart-3))",
                    },
                  }}
                  className="h-full"
                >
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={comparisonData}>
                      <XAxis dataKey="name" stroke="#888888" fontSize={12} tickLine={false} axisLine={false} />
                      <YAxis
                        stroke="#888888"
                        fontSize={12}
                        tickLine={false}
                        axisLine={false}
                        domain={[0, 100]}
                        tickFormatter={(value) => `${value}%`}
                      />
                      <ChartTooltip content={<ChartTooltipContent />} />
                      <Bar dataKey="performance" fill="var(--color-performance)" radius={[4, 4, 0, 0]} />
                      <Bar dataKey="efficiency" fill="var(--color-efficiency)" radius={[4, 4, 0, 0]} />
                      <Bar dataKey="uptime" fill="var(--color-uptime)" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </ChartContainer>
              </div>
              <div className="mt-4">
                <Alert>
                  <AlertCircle className="h-4 w-4" />
                  <AlertTitle>Model Comparison Insight</AlertTitle>
                  <AlertDescription>
                    The STC 800C shows the highest overall performance with 88% performance score and 96% uptime, 
                    while the STC 600C might benefit from efficiency optimizations. Consider implementing the successful 
                    operational practices from the STC 800C across other models.
                  </AlertDescription>
                </Alert>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <Alert>
        <AlertCircle className="h-4 w-4" />
        <AlertTitle>Performance Insight</AlertTitle>
        <AlertDescription>
          Temperature levels are directly correlated with fuel consumption. Maintaining optimal temperature ranges
          (50-65°C) can reduce fuel usage by up to 12%. Consider implementing automatic temperature control systems to
          optimize fuel efficiency.
        </AlertDescription>
      </Alert>
    </div>
  )
}

