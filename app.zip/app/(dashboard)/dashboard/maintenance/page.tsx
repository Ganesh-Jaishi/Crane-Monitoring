"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { getSupabaseClient } from "@/lib/supabase/client"
import { AlertCircle, Calendar, Download, PenToolIcon as Tool, Wrench } from "lucide-react"
import { CraneSelector } from "@/components/dashboard/crane-selector"
import { MaintenanceSchedule } from "@/components/dashboard/maintenance-schedule"
import { MaintenanceHistory } from "@/components/dashboard/maintenance-history"
import { EquipmentHealth } from "@/components/dashboard/equipment-health"
import { PartsInventory } from "@/components/dashboard/parts-inventory"

const CRANE_MODELS = [
  {
    id: "CRANE-001",
    name: "Rhino 90C",
    model: "Rhino 90C",
    location: "Port A"
  },
  {
    id: "CRANE-002",
    name: "STC 600C",
    model: "STC 600C",
    location: "Port B"
  },
  {
    id: "CRANE-003",
    name: "STC 600T5P",
    model: "STC 600T5P",
    location: "Port C"
  },
  {
    id: "CRANE-004",
    name: "STC 800C",
    model: "STC 800C",
    location: "Port D"
  }
];

export default function MaintenancePage() {
  const [selectedCrane, setSelectedCrane] = useState<string | null>(null)
  const [cranes, setCranes] = useState<any[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [maintenanceData, setMaintenanceData] = useState<any>(null)

  useEffect(() => {
    const fetchCranes = async () => {
      try {
        // Use the predefined crane models instead of fetching from database
        setCranes(CRANE_MODELS)
        if (CRANE_MODELS.length > 0) {
          setSelectedCrane(CRANE_MODELS[0].id)
        }
      } catch (error) {
        console.error("Error setting up cranes:", error)
      } finally {
        setIsLoading(false)
      }
    }

    fetchCranes()
  }, [])

  useEffect(() => {
    if (!selectedCrane) return

    const fetchMaintenanceData = async () => {
      try {
        const supabase = getSupabaseClient()
        const { data, error } = await supabase
          .from("maintenance_parameters")
          .select("*")
          .eq("crane_id", selectedCrane)
          .order("timestamp", { ascending: false })
          .limit(1)
          .maybeSingle()

        if (error || !data) {
          // Silently handle error and set default data
          setMaintenanceData({
            last_maintenance_date: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
            next_maintenance_date: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
            total_operating_hours: 0,
            component_health_status: {
              engine: "Good",
              hydraulics: "Good",
              structure: "Good",
              electronics: "Good"
            },
            maintenance_history: []
          })
          return
        }

        setMaintenanceData(data)
      } catch (error) {
        // Silently handle error and set default data
        setMaintenanceData({
          last_maintenance_date: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
          next_maintenance_date: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
          total_operating_hours: 0,
          component_health_status: {
            engine: "Good",
            hydraulics: "Good",
            structure: "Good",
            electronics: "Good"
          },
          maintenance_history: []
        })
      }
    }

    fetchMaintenanceData()

    // Set up real-time subscription for maintenance data
    const supabase = getSupabaseClient()
    const subscription = supabase
      .channel("maintenance-changes")
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "maintenance_parameters",
          filter: `crane_id=eq.${selectedCrane}`,
        },
        (payload) => {
          setMaintenanceData(payload.new)
        },
      )
      .subscribe()

    return () => {
      supabase.removeChannel(subscription)
    }
  }, [selectedCrane])

  const handleCraneChange = (craneId: string) => {
    setSelectedCrane(craneId)
  }

  if (isLoading) {
    return (
      <div className="flex h-full items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent" />
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-4 md:flex-row md:items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Maintenance Management</h1>
          <p className="text-muted-foreground">Schedule, track, and manage maintenance activities</p>
        </div>
        <CraneSelector cranes={cranes} selectedCrane={selectedCrane} onChange={handleCraneChange} />
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Next Maintenance</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {maintenanceData?.scheduled_date
                ? new Date(maintenanceData.scheduled_date).toLocaleDateString()
                : "Not scheduled"}
            </div>
            <p className="text-xs text-muted-foreground">
              {maintenanceData?.maintenance_type || "Regular maintenance"}
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Equipment Health</CardTitle>
            <Tool className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">87%</div>
            <p className="text-xs text-muted-foreground">Overall condition score</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending Tasks</CardTitle>
            <Wrench className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">3</div>
            <p className="text-xs text-muted-foreground">Maintenance tasks awaiting completion</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Parts Inventory</CardTitle>
            <Tool className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">94%</div>
            <p className="text-xs text-muted-foreground">Critical parts availability</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="schedule" className="space-y-4">
        <TabsList>
          <TabsTrigger value="schedule">Maintenance Schedule</TabsTrigger>
          <TabsTrigger value="history">Maintenance History</TabsTrigger>
          <TabsTrigger value="health">Equipment Health</TabsTrigger>
          <TabsTrigger value="inventory">Parts Inventory</TabsTrigger>
        </TabsList>
        <TabsContent value="schedule" className="space-y-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0">
              <div className="space-y-1">
                <CardTitle>Upcoming Maintenance</CardTitle>
                <CardDescription>Scheduled maintenance activities</CardDescription>
              </div>
              <Button variant="outline" size="sm">
                <Download className="mr-2 h-4 w-4" />
                Export
              </Button>
            </CardHeader>
            <CardContent>
              <MaintenanceSchedule craneId={selectedCrane} />
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="history" className="space-y-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0">
              <div className="space-y-1">
                <CardTitle>Maintenance History</CardTitle>
                <CardDescription>Past maintenance activities and outcomes</CardDescription>
              </div>
              <Badge variant="outline">Last 6 months</Badge>
            </CardHeader>
            <CardContent>
              <MaintenanceHistory craneId={selectedCrane} />
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="health" className="space-y-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0">
              <div className="space-y-1">
                <CardTitle>Equipment Health Status</CardTitle>
                <CardDescription>Component condition and health metrics</CardDescription>
              </div>
              <Badge variant="outline">Real-time</Badge>
            </CardHeader>
            <CardContent>
              <EquipmentHealth craneId={selectedCrane} />
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="inventory" className="space-y-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0">
              <div className="space-y-1">
                <CardTitle>Parts Inventory</CardTitle>
                <CardDescription>Availability of maintenance parts and components</CardDescription>
              </div>
              <Button variant="outline" size="sm">
                Order Parts
              </Button>
            </CardHeader>
            <CardContent>
              <PartsInventory craneId={selectedCrane} />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <Alert>
        <AlertCircle className="h-4 w-4" />
        <AlertTitle>Maintenance Recommendation</AlertTitle>
        <AlertDescription>
          Based on vibration analysis, we recommend inspecting the main hoist gearbox during the next scheduled
          maintenance. Early signs of wear detected.
        </AlertDescription>
      </Alert>
    </div>
  )
}

