"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { CraneSelector } from "@/components/dashboard/crane-selector"
import { Zap, TrendingUp, AlertCircle } from "lucide-react"

export default function PowerMonitoringPage() {
  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-4 md:flex-row md:items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Power Monitoring</h1>
          <p className="text-muted-foreground">Detailed power consumption analysis and optimization</p>
        </div>
        <CraneSelector />
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <Card>
          <CardHeader>
            <CardTitle>Current Power Draw</CardTitle>
            <CardDescription>Real-time power consumption</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">42.8 kW</div>
            <p className="text-sm text-muted-foreground mt-2">↓ 12% from average</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Peak Power Today</CardTitle>
            <CardDescription>Highest consumption in 24h</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">58.2 kW</div>
            <p className="text-sm text-muted-foreground mt-2">At 14:30</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Average Power</CardTitle>
            <CardDescription>30-day average consumption</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">45.2 kW</div>
            <p className="text-sm text-muted-foreground mt-2">Baseline consumption</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="consumption" className="space-y-4">
        <TabsList>
          <TabsTrigger value="consumption">Consumption Patterns</TabsTrigger>
          <TabsTrigger value="efficiency">Efficiency Analysis</TabsTrigger>
          <TabsTrigger value="optimization">Optimization Tips</TabsTrigger>
        </TabsList>

        <TabsContent value="consumption" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Power Consumption Over Time</CardTitle>
              <CardDescription>24-hour consumption pattern</CardDescription>
            </CardHeader>
            <CardContent className="h-[400px]">
              {/* Add your power consumption chart component here */}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="efficiency" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Power Efficiency Metrics</CardTitle>
              <CardDescription>Key performance indicators</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">Power Factor</p>
                    <p className="text-sm text-muted-foreground">Current power factor rating</p>
                  </div>
                  <div className="text-2xl font-bold">0.92</div>
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">Energy Efficiency</p>
                    <p className="text-sm text-muted-foreground">Overall system efficiency</p>
                  </div>
                  <div className="text-2xl font-bold">87%</div>
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">Peak Demand</p>
                    <p className="text-sm text-muted-foreground">Maximum power requirement</p>
                  </div>
                  <div className="text-2xl font-bold">65 kW</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="optimization" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Optimization Recommendations</CardTitle>
              <CardDescription>Suggestions to improve power efficiency</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <TrendingUp className="h-5 w-5 text-green-500 mt-0.5" />
                  <div>
                    <p className="font-medium">Optimize Operating Hours</p>
                    <p className="text-sm text-muted-foreground">
                      Schedule heavy operations during off-peak hours to reduce power costs
                    </p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <Zap className="h-5 w-5 text-yellow-500 mt-0.5" />
                  <div>
                    <p className="font-medium">Power Factor Correction</p>
                    <p className="text-sm text-muted-foreground">
                      Install capacitor banks to improve power factor from 0.92 to 0.98
                    </p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <AlertCircle className="h-5 w-5 text-blue-500 mt-0.5" />
                  <div>
                    <p className="font-medium">Regular Maintenance</p>
                    <p className="text-sm text-muted-foreground">
                      Schedule preventive maintenance to maintain optimal power efficiency
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
} 