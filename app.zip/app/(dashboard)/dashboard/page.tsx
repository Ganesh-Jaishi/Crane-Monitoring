"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { FuelConsumption } from "@/components/dashboard/fuel-consumption"
import { EnergyOptimization } from "@/components/dashboard/energy-optimization"
import { EfficiencyAnalytics } from "@/components/dashboard/efficiency-analytics"
import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"

export default function DashboardPage() {
  const [selectedCraneId, setSelectedCraneId] = useState("CRANE-001")
  const router = useRouter()

  return (
    <div className="flex-1 space-y-6 p-8 pt-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => router.push('/crane-selection')}
            className="mr-2"
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h2 className="text-3xl font-bold tracking-tight">Crane Monitoring Dashboard</h2>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm">
            Export
          </Button>
          <Button size="sm">
            Configure
          </Button>
        </div>
      </div>
      
      {/* Fuel Consumption Section */}
      <div className="space-y-4">
        <h3 className="text-2xl font-semibold">Fuel Consumption Monitoring</h3>
        <p className="text-muted-foreground mb-4">
          Track and analyze equipment fuel consumption patterns, efficiency, and optimize usage.
        </p>
        <FuelConsumption craneId={selectedCraneId} />
      </div>
      
      {/* Energy Optimization Section */}
      <div className="space-y-4 mt-10">
        <h3 className="text-2xl font-semibold">Energy Optimization</h3>
        <p className="text-muted-foreground mb-4">
          Monitor power usage patterns, identify optimization opportunities, and improve energy efficiency.
        </p>
        <EnergyOptimization craneId={selectedCraneId} />
      </div>
      
      {/* Efficiency Analytics Section */}
      <div className="space-y-4 mt-10">
        <h3 className="text-2xl font-semibold">Efficiency Analytics</h3>
        <p className="text-muted-foreground mb-4">
          Analyze operational efficiency trends, correlations, and performance metrics over time.
        </p>
        <EfficiencyAnalytics craneId={selectedCraneId} />
      </div>
    </div>
  )
}

