"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { EnergyEfficiencyDashboard } from "@/components/dashboard/energy-efficiency-dashboard"
import { CraneSelector } from "@/components/dashboard/crane-selector"
import { Thermometer } from "lucide-react"

const DEMO_CRANES = [
  { 
    id: "CRANE-001", 
    name: "Rhino 90C",
    model: "Rhino 90C",
    location: "Port A",
    severity: "normal" as const
  },
  { 
    id: "CRANE-002", 
    name: "STC 600C",
    model: "STC 600C",
    location: "Port B",
    severity: "normal" as const
  },
  { 
    id: "CRANE-003", 
    name: "STC 600T5P",
    model: "STC 600T5P",
    location: "Port C",
    severity: "normal" as const
  },
  { 
    id: "CRANE-004", 
    name: "STC 800C",
    model: "STC 800C",
    location: "Port D",
    severity: "normal" as const
  }
]

export default function TemperaturePage() {
  const [selectedCraneId, setSelectedCraneId] = useState<string>("CRANE-001")

  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-4 md:flex-row md:items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Temperature Monitoring</h1>
          <p className="text-muted-foreground">
            Monitor real-time temperature metrics for motor and environment
          </p>
        </div>
        <CraneSelector 
          cranes={DEMO_CRANES}
          selectedCrane={selectedCraneId}
          onChange={setSelectedCraneId}
        />
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-center space-x-2">
            <Thermometer className="h-6 w-6 text-orange-500" />
            <div>
              <CardTitle>Temperature Analysis</CardTitle>
              <CardDescription>
                Detailed temperature monitoring for motor and surrounding environment
              </CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <EnergyEfficiencyDashboard craneId={selectedCraneId} showOnlyTemperature />
        </CardContent>
      </Card>
    </div>
  )
} 