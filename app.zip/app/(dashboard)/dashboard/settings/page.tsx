"use client"

import { useState, useEffect } from "react"
import { useTheme } from "next-themes"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog"
import { Save, AlertTriangle } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

export default function SettingsPage() {
  const { toast } = useToast()
  const { theme, setTheme } = useTheme()
  
  const [mounted, setMounted] = useState(false)

  const [displaySettings, setDisplaySettings] = useState({
    theme: "system",
    refreshRate: "30",
    showRealTimeData: true,
    compactView: false
  })

  const [systemSettings, setSystemSettings] = useState({
    backupFrequency: "daily",
    alertThreshold: "medium",
    dataRetention: "30",
    autoOptimize: true
  })

  useEffect(() => {
    const savedDisplaySettings = localStorage.getItem('displaySettings')
    const savedSystemSettings = localStorage.getItem('systemSettings')
    
    if (savedDisplaySettings) {
      const parsed = JSON.parse(savedDisplaySettings)
      setDisplaySettings(parsed)
    }
    
    if (savedSystemSettings) {
      setSystemSettings(JSON.parse(savedSystemSettings))
    }

    setMounted(true)
  }, [])

  useEffect(() => {
    if (mounted && theme) {
      const updatedSettings = { ...displaySettings, theme }
      setDisplaySettings(updatedSettings)
      queueMicrotask(() => {
        localStorage.setItem('displaySettings', JSON.stringify(updatedSettings))
      })
    }
  }, [theme, mounted])

  const handleThemeChange = (value: string) => {
    setTheme(value)
  }

  const handleDisplaySettingsSave = () => {
    localStorage.setItem('displaySettings', JSON.stringify(displaySettings))
    toast({
      title: "Display settings saved",
      description: "Your display preferences have been updated.",
    })
  }

  const handleSystemSettingsSave = () => {
    // Save system settings to localStorage
    localStorage.setItem('systemSettings', JSON.stringify(systemSettings))
    toast({
      title: "System settings saved",
      description: "Your system settings have been updated.",
    })
  }

  const handleResetSettings = () => {
    // Reset all settings to default
    setDisplaySettings({
      theme: "system",
      refreshRate: "30",
      showRealTimeData: true,
      compactView: false
    })
    setSystemSettings({
      backupFrequency: "daily",
      alertThreshold: "medium",
      dataRetention: "30",
      autoOptimize: true
    })
    localStorage.removeItem('displaySettings')
    localStorage.removeItem('systemSettings')
    toast({
      title: "Settings reset",
      description: "All settings have been reset to default values.",
    })
  }

  const handleClearData = () => {
    // Clear all application data
    localStorage.clear()
    toast({
      title: "Data cleared",
      description: "All application data has been cleared.",
      variant: "destructive"
    })
  }

  // Prevent hydration issues
  if (!mounted) {
    return null
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Settings</h1>
        <p className="text-muted-foreground">Manage your application preferences and system settings.</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        {/* Display Settings */}
        <Card>
          <CardHeader>
            <CardTitle>Display Settings</CardTitle>
            <CardDescription>Customize how data is displayed in the dashboard.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="theme">Theme</Label>
              <Select 
                value={theme || "system"}
                onValueChange={handleThemeChange}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select theme" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="light">Light</SelectItem>
                  <SelectItem value="dark">Dark</SelectItem>
                  <SelectItem value="system">System</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="refreshRate">Data Refresh Rate (seconds)</Label>
              <Input
                id="refreshRate"
                type="number"
                value={displaySettings.refreshRate}
                onChange={(e) => setDisplaySettings(prev => ({ ...prev, refreshRate: e.target.value }))}
              />
            </div>

            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Compact View</Label>
                <p className="text-sm text-muted-foreground">Use a more compact layout for dashboards.</p>
              </div>
              <Switch
                checked={displaySettings.compactView}
                onCheckedChange={(checked) => setDisplaySettings(prev => ({ ...prev, compactView: checked }))}
              />
            </div>

            <Button onClick={handleDisplaySettingsSave} className="w-full">
              <Save className="mr-2 h-4 w-4" />
              Save Display Settings
            </Button>
          </CardContent>
        </Card>

        {/* System Settings */}
        <Card>
          <CardHeader>
            <CardTitle>System Settings</CardTitle>
            <CardDescription>Configure system-wide settings and preferences.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="backupFrequency">Backup Frequency</Label>
              <Select 
                value={systemSettings.backupFrequency}
                onValueChange={(value) => setSystemSettings(prev => ({ ...prev, backupFrequency: value }))}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select frequency" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="hourly">Hourly</SelectItem>
                  <SelectItem value="daily">Daily</SelectItem>
                  <SelectItem value="weekly">Weekly</SelectItem>
                  <SelectItem value="monthly">Monthly</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="alertThreshold">Alert Threshold</Label>
              <Select 
                value={systemSettings.alertThreshold}
                onValueChange={(value) => setSystemSettings(prev => ({ ...prev, alertThreshold: value }))}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select threshold" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="dataRetention">Data Retention (days)</Label>
              <Input
                id="dataRetention"
                type="number"
                value={systemSettings.dataRetention}
                onChange={(e) => setSystemSettings(prev => ({ ...prev, dataRetention: e.target.value }))}
              />
            </div>

            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Auto-Optimize</Label>
                <p className="text-sm text-muted-foreground">Automatically optimize system performance.</p>
              </div>
              <Switch
                checked={systemSettings.autoOptimize}
                onCheckedChange={(checked) => setSystemSettings(prev => ({ ...prev, autoOptimize: checked }))}
              />
            </div>

            <Button onClick={handleSystemSettingsSave} className="w-full">
              <Save className="mr-2 h-4 w-4" />
              Save System Settings
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Danger Zone */}
      <Card className="border-red-200 bg-red-50">
        <CardHeader>
          <CardTitle className="text-red-600">
            <AlertTriangle className="inline-block mr-2 h-5 w-5" />
            Danger Zone
          </CardTitle>
          <CardDescription>The following actions are destructive and cannot be undone. Please proceed with caution.</CardDescription>
        </CardHeader>
        <CardContent className="flex gap-4">
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button variant="outline" className="border-red-500 text-red-500 hover:bg-red-50">
                Reset All Settings
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                <AlertDialogDescription>
                  This will reset all settings to their default values. This action cannot be undone.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction onClick={handleResetSettings} className="bg-red-500 hover:bg-red-600">
                  Reset Settings
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>

          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button variant="outline" className="border-red-500 text-red-500 hover:bg-red-50">
                Clear All Data
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                <AlertDialogDescription>
                  This will permanently delete all your application data. This action cannot be undone.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction onClick={handleClearData} className="bg-red-500 hover:bg-red-600">
                  Clear Data
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </CardContent>
      </Card>
    </div>
  )
}

