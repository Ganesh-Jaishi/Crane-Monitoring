"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { 
  Thermometer, 
  Power, 
  ToggleLeft,
  Radio,
  CheckCircle2, 
  AlertTriangle, 
  XCircle,
  Clock, 
  Activity,
  Battery,
  Wifi,
  Settings,
  RefreshCw
} from "lucide-react"
import { cn } from "@/lib/utils"

interface Sensor {
  id: string;
  name: string;
  type: 'temperature' | 'power' | 'relay' | 'pressure';
  icon: React.ElementType;
  location: string;
  status: 'online' | 'offline' | 'warning' | 'error';
  value: number;
  unit: string;
  battery?: number;
  signalStrength?: number;
  lastUpdate: string;
  isActive: boolean;
  thresholds: {
    warning: number;
    critical: number;
  };
  autoShutdown: boolean;
}

export default function SensorStatusPage() {
  const [sensors, setSensors] = useState<Sensor[]>([
    {
      id: "temp1",
      name: "Motor Temperature",
      type: "temperature",
      icon: Thermometer,
      location: "Main Motor Housing",
      status: "online",
      value: 65,
      unit: "°C",
      battery: 85,
      signalStrength: 90,
      lastUpdate: "Just now",
      isActive: true,
      thresholds: {
        warning: 65,
        critical: 75
      },
      autoShutdown: true
    },
    {
      id: "temp2",
      name: "Ambient Temperature",
      type: "temperature",
      icon: Thermometer,
      location: "Control Box",
      status: "online",
      value: 28,
      unit: "°C",
      battery: 75,
      signalStrength: 95,
      lastUpdate: "2 min ago",
      isActive: true,
      thresholds: {
        warning: 35,
        critical: 45
      },
      autoShutdown: true
    },
    {
      id: "power1",
      name: "Main Power Monitor",
      type: "power",
      icon: Power,
      location: "Distribution Panel",
      status: "online",
      value: 224,
      unit: "V",
      signalStrength: 100,
      lastUpdate: "Just now",
      isActive: true,
      thresholds: {
        warning: 240,
        critical: 250
      },
      autoShutdown: true
    },
    {
      id: "relay1",
      name: "Main Relay Module",
      type: "relay",
      icon: ToggleLeft,
      location: "Control Panel",
      status: "online",
      value: 1,
      unit: "ON/OFF",
      signalStrength: 98,
      lastUpdate: "Just now",
      isActive: true,
      thresholds: {
        warning: 0,
        critical: 0
      },
      autoShutdown: true
    },
    {
      id: "relay2",
      name: "Secondary Relay",
      type: "relay",
      icon: ToggleLeft,
      location: "Auxiliary Panel",
      status: "warning",
      value: 0,
      unit: "ON/OFF",
      signalStrength: 45,
      lastUpdate: "15 min ago",
      isActive: false,
      thresholds: {
        warning: 0,
        critical: 0
      },
      autoShutdown: true
    },
    {
      id: "press1",
      name: "Hydraulic Pressure",
      type: "pressure",
      icon: Radio,
      location: "Hydraulic System",
      status: "error",
      value: 0,
      unit: "bar",
      battery: 12,
      signalStrength: 0,
      lastUpdate: "2 hours ago",
      isActive: false,
      thresholds: {
        warning: 85,
        critical: 95
      },
      autoShutdown: true
    }
  ]);

  // Alert message state
  const [alertMessage, setAlertMessage] = useState<string | null>(null);

  // Update sensor data randomly for simulation
  useEffect(() => {
    const interval = setInterval(() => {
      setSensors(prevSensors => 
        prevSensors.map(sensor => {
          if (sensor.status === 'offline' || !sensor.isActive) return sensor;
          
          // Random value fluctuations
          let newValue = sensor.value;
          let newStatus = sensor.status;
          
          if (sensor.type === 'temperature') {
            // Temperature random fluctuation ±2°C
            newValue = Math.max(20, Math.min(90, sensor.value + (Math.random() * 4 - 2)));
          } else if (sensor.type === 'power') {
            // Voltage random fluctuation ±5V
            newValue = Math.max(180, Math.min(250, sensor.value + (Math.random() * 10 - 5)));
          } else if (sensor.type === 'pressure') {
            // Pressure random fluctuation ±2 bar
            newValue = Math.max(0, Math.min(100, sensor.value + (Math.random() * 4 - 2)));
          }
          
          // Update battery if applicable
          const newBattery = sensor.battery 
            ? Math.max(0, sensor.battery - Math.random() * 0.2) 
            : undefined;
            
          // Update signal strength with small random variations
          const newSignalStrength = sensor.signalStrength 
            ? Math.max(0, Math.min(100, sensor.signalStrength + (Math.random() * 4 - 2))) 
            : undefined;
          
          // Update status based on thresholds
          if (newValue >= sensor.thresholds.critical) {
            newStatus = 'error';
          } else if (newValue >= sensor.thresholds.warning) {
            newStatus = 'warning';
          } else {
            newStatus = 'online';
          }
          
          // Auto shutdown if critical and enabled
          if (newStatus === 'error' && sensor.autoShutdown && sensor.isActive) {
            setAlertMessage(`Auto shutdown triggered for ${sensor.name}`);
            return {
              ...sensor,
              value: newValue,
              status: newStatus,
              battery: newBattery,
              signalStrength: newSignalStrength,
              lastUpdate: 'Just now',
              isActive: false
            };
          }
          
          return {
            ...sensor,
            value: newValue,
            status: newStatus,
            battery: newBattery,
            signalStrength: newSignalStrength,
            lastUpdate: 'Just now'
          };
        })
      );
    }, 5000);
    
    return () => clearInterval(interval);
  }, []);

  // Clear alert after 5 seconds
  useEffect(() => {
    if (alertMessage) {
      const timer = setTimeout(() => {
        setAlertMessage(null);
      }, 5000);
      
      return () => clearTimeout(timer);
    }
  }, [alertMessage]);

  // Emergency halt - deactivate all sensors
  const emergencyHalt = () => {
    setSensors(prevSensors => 
      prevSensors.map(sensor => ({
        ...sensor,
        isActive: false,
        status: sensor.status === 'offline' ? 'offline' : 'online',
        value: sensor.type === 'relay' ? 0 : sensor.value
      }))
    );
    setAlertMessage('EMERGENCY HALT ACTIVATED: All systems powered down');
  };

  // Toggle sensor status
  const toggleSensor = (id: string) => {
    setSensors(prevSensors => 
      prevSensors.map(sensor => 
        sensor.id === id 
          ? { 
              ...sensor, 
              isActive: !sensor.isActive,
              value: sensor.type === 'relay' ? (sensor.isActive ? 0 : 1) : sensor.value
            } 
          : sensor
      )
    );
  };

  // Update threshold
  const updateThreshold = (id: string, field: 'warning' | 'critical', value: string) => {
    const numValue = parseFloat(value);
    if (isNaN(numValue)) return;
    
    setSensors(prevSensors => 
      prevSensors.map(sensor => 
        sensor.id === id 
          ? { 
              ...sensor, 
              thresholds: {
                ...sensor.thresholds,
                [field]: numValue
              }
            } 
          : sensor
      )
    );
  };

  // Toggle auto shutdown
  const toggleAutoShutdown = (id: string) => {
    setSensors(prevSensors => 
      prevSensors.map(sensor => 
        sensor.id === id 
          ? { ...sensor, autoShutdown: !sensor.autoShutdown } 
          : sensor
      )
    );
  };

  // Reset sensor
  const resetSensor = (id: string) => {
    setSensors(prevSensors => 
      prevSensors.map(sensor => 
        sensor.id === id 
          ? { 
              ...sensor, 
              status: 'online',
              isActive: true,
              value: sensor.type === 'relay' ? 1 : 
                     sensor.type === 'temperature' ? 25 :
                     sensor.type === 'power' ? 220 : 50
            } 
          : sensor
      )
    );
  };

  // Get color for sensor status
  const getStatusColor = (status: string): string => {
    switch (status) {
      case 'online': return 'text-green-500';
      case 'warning': return 'text-amber-500';
      case 'error': return 'text-red-500';
      case 'offline': return 'text-gray-500';
      default: return 'text-gray-500';
    }
  };

  // Get icon for sensor status
  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'online': return <CheckCircle2 className="h-5 w-5 text-green-500" />;
      case 'warning': return <AlertTriangle className="h-5 w-5 text-amber-500" />;
      case 'error': return <XCircle className="h-5 w-5 text-red-500" />;
      case 'offline': return <AlertTriangle className="h-5 w-5 text-gray-500" />;
      default: return <AlertTriangle className="h-5 w-5 text-gray-500" />;
    }
  };

  // Filter sensors by type
  const filterSensors = (type: string | null) => {
    if (!type || type === 'all') return sensors;
    return sensors.filter(sensor => sensor.type === type);
  };

  // Get sensors summary stats
  const getSensorStats = () => {
    const total = sensors.length;
    const active = sensors.filter(s => s.isActive).length;
    const warnings = sensors.filter(s => s.status === 'warning').length;
    const errors = sensors.filter(s => s.status === 'error').length;
    const offline = sensors.filter(s => s.status === 'offline').length;
    
    return { total, active, warnings, errors, offline };
  };

  const stats = getSensorStats();

  return (
    <div className="space-y-6">
      {/* Emergency Halt Alert Bar */}
      {alertMessage && (
        <div className="sticky top-0 z-50 p-4 mb-4 bg-red-100 border border-red-400 text-red-700 rounded flex justify-between items-center">
          <div className="flex items-center">
            <AlertTriangle className="h-5 w-5 mr-2" />
            <span className="font-bold">{alertMessage}</span>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setAlertMessage(null)}
          >
            Dismiss
          </Button>
        </div>
      )}

      {/* Header with Emergency Halt Button */}
      <div className="sticky top-0 z-10 bg-white dark:bg-gray-950 py-2 border-b">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-3xl font-bold tracking-tight">Sensor Status & Control</h2>
            <p className="text-muted-foreground">Monitor and control all sensors from a single dashboard</p>
          </div>
          <div className="flex space-x-4">
            <Button 
              variant="outline" 
              size="sm" 
              className="flex items-center gap-2"
              onClick={() => window.location.reload()}
            >
              <RefreshCw className="h-4 w-4" />
              Refresh
            </Button>
            <Button 
              variant="destructive" 
              size="lg" 
              className="flex items-center gap-2 shadow-lg"
              onClick={emergencyHalt}
            >
              <Power className="h-5 w-5" />
              EMERGENCY HALT
            </Button>
          </div>
        </div>
      </div>

      {/* Sensor Stats Summary */}
      <div className="grid gap-4 grid-cols-2 md:grid-cols-5">
        <Card>
          <CardHeader className="py-2">
            <CardTitle className="text-sm">Total Sensors</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.total}</div>
            <p className="text-xs text-muted-foreground">Installed sensors</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="py-2">
            <CardTitle className="text-sm text-green-600">Active</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{stats.active}</div>
            <p className="text-xs text-muted-foreground">Running sensors</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="py-2">
            <CardTitle className="text-sm text-amber-600">Warnings</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-amber-600">{stats.warnings}</div>
            <p className="text-xs text-muted-foreground">Need attention</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="py-2">
            <CardTitle className="text-sm text-red-600">Errors</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{stats.errors}</div>
            <p className="text-xs text-muted-foreground">Critical issues</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="py-2">
            <CardTitle className="text-sm text-gray-600">Offline</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-gray-600">{stats.offline}</div>
            <p className="text-xs text-muted-foreground">Disconnected</p>
          </CardContent>
        </Card>
      </div>

      {/* Sensor Tabs and Content */}
      <Tabs defaultValue="all" className="space-y-4">
        <div className="flex justify-between items-center">
          <TabsList>
            <TabsTrigger value="all">All Sensors</TabsTrigger>
            <TabsTrigger value="temperature">Temperature</TabsTrigger>
            <TabsTrigger value="power">Power</TabsTrigger>
            <TabsTrigger value="relay">Relay</TabsTrigger>
            <TabsTrigger value="pressure">Pressure</TabsTrigger>
          </TabsList>
          <div className="flex gap-2">
            <Badge variant="outline" className="bg-green-50">
              <div className="h-2 w-2 rounded-full bg-green-500 mr-1"></div>
              <span>Online: {sensors.filter(s => s.status === 'online').length}</span>
            </Badge>
            <Badge variant="outline" className="bg-amber-50">
              <div className="h-2 w-2 rounded-full bg-amber-500 mr-1"></div>
              <span>Warning: {stats.warnings}</span>
            </Badge>
            <Badge variant="outline" className="bg-red-50">
              <div className="h-2 w-2 rounded-full bg-red-500 mr-1"></div>
              <span>Error: {stats.errors}</span>
            </Badge>
          </div>
        </div>

        <TabsContent value="all" className="space-y-4">
          {sensors.map(sensor => (
            <SensorCard 
              key={sensor.id} 
              sensor={sensor}
              toggleSensor={toggleSensor}
              updateThreshold={updateThreshold}
              toggleAutoShutdown={toggleAutoShutdown}
              resetSensor={resetSensor}
              getStatusIcon={getStatusIcon}
            />
          ))}
        </TabsContent>

        <TabsContent value="temperature" className="space-y-4">
          {filterSensors('temperature').map(sensor => (
            <SensorCard 
              key={sensor.id} 
              sensor={sensor}
              toggleSensor={toggleSensor}
              updateThreshold={updateThreshold}
              toggleAutoShutdown={toggleAutoShutdown}
              resetSensor={resetSensor}
              getStatusIcon={getStatusIcon}
            />
          ))}
        </TabsContent>

        <TabsContent value="power" className="space-y-4">
          {filterSensors('power').map(sensor => (
            <SensorCard 
              key={sensor.id} 
              sensor={sensor}
              toggleSensor={toggleSensor}
              updateThreshold={updateThreshold}
              toggleAutoShutdown={toggleAutoShutdown}
              resetSensor={resetSensor}
              getStatusIcon={getStatusIcon}
            />
          ))}
        </TabsContent>

        <TabsContent value="relay" className="space-y-4">
          {filterSensors('relay').map(sensor => (
            <SensorCard 
              key={sensor.id} 
              sensor={sensor}
              toggleSensor={toggleSensor}
              updateThreshold={updateThreshold}
              toggleAutoShutdown={toggleAutoShutdown}
              resetSensor={resetSensor}
              getStatusIcon={getStatusIcon}
            />
          ))}
        </TabsContent>

        <TabsContent value="pressure" className="space-y-4">
          {filterSensors('pressure').map(sensor => (
            <SensorCard 
              key={sensor.id} 
              sensor={sensor}
              toggleSensor={toggleSensor}
              updateThreshold={updateThreshold}
              toggleAutoShutdown={toggleAutoShutdown}
              resetSensor={resetSensor}
              getStatusIcon={getStatusIcon}
            />
          ))}
        </TabsContent>
      </Tabs>
    </div>
  );
}

// Sensor Card Component
interface SensorCardProps {
  sensor: Sensor;
  toggleSensor: (id: string) => void;
  updateThreshold: (id: string, field: 'warning' | 'critical', value: string) => void;
  toggleAutoShutdown: (id: string) => void;
  resetSensor: (id: string) => void;
  getStatusIcon: (status: string) => React.ReactNode;
}

function SensorCard({ 
  sensor, 
  toggleSensor, 
  updateThreshold, 
  toggleAutoShutdown,
  resetSensor,
  getStatusIcon
}: SensorCardProps) {
  const [showControls, setShowControls] = useState(false);

  // Get appropriate color for the value based on thresholds
  const getValueColor = () => {
    if (sensor.value >= sensor.thresholds.critical) return "text-red-600";
    if (sensor.value >= sensor.thresholds.warning) return "text-amber-600";
    return "text-green-600";
  };

  // Get appropriate class for card border based on status
  const getCardBorderClass = () => {
    if (!sensor.isActive) return "border-l-4 border-l-gray-400";
    switch (sensor.status) {
      case 'online': return "border-l-4 border-l-green-500";
      case 'warning': return "border-l-4 border-l-amber-500";
      case 'error': return "border-l-4 border-l-red-500";
      case 'offline': return "border-l-4 border-l-gray-500";
      default: return "border-l-4 border-l-gray-400";
    }
  };

  // Get badge for sensor status
  const getStatusBadge = () => {
    if (!sensor.isActive) return "bg-gray-100 text-gray-800";
    switch (sensor.status) {
      case 'online': return "bg-green-100 text-green-800";
      case 'warning': return "bg-amber-100 text-amber-800";
      case 'error': return "bg-red-100 text-red-800";
      case 'offline': return "bg-gray-100 text-gray-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <Card className={cn(getCardBorderClass(), "overflow-hidden")}>
      <CardHeader className="pb-2">
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-2">
            <sensor.icon className={cn("h-5 w-5", sensor.isActive ? "" : "text-gray-400")} />
            <div>
              <CardTitle className="text-base">{sensor.name}</CardTitle>
              <CardDescription>{sensor.location}</CardDescription>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Badge className={getStatusBadge()}>
              {sensor.isActive ? sensor.status.toUpperCase() : "INACTIVE"}
            </Badge>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowControls(!showControls)}
            >
              <Settings className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Left column - sensor value and status */}
          <div className="space-y-4">
            <div className="flex items-center justify-center">
              <div className="text-center">
                <div className={cn("text-4xl font-bold", getValueColor())}>
                  {sensor.value} {sensor.unit}
                </div>
                <div className="text-sm text-muted-foreground mt-1">
                  Current Reading
                </div>
              </div>
            </div>
            
            <div className="space-y-2">
              {/* Show thresholds for non-relay sensors */}
              {sensor.type !== 'relay' && (
                <>
                  <div className="flex justify-between text-sm">
                    <span>Warning Threshold:</span>
                    <span className="text-amber-600">{sensor.thresholds.warning} {sensor.unit}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Critical Threshold:</span>
                    <span className="text-red-600">{sensor.thresholds.critical} {sensor.unit}</span>
                  </div>
                </>
              )}
              
              {/* Status indicators */}
              <div className="flex justify-between text-sm">
                <span>Last Update:</span>
                <span>{sensor.lastUpdate}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span>Auto Shutdown:</span>
                <span className={sensor.autoShutdown ? "text-green-600" : "text-gray-600"}>
                  {sensor.autoShutdown ? "Enabled" : "Disabled"}
                </span>
              </div>
              
              {/* Battery level if available */}
              {sensor.battery !== undefined && (
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Battery:</span>
                    <span className={
                      sensor.battery < 20 ? "text-red-600" : 
                      sensor.battery < 50 ? "text-amber-600" : 
                      "text-green-600"
                    }>
                      {Math.round(sensor.battery)}%
                    </span>
                  </div>
                  <Progress 
                    value={sensor.battery} 
                    className={sensor.battery < 20 ? "h-1.5 bg-red-100" : "h-1.5"}
                    style={{
                      '--progress-foreground': sensor.battery < 20 ? 'rgb(220, 38, 38)' : undefined
                    } as React.CSSProperties}
                  />
                </div>
              )}
              
              {/* Signal strength if available */}
              {sensor.signalStrength !== undefined && (
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Signal:</span>
                    <span className={
                      sensor.signalStrength < 20 ? "text-red-600" : 
                      sensor.signalStrength < 50 ? "text-amber-600" : 
                      "text-green-600"
                    }>
                      {Math.round(sensor.signalStrength)}%
                    </span>
                  </div>
                  <Progress 
                    value={sensor.signalStrength} 
                    className={sensor.signalStrength < 20 ? "h-1.5 bg-red-100" : "h-1.5"}
                    style={{
                      '--progress-foreground': sensor.signalStrength < 20 ? 'rgb(220, 38, 38)' : undefined
                    } as React.CSSProperties}
                  />
                </div>
              )}
            </div>
          </div>
          
          {/* Right column - controls (shown/hidden) */}
          <div className={showControls ? "space-y-4" : "hidden md:block space-y-4"}>
            <div className="space-y-2 border rounded-md p-3">
              <h3 className="font-medium text-sm">Sensor Controls</h3>
              
              {/* Power toggle */}
              <div className="flex items-center justify-between">
                <Label htmlFor={`toggle-${sensor.id}`} className="cursor-pointer">
                  {sensor.isActive ? "Active" : "Inactive"}
                </Label>
                <Switch
                  id={`toggle-${sensor.id}`}
                  checked={sensor.isActive}
                  onCheckedChange={() => toggleSensor(sensor.id)}
                  disabled={sensor.status === 'offline'}
                />
              </div>
              
              {/* Auto shutdown toggle */}
              <div className="flex items-center justify-between">
                <Label htmlFor={`auto-${sensor.id}`} className="cursor-pointer">
                  Auto Shutdown
                </Label>
                <Switch
                  id={`auto-${sensor.id}`}
                  checked={sensor.autoShutdown}
                  onCheckedChange={() => toggleAutoShutdown(sensor.id)}
                  disabled={sensor.status === 'offline'}
                />
              </div>
              
              {/* Threshold controls for non-relay sensors */}
              {sensor.type !== 'relay' && (
                <div className="grid grid-cols-2 gap-2 mt-3">
                  <div>
                    <Label htmlFor={`warning-${sensor.id}`} className="text-xs">
                      Warning at
                    </Label>
                    <Input
                      id={`warning-${sensor.id}`}
                      type="number"
                      value={sensor.thresholds.warning}
                      onChange={(e) => updateThreshold(sensor.id, 'warning', e.target.value)}
                      className="h-8 mt-1"
                      disabled={!sensor.isActive || sensor.status === 'offline'}
                    />
                  </div>
                  <div>
                    <Label htmlFor={`critical-${sensor.id}`} className="text-xs">
                      Critical at
                    </Label>
                    <Input
                      id={`critical-${sensor.id}`}
                      type="number"
                      value={sensor.thresholds.critical}
                      onChange={(e) => updateThreshold(sensor.id, 'critical', e.target.value)}
                      className="h-8 mt-1"
                      disabled={!sensor.isActive || sensor.status === 'offline'}
                    />
                  </div>
                </div>
              )}
            </div>
            
            {/* Status and actions */}
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-1">
                {getStatusIcon(sensor.status)}
                <span className="text-xs">
                  {sensor.isActive 
                    ? sensor.status === 'online' 
                      ? 'Normal operation' 
                      : sensor.status === 'warning' 
                        ? 'Needs attention' 
                        : sensor.status === 'error' 
                          ? 'Critical condition' 
                          : 'Disconnected'
                    : 'Powered off'
                  }
                </span>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={() => resetSensor(sensor.id)}
                disabled={sensor.status === 'offline'}
              >
                <Activity className="h-3 w-3 mr-1" />
                Reset
              </Button>
            </div>
          </div>
        </div>
      </CardContent>
      {showControls && (
        <CardFooter className="bg-muted/50 flex justify-end py-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setShowControls(false)}
          >
            Hide Controls
          </Button>
        </CardFooter>
      )}
    </Card>
  );
} 