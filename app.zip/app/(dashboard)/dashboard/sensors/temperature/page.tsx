"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Thermometer, AlertTriangle, Zap, RefreshCw, LineChart } from "lucide-react"
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend
} from "recharts"

export default function TemperatureSensorsPage() {
  // Temperature data for multiple sensors
  const [temperatureSensors, setTemperatureSensors] = useState([
    {
      id: 1,
      name: "Motor Temperature Sensor",
      location: "Main Motor Housing",
      currentTemp: 65,
      status: "warning",
      threshold: 75,
      warningThreshold: 65,
      history: [
        { time: "09:00", value: 58 },
        { time: "09:30", value: 61 },
        { time: "10:00", value: 63 },
        { time: "10:30", value: 67 },
        { time: "11:00", value: 65 },
        { time: "11:30", value: 64 },
        { time: "12:00", value: 65 },
      ],
      alerts: 1
    },
    {
      id: 2,
      name: "Ambient Temperature Sensor",
      location: "Control Box",
      currentTemp: 28,
      status: "normal",
      threshold: 45,
      warningThreshold: 35,
      history: [
        { time: "09:00", value: 26 },
        { time: "09:30", value: 27 },
        { time: "10:00", value: 28 },
        { time: "10:30", value: 29 },
        { time: "11:00", value: 29 },
        { time: "11:30", value: 28 },
        { time: "12:00", value: 28 },
      ],
      alerts: 0
    },
    {
      id: 3,
      name: "Power Circuit Temperature",
      location: "Power Distribution Unit",
      currentTemp: 42,
      status: "normal",
      threshold: 60,
      warningThreshold: 50,
      history: [
        { time: "09:00", value: 38 },
        { time: "09:30", value: 40 },
        { time: "10:00", value: 43 },
        { time: "10:30", value: 45 },
        { time: "11:00", value: 44 },
        { time: "11:30", value: 43 },
        { time: "12:00", value: 42 },
      ],
      alerts: 0
    }
  ])
  
  // Simulate temperature data updates
  useEffect(() => {
    const interval = setInterval(() => {
      setTemperatureSensors(prev => 
        prev.map(sensor => {
          // Random temperature variation between -2 and +2 degrees
          const variation = (Math.random() * 4) - 2;
          const newTemp = Math.max(20, Math.min(90, Math.round(sensor.currentTemp + variation)));
          
          // Update status based on new temperature
          let newStatus = "normal";
          if (newTemp >= sensor.threshold) newStatus = "critical";
          else if (newTemp >= sensor.warningThreshold) newStatus = "warning";
          
          // Update history with new value
          const newHistory = [...sensor.history];
          if (newHistory.length >= 12) {
            newHistory.shift(); // Remove oldest data point if we have 12 already
          }
          
          // Get current time for the new data point
          const now = new Date();
          const timeStr = `${now.getHours()}:${now.getMinutes().toString().padStart(2, '0')}`;
          
          newHistory.push({ time: timeStr, value: newTemp });
          
          // Increment alerts if status changed to critical
          const newAlerts = newStatus === "critical" && sensor.status !== "critical" 
            ? sensor.alerts + 1 
            : sensor.alerts;
          
          return {
            ...sensor,
            currentTemp: newTemp,
            status: newStatus,
            history: newHistory,
            alerts: newAlerts
          };
        })
      );
    }, 10000); // Update every 10 seconds
    
    return () => clearInterval(interval);
  }, []);
  
  // Update threshold for a sensor
  const updateThreshold = (id: number, field: 'threshold' | 'warningThreshold', value: string) => {
    const numValue = parseInt(value);
    if (isNaN(numValue)) return;
    
    setTemperatureSensors(prev => 
      prev.map(sensor => 
        sensor.id === id ? { ...sensor, [field]: numValue } : sensor
      )
    );
  };
  
  // Get status color
  const getStatusColor = (status: string) => {
    switch (status) {
      case "critical": return "bg-red-500";
      case "warning": return "bg-amber-500";
      default: return "bg-green-500";
    }
  };
  
  // Get status badge variant
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "critical": return "destructive";
      case "warning": return "warning";
      default: return "success";
    }
  };
  
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold tracking-tight">Temperature Sensors</h2>
        <Button variant="outline" size="sm" className="flex items-center gap-2">
          <RefreshCw className="h-4 w-4" />
          Refresh Data
        </Button>
      </div>
      
      <div className="grid gap-6 md:grid-cols-3">
        {temperatureSensors.map(sensor => (
          <Card key={sensor.id} className={`border-t-4 ${getStatusColor(sensor.status)}`}>
            <CardHeader className="pb-2">
              <div className="flex justify-between">
                <div>
                  <CardTitle className="text-lg">{sensor.name}</CardTitle>
                  <CardDescription>{sensor.location}</CardDescription>
                </div>
                <Badge variant={getStatusBadge(sensor.status) as any}>
                  {sensor.status.charAt(0).toUpperCase() + sensor.status.slice(1)}
                </Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-center py-4">
                <div className="relative flex items-center justify-center h-36 w-36 rounded-full border-8 border-muted">
                  <div className="text-3xl font-bold">
                    {sensor.currentTemp}°C
                  </div>
                  <Thermometer 
                    className={`absolute bottom-0 h-8 w-8 ${
                      sensor.status === "critical" ? "text-red-500" : 
                      sensor.status === "warning" ? "text-amber-500" : 
                      "text-green-500"
                    }`} 
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4 mt-4">
                <div>
                  <Label htmlFor={`threshold-${sensor.id}`}>Critical Threshold</Label>
                  <div className="flex items-center gap-2">
                    <Input 
                      id={`threshold-${sensor.id}`}
                      type="number" 
                      value={sensor.threshold}
                      onChange={(e) => updateThreshold(sensor.id, 'threshold', e.target.value)}
                      className="w-20"
                    />
                    <span>°C</span>
                    <AlertTriangle 
                      className={`h-4 w-4 ${
                        sensor.currentTemp >= sensor.threshold ? "text-red-500" : "text-muted-foreground"
                      }`} 
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor={`warning-${sensor.id}`}>Warning Threshold</Label>
                  <div className="flex items-center gap-2">
                    <Input 
                      id={`warning-${sensor.id}`}
                      type="number" 
                      value={sensor.warningThreshold}
                      onChange={(e) => updateThreshold(sensor.id, 'warningThreshold', e.target.value)}
                      className="w-20"
                    />
                    <span>°C</span>
                    <AlertTriangle 
                      className={`h-4 w-4 ${
                        sensor.currentTemp >= sensor.warningThreshold ? "text-amber-500" : "text-muted-foreground"
                      }`} 
                    />
                  </div>
                </div>
              </div>
              
              {/* Temperature Chart */}
              <div className="h-[140px] mt-4">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart
                    data={sensor.history}
                    margin={{ top: 5, right: 0, left: -20, bottom: 0 }}
                  >
                    <defs>
                      <linearGradient id={`colorTemp${sensor.id}`} x1="0" y1="0" x2="0" y2="1">
                        <stop 
                          offset="5%" 
                          stopColor={
                            sensor.status === "critical" ? "#ef4444" : 
                            sensor.status === "warning" ? "#f59e0b" : 
                            "#10b981"
                          } 
                          stopOpacity={0.8}
                        />
                        <stop 
                          offset="95%" 
                          stopColor={
                            sensor.status === "critical" ? "#ef4444" : 
                            sensor.status === "warning" ? "#f59e0b" : 
                            "#10b981"
                          } 
                          stopOpacity={0}
                        />
                      </linearGradient>
                    </defs>
                    <XAxis dataKey="time" tick={{ fontSize: 10 }} />
                    <YAxis 
                      domain={[
                        Math.floor(Math.min(...sensor.history.map(h => h.value)) * 0.9), 
                        Math.ceil(Math.max(...sensor.history.map(h => h.value)) * 1.1)
                      ]} 
                      tick={{ fontSize: 10 }}
                    />
                    <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                    <Tooltip 
                      formatter={(value) => [`${value}°C`, 'Temperature']}
                      contentStyle={{
                        backgroundColor: '#ffffff',
                        border: '1px solid #e2e8f0',
                        borderRadius: '6px',
                        fontSize: '12px'
                      }}
                    />
                    <Area 
                      type="monotone" 
                      dataKey="value" 
                      stroke={
                        sensor.status === "critical" ? "#ef4444" : 
                        sensor.status === "warning" ? "#f59e0b" : 
                        "#10b981"
                      } 
                      fillOpacity={1} 
                      fill={`url(#colorTemp${sensor.id})`} 
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
              
              <div className="flex items-center justify-between mt-4 text-xs text-muted-foreground">
                <div className="flex items-center gap-1">
                  <Zap className="h-3 w-3" />
                  <span>Real-time updates</span>
                </div>
                <div className="flex items-center gap-1">
                  <LineChart className="h-3 w-3" />
                  <Button variant="link" size="sm" className="p-0 h-auto text-xs">
                    View full history
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>Temperature Alert Settings</CardTitle>
          <CardDescription>Configure global alert settings for all temperature sensors</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="email-alerts">Email Alerts</Label>
                <p className="text-xs text-muted-foreground">
                  Send email notifications on critical temperature events
                </p>
              </div>
              <Switch id="email-alerts" defaultChecked />
            </div>
            
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="auto-cooling">Automatic Cooling</Label>
                <p className="text-xs text-muted-foreground">
                  Activate cooling system when temperature exceeds thresholds
                </p>
              </div>
              <Switch id="auto-cooling" defaultChecked />
            </div>
            
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="emergency-shutdown">Emergency Shutdown</Label>
                <p className="text-xs text-muted-foreground">
                  Automatically shut down system on extreme temperatures
                </p>
              </div>
              <Switch id="emergency-shutdown" defaultChecked />
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
} 