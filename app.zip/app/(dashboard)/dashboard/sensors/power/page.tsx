"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { 
  Battery, 
  Zap, 
  AlertTriangle, 
  BatteryCharging, 
  RefreshCw, 
  LineChart, 
  Clock, 
  Bolt,
  Power
} from "lucide-react"
import {
  LineChart as RechartsLineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Area,
  AreaChart,
  Legend,
  PieChart,
  Pie,
  Cell
} from "recharts"

export default function PowerMonitoringPage() {
  // Power data
  const [powerData, setPowerData] = useState({
    voltage: 220,
    current: 10.5,
    power: 2310,
    frequency: 50,
    powerFactor: 0.92,
    energyToday: 18.4,
    energyMonth: 423,
    peakPower: 2800,
    batteryLevel: 85,
    thresholds: {
      highVoltage: 240,
      lowVoltage: 200,
      highCurrent: 15,
      highPower: 3000
    },
    alerts: [
      { id: 1, title: "High Current Detected", time: "09:45", value: "16.2A", severity: "warning" },
      { id: 2, title: "Power Consumption Peak", time: "Yesterday 15:30", value: "2850W", severity: "info" }
    ],
    history: {
      voltage: [
        { time: "08:00", value: 218 },
        { time: "09:00", value: 220 },
        { time: "10:00", value: 222 },
        { time: "11:00", value: 225 },
        { time: "12:00", value: 223 },
        { time: "13:00", value: 220 },
        { time: "14:00", value: 219 },
        { time: "15:00", value: 220 }
      ],
      current: [
        { time: "08:00", value: 8.5 },
        { time: "09:00", value: 9.2 },
        { time: "10:00", value: 10.8 },
        { time: "11:00", value: 12.5 },
        { time: "12:00", value: 11.3 },
        { time: "13:00", value: 10.5 },
        { time: "14:00", value: 9.8 },
        { time: "15:00", value: 10.5 }
      ],
      power: [
        { time: "08:00", value: 1850 },
        { time: "09:00", value: 2024 },
        { time: "10:00", value: 2398 },
        { time: "11:00", value: 2812 },
        { time: "12:00", value: 2520 },
        { time: "13:00", value: 2310 },
        { time: "14:00", value: 2150 },
        { time: "15:00", value: 2310 }
      ]
    },
    distribution: [
      { name: "Motor", value: 45 },
      { name: "Control Systems", value: 25 },
      { name: "Lighting", value: 15 },
      { name: "Other", value: 15 }
    ]
  })
  
  // Simulate power data updates
  useEffect(() => {
    const interval = setInterval(() => {
      setPowerData(prev => {
        // Random variations
        const voltageVariation = (Math.random() * 8) - 4;  // -4 to +4V
        const currentVariation = (Math.random() * 2) - 1;  // -1 to +1A
        
        const newVoltage = Math.round((prev.voltage + voltageVariation) * 10) / 10;
        const newCurrent = Math.round((prev.current + currentVariation) * 10) / 10;
        const newPower = Math.round(newVoltage * newCurrent);
        
        // Update history
        const now = new Date();
        const timeStr = `${now.getHours()}:${now.getMinutes().toString().padStart(2, '0')}`;
        
        const newVoltageHistory = [...prev.history.voltage];
        const newCurrentHistory = [...prev.history.current];
        const newPowerHistory = [...prev.history.power];
        
        if (newVoltageHistory.length >= 12) {
          newVoltageHistory.shift();
          newCurrentHistory.shift();
          newPowerHistory.shift();
        }
        
        newVoltageHistory.push({ time: timeStr, value: newVoltage });
        newCurrentHistory.push({ time: timeStr, value: newCurrent });
        newPowerHistory.push({ time: timeStr, value: newPower });
        
        // Check for new alerts
        let newAlerts = [...prev.alerts];
        if (newVoltage > prev.thresholds.highVoltage && Math.random() > 0.7) {
          newAlerts.unshift({
            id: Date.now(),
            title: "High Voltage Alert",
            time: timeStr,
            value: `${newVoltage}V`,
            severity: "warning"
          });
        }
        
        if (newCurrent > prev.thresholds.highCurrent && Math.random() > 0.7) {
          newAlerts.unshift({
            id: Date.now(),
            title: "High Current Alert",
            time: timeStr,
            value: `${newCurrent}A`,
            severity: "warning"
          });
        }
        
        // Keep only the 5 most recent alerts
        newAlerts = newAlerts.slice(0, 5);
        
        return {
          ...prev,
          voltage: newVoltage,
          current: newCurrent,
          power: newPower,
          history: {
            voltage: newVoltageHistory,
            current: newCurrentHistory,
            power: newPowerHistory
          },
          alerts: newAlerts
        };
      });
    }, 8000); // Update every 8 seconds
    
    return () => clearInterval(interval);
  }, []);
  
  // Update threshold
  const updateThreshold = (field: keyof typeof powerData.thresholds, value: string) => {
    const numValue = parseFloat(value);
    if (isNaN(numValue)) return;
    
    setPowerData(prev => ({
      ...prev,
      thresholds: {
        ...prev.thresholds,
        [field]: numValue
      }
    }));
  };
  
  // Emergency halt function
  const emergencyHalt = () => {
    alert("EMERGENCY HALT ACTIVATED: All systems powered down");
    // In a real system, this would send commands to shut down all power systems
  };
  
  // Alert severity colors
  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "critical": return "bg-red-500 text-white";
      case "warning": return "bg-amber-100 text-amber-800";
      case "info": return "bg-blue-100 text-blue-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };
  
  // Colors for charts and distribution
  const COLORS = ["#0ea5e9", "#8b5cf6", "#f59e0b", "#10b981"];
  
  return (
    <div className="space-y-6">
      {/* Emergency Halt Button */}
      <div className="sticky top-0 z-10 bg-white dark:bg-gray-950 py-2 border-b mb-4">
        <div className="flex items-center justify-between">
          <h2 className="text-3xl font-bold tracking-tight">Power Monitoring</h2>
          <Button 
            variant="destructive" 
            size="lg" 
            className="flex items-center gap-2 shadow-lg"
            onClick={emergencyHalt}
          >
            <Power className="h-5 w-5" />
            EMERGENCY HALT
          </Button>
        </div>
      </div>
      
      <Tabs defaultValue="overview">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="history">Historical Data</TabsTrigger>
          <TabsTrigger value="alerts">Alerts</TabsTrigger>
          <TabsTrigger value="settings">Settings</TabsTrigger>
        </TabsList>
        
        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-6">
          {/* Key Metrics */}
          <div className="grid gap-6 md:grid-cols-3">
            {/* Voltage Card */}
            <Card className={
              powerData.voltage > powerData.thresholds.highVoltage || 
              powerData.voltage < powerData.thresholds.lowVoltage
                ? "border-t-4 border-t-amber-500"
                : "border-t-4 border-t-green-500"
            }>
              <CardHeader className="pb-2">
                <div className="flex justify-between">
                  <div>
                    <CardTitle className="text-lg">Voltage</CardTitle>
                    <CardDescription>Current supply voltage</CardDescription>
                  </div>
                  <Zap className="h-5 w-5 text-blue-500" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col items-center justify-center py-4">
                  <div className="text-4xl font-bold">{powerData.voltage} V</div>
                  <div className="text-sm text-muted-foreground">AC Voltage</div>
                </div>
                
                <div className="mt-4">
                  <div className="flex justify-between text-sm mb-1">
                    <span>Range: {powerData.thresholds.lowVoltage}V - {powerData.thresholds.highVoltage}V</span>
                    <span className={
                      powerData.voltage > powerData.thresholds.highVoltage 
                        ? "text-red-500" 
                        : powerData.voltage < powerData.thresholds.lowVoltage 
                          ? "text-red-500" 
                          : "text-green-500"
                    }>
                      {
                        powerData.voltage > powerData.thresholds.highVoltage 
                          ? "High" 
                          : powerData.voltage < powerData.thresholds.lowVoltage 
                            ? "Low" 
                            : "Normal"
                      }
                    </span>
                  </div>
                  <Progress 
                    value={((powerData.voltage - 100) / 200) * 100} 
                    className="h-2" 
                  />
                  <div className="flex justify-between text-xs mt-1">
                    <span>100V</span>
                    <span>200V</span>
                    <span>300V</span>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            {/* Current Card */}
            <Card className={
              powerData.current > powerData.thresholds.highCurrent
                ? "border-t-4 border-t-amber-500"
                : "border-t-4 border-t-green-500"
            }>
              <CardHeader className="pb-2">
                <div className="flex justify-between">
                  <div>
                    <CardTitle className="text-lg">Current</CardTitle>
                    <CardDescription>Amperage consumption</CardDescription>
                  </div>
                  <Bolt className="h-5 w-5 text-purple-500" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col items-center justify-center py-4">
                  <div className="text-4xl font-bold">{powerData.current} A</div>
                  <div className="text-sm text-muted-foreground">AC Current</div>
                </div>
                
                <div className="mt-4">
                  <div className="flex justify-between text-sm mb-1">
                    <span>Max: {powerData.thresholds.highCurrent}A</span>
                    <span className={
                      powerData.current > powerData.thresholds.highCurrent
                        ? "text-red-500" 
                        : "text-green-500"
                    }>
                      {
                        powerData.current > powerData.thresholds.highCurrent
                          ? "High" 
                          : "Normal"
                      }
                    </span>
                  </div>
                  <Progress 
                    value={(powerData.current / 20) * 100} 
                    className="h-2" 
                  />
                  <div className="flex justify-between text-xs mt-1">
                    <span>0A</span>
                    <span>10A</span>
                    <span>20A</span>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            {/* Power Card */}
            <Card className={
              powerData.power > powerData.thresholds.highPower
                ? "border-t-4 border-t-amber-500"
                : "border-t-4 border-t-green-500"
            }>
              <CardHeader className="pb-2">
                <div className="flex justify-between">
                  <div>
                    <CardTitle className="text-lg">Power</CardTitle>
                    <CardDescription>Active power consumption</CardDescription>
                  </div>
                  <BatteryCharging className="h-5 w-5 text-green-500" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col items-center justify-center py-4">
                  <div className="text-4xl font-bold">{powerData.power} W</div>
                  <div className="text-sm text-muted-foreground">Real-time power</div>
                </div>
                
                <div className="mt-4">
                  <div className="flex justify-between text-sm mb-1">
                    <span>Max: {powerData.thresholds.highPower}W</span>
                    <span className={
                      powerData.power > powerData.thresholds.highPower
                        ? "text-red-500" 
                        : "text-green-500"
                    }>
                      {
                        powerData.power > powerData.thresholds.highPower
                          ? "High" 
                          : "Normal"
                      }
                    </span>
                  </div>
                  <Progress 
                    value={(powerData.power / 4000) * 100} 
                    className="h-2"
                  />
                  <div className="flex justify-between text-xs mt-1">
                    <span>0W</span>
                    <span>2000W</span>
                    <span>4000W</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
          
          {/* Power Chart */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base font-medium">Power Trend (Last 8 hours)</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart
                    data={powerData.history.power}
                    margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
                  >
                    <defs>
                      <linearGradient id="colorPower" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.8}/>
                        <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                    <XAxis dataKey="time" tick={{ fontSize: 12 }} />
                    <YAxis tick={{ fontSize: 12 }} />
                    <Tooltip 
                      formatter={(value) => [`${value} W`, 'Power']}
                      contentStyle={{
                        backgroundColor: '#ffffff',
                        border: '1px solid #e2e8f0',
                        borderRadius: '6px'
                      }}
                    />
                    <Area 
                      type="monotone" 
                      dataKey="value" 
                      stroke="#8b5cf6" 
                      fillOpacity={1} 
                      fill="url(#colorPower)" 
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Historical Data Tab */}
        <TabsContent value="history">
          <Card>
            <CardHeader>
              <CardTitle>Power History</CardTitle>
              <CardDescription>Historical data for power parameters</CardDescription>
            </CardHeader>
            <CardContent className="space-y-8">
              {/* Voltage History */}
              <div>
                <h3 className="text-lg font-medium mb-4">Voltage History</h3>
                <div className="h-[250px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <RechartsLineChart
                      data={powerData.history.voltage}
                      margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                      <XAxis dataKey="time" />
                      <YAxis domain={[200, 240]} />
                      <Tooltip 
                        formatter={(value) => [`${value} V`, 'Voltage']}
                        contentStyle={{
                          backgroundColor: '#ffffff',
                          border: '1px solid #e2e8f0',
                          borderRadius: '6px'
                        }}
                      />
                      <Line 
                        type="monotone" 
                        dataKey="value" 
                        stroke="#0ea5e9" 
                        strokeWidth={2}
                        dot={{ stroke: '#0ea5e9', strokeWidth: 2, r: 4 }}
                        activeDot={{ r: 6 }}
                      />
                    </RechartsLineChart>
                  </ResponsiveContainer>
                </div>
              </div>
              
              {/* Current History */}
              <div>
                <h3 className="text-lg font-medium mb-4">Current History</h3>
                <div className="h-[250px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <RechartsLineChart
                      data={powerData.history.current}
                      margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                      <XAxis dataKey="time" />
                      <YAxis domain={[0, 15]} />
                      <Tooltip 
                        formatter={(value) => [`${value} A`, 'Current']}
                        contentStyle={{
                          backgroundColor: '#ffffff',
                          border: '1px solid #e2e8f0',
                          borderRadius: '6px'
                        }}
                      />
                      <Line 
                        type="monotone" 
                        dataKey="value" 
                        stroke="#8b5cf6" 
                        strokeWidth={2}
                        dot={{ stroke: '#8b5cf6', strokeWidth: 2, r: 4 }}
                        activeDot={{ r: 6 }}
                      />
                    </RechartsLineChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Alerts Tab */}
        <TabsContent value="alerts">
          <Card>
            <CardHeader>
              <CardTitle>Power Alerts</CardTitle>
              <CardDescription>Recent alerts and notifications</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {powerData.alerts.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    No alerts at this time
                  </div>
                ) : (
                  powerData.alerts.map(alert => (
                    <div 
                      key={alert.id} 
                      className={`rounded-md p-4 ${getSeverityColor(alert.severity)}`}
                    >
                      <div className="flex items-start gap-4">
                        <AlertTriangle className="h-5 w-5" />
                        <div className="space-y-1 flex-1">
                          <div className="flex items-center justify-between">
                            <p className="font-medium">{alert.title}</p>
                            <Badge variant="outline" className="text-xs">
                              {alert.value}
                            </Badge>
                          </div>
                          <div className="flex items-center text-xs">
                            <Clock className="mr-1 h-3 w-3" />
                            <span>{alert.time}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Settings Tab */}
        <TabsContent value="settings">
          <Card>
            <CardHeader>
              <CardTitle>Power Monitoring Settings</CardTitle>
              <CardDescription>Configure thresholds and alerts</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="high-voltage">High Voltage Threshold (V)</Label>
                    <Input
                      id="high-voltage"
                      type="number"
                      value={powerData.thresholds.highVoltage}
                      onChange={(e) => updateThreshold('highVoltage', e.target.value)}
                    />
                    <p className="text-xs text-muted-foreground">
                      Alert when voltage exceeds this value
                    </p>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="low-voltage">Low Voltage Threshold (V)</Label>
                    <Input
                      id="low-voltage"
                      type="number"
                      value={powerData.thresholds.lowVoltage}
                      onChange={(e) => updateThreshold('lowVoltage', e.target.value)}
                    />
                    <p className="text-xs text-muted-foreground">
                      Alert when voltage drops below this value
                    </p>
                  </div>
                </div>
                
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="high-current">High Current Threshold (A)</Label>
                    <Input
                      id="high-current"
                      type="number"
                      value={powerData.thresholds.highCurrent}
                      onChange={(e) => updateThreshold('highCurrent', e.target.value)}
                    />
                    <p className="text-xs text-muted-foreground">
                      Alert when current exceeds this value
                    </p>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="high-power">High Power Threshold (W)</Label>
                    <Input
                      id="high-power"
                      type="number"
                      value={powerData.thresholds.highPower}
                      onChange={(e) => updateThreshold('highPower', e.target.value)}
                    />
                    <p className="text-xs text-muted-foreground">
                      Alert when power exceeds this value
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button>Save Settings</Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
} 