"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Slider } from "@/components/ui/slider"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ToggleLeft, AlertTriangle, Power, History, Activity } from "lucide-react"
import { Progress } from "@/components/ui/progress"

export default function RelayControlPage() {
  // State for relay modules
  const [relays, setRelays] = useState([
    { 
      id: 1, 
      name: "Main Relay Module (5V/12V)", 
      status: true, 
      autoShutdown: true,
      threshold: 50,
      lastTriggered: "Never",
      voltage: 5.2,
      current: 0.1,
      temperature: 28
    },
    { 
      id: 2, 
      name: "Secondary Relay Module", 
      status: false, 
      autoShutdown: true,
      threshold: 60,
      lastTriggered: "2 hours ago",
      voltage: 11.8,
      current: 0,
      temperature: 25
    }
  ])
  
  // Toggle relay status
  const toggleRelayStatus = (id: number) => {
    setRelays(relays.map(relay => 
      relay.id === id ? { ...relay, status: !relay.status } : relay
    ))
  }
  
  // Toggle auto shutdown
  const toggleAutoShutdown = (id: number) => {
    setRelays(relays.map(relay => 
      relay.id === id ? { ...relay, autoShutdown: !relay.autoShutdown } : relay
    ))
  }
  
  // Update threshold
  const updateThreshold = (id: number, value: number[]) => {
    setRelays(relays.map(relay => 
      relay.id === id ? { ...relay, threshold: value[0] } : relay
    ))
  }
  
  // Emergency halt all relays
  const emergencyHalt = () => {
    setRelays(relays.map(relay => ({ ...relay, status: false })))
  }
  
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold tracking-tight">Relay Control</h2>
        <Button variant="destructive" onClick={emergencyHalt} className="flex items-center gap-2">
          <Power className="h-4 w-4" />
          Emergency Halt
        </Button>
      </div>
      
      <Tabs defaultValue="control">
        <TabsList>
          <TabsTrigger value="control">Control Panel</TabsTrigger>
          <TabsTrigger value="logs">Event Logs</TabsTrigger>
          <TabsTrigger value="settings">Settings</TabsTrigger>
        </TabsList>
        <TabsContent value="control" className="space-y-4">
          {relays.map(relay => (
            <Card key={relay.id} className={relay.status ? "border-l-4 border-l-green-500" : "border-l-4 border-l-gray-300"}>
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>{relay.name}</CardTitle>
                    <CardDescription>Control relay power and monitor status</CardDescription>
                  </div>
                  <Badge variant={relay.status ? "default" : "outline"}>
                    {relay.status ? "ON" : "OFF"}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid gap-6 md:grid-cols-2">
                  {/* Relay Status */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label htmlFor={`status-${relay.id}`}>Relay Status</Label>
                      <Switch 
                        id={`status-${relay.id}`} 
                        checked={relay.status}
                        onCheckedChange={() => toggleRelayStatus(relay.id)}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <Label htmlFor={`auto-${relay.id}`}>Auto Shutdown</Label>
                      <Switch 
                        id={`auto-${relay.id}`} 
                        checked={relay.autoShutdown}
                        onCheckedChange={() => toggleAutoShutdown(relay.id)}
                      />
                    </div>
                    <div className="pt-2">
                      <Label htmlFor={`threshold-${relay.id}`}>Threshold ({relay.threshold}°C)</Label>
                      <Slider
                        id={`threshold-${relay.id}`}
                        defaultValue={[relay.threshold]}
                        max={100}
                        step={1}
                        disabled={!relay.autoShutdown}
                        onValueChange={(value) => updateThreshold(relay.id, value)}
                        className="py-4"
                      />
                      <div className="flex text-xs justify-between">
                        <span>0°C</span>
                        <span>50°C</span>
                        <span>100°C</span>
                      </div>
                    </div>
                  </div>
                  
                  {/* Relay Metrics */}
                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span>Voltage: {relay.voltage}V</span>
                        <span className={relay.voltage > 12 ? "text-red-500" : "text-green-500"}>
                          {relay.voltage > 12 ? "High" : "Normal"}
                        </span>
                      </div>
                      <Progress value={(relay.voltage / 15) * 100} className="h-2" />
                    </div>
                    
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span>Current: {relay.current}A</span>
                        <span className={relay.current > 1 ? "text-red-500" : "text-green-500"}>
                          {relay.current > 1 ? "High" : "Normal"}
                        </span>
                      </div>
                      <Progress value={(relay.current / 2) * 100} className="h-2" />
                    </div>
                    
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span>Temperature: {relay.temperature}°C</span>
                        <span className={
                          relay.temperature > relay.threshold ? "text-red-500" : 
                          relay.temperature > relay.threshold * 0.8 ? "text-amber-500" : "text-green-500"
                        }>
                          {
                            relay.temperature > relay.threshold ? "Critical" : 
                            relay.temperature > relay.threshold * 0.8 ? "Warning" : "Normal"
                          }
                        </span>
                      </div>
                      <Progress 
                        value={(relay.temperature / 100) * 100} 
                        className="h-2"
                        style={{
                          backgroundColor: relay.temperature > relay.threshold * 0.8 ? "#fef3c7" : undefined
                        }}
                      />
                    </div>
                    
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <History className="h-4 w-4" />
                      <span>Last triggered: {relay.lastTriggered}</span>
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="border-t pt-4">
                <div className="flex justify-between w-full text-sm">
                  <Button variant="outline" size="sm" className="flex items-center gap-1">
                    <Activity className="h-3 w-3" />
                    View History
                  </Button>
                  <div className="flex items-center gap-1 text-muted-foreground">
                    <AlertTriangle className="h-4 w-4 text-amber-500" />
                    {relay.autoShutdown ? `Will auto-shutdown at ${relay.threshold}°C` : "Auto-shutdown disabled"}
                  </div>
                </div>
              </CardFooter>
            </Card>
          ))}
        </TabsContent>
        
        <TabsContent value="logs">
          <Card>
            <CardHeader>
              <CardTitle>Event Logs</CardTitle>
              <CardDescription>Recent relay events and triggers</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="rounded-md bg-muted p-4">
                  <div className="flex items-start gap-4">
                    <div className="rounded-full bg-green-100 p-2">
                      <Power className="h-4 w-4 text-green-600" />
                    </div>
                    <div className="space-y-1">
                      <p className="text-sm font-medium">Secondary Relay Module turned OFF</p>
                      <p className="text-xs text-muted-foreground">2 hours ago · Manual operation</p>
                    </div>
                  </div>
                </div>
                
                <div className="rounded-md bg-muted p-4">
                  <div className="flex items-start gap-4">
                    <div className="rounded-full bg-amber-100 p-2">
                      <AlertTriangle className="h-4 w-4 text-amber-600" />
                    </div>
                    <div className="space-y-1">
                      <p className="text-sm font-medium">Temperature threshold warning</p>
                      <p className="text-xs text-muted-foreground">3 hours ago · Main Relay Module · 48°C</p>
                    </div>
                  </div>
                </div>
                
                <div className="rounded-md bg-muted p-4">
                  <div className="flex items-start gap-4">
                    <div className="rounded-full bg-green-100 p-2">
                      <Power className="h-4 w-4 text-green-600" />
                    </div>
                    <div className="space-y-1">
                      <p className="text-sm font-medium">Main Relay Module turned ON</p>
                      <p className="text-xs text-muted-foreground">5 hours ago · Manual operation</p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="settings">
          <Card>
            <CardHeader>
              <CardTitle>Relay Settings</CardTitle>
              <CardDescription>Configure global relay settings</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid gap-2">
                  <Label htmlFor="timeout">Auto-shutdown Timeout (seconds)</Label>
                  <Input id="timeout" type="number" defaultValue={10} />
                  <p className="text-xs text-muted-foreground">
                    Time to wait before shutting down after threshold is reached
                  </p>
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="notify">Alert Notifications</Label>
                    <p className="text-xs text-muted-foreground">
                      Send notifications when relays change state
                    </p>
                  </div>
                  <Switch id="notify" defaultChecked />
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="failsafe">Failsafe Mode</Label>
                    <p className="text-xs text-muted-foreground">
                      Automatically turn off relays on system errors
                    </p>
                  </div>
                  <Switch id="failsafe" defaultChecked />
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button>Save Settings</Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
} 