"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { getSupabaseClient, supabase } from "@/lib/supabase/client"
import { AlertCircle, AlertTriangle, Bell, Calendar, Check, Download, Filter, Info, Search, X } from "lucide-react"
import { CraneSelector } from "@/components/dashboard/crane-selector"
import { cn } from "@/lib/utils"
import { format } from "date-fns"

interface Alert {
  id: string
  alert_type: string
  severity: string
  message: string
  timestamp: string
  acknowledged: boolean
  category?: string
  related_to?: string
  crane_id: string
}

export default function AlertsPage() {
  const [selectedCrane, setSelectedCrane] = useState<string | null>(null)
  const [cranes, setCranes] = useState<any[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [alerts, setAlerts] = useState<Alert[]>([
    {
      id: "1",
      alert_type: "Fuel Level Critical",
      severity: "critical",
      message: "Fuel level at 10%. Immediate refueling required to prevent system shutdown.",
      timestamp: new Date(Date.now() - 15 * 60 * 1000).toISOString(), // 15 mins ago
      acknowledged: false,
      category: "Fuel System",
      related_to: "Fuel Tank",
      crane_id: "CRANE-001"
    },
    {
      id: "2",
      alert_type: "High Energy Usage",
      severity: "warning",
      message: "Energy consumption 30% above baseline. Check for system inefficiencies.",
      timestamp: new Date(Date.now() - 45 * 60 * 1000).toISOString(), // 45 mins ago
      acknowledged: false,
      category: "Energy Optimization",
      related_to: "Main Motor",
      crane_id: "CRANE-001"
    },
    {
      id: "3",
      alert_type: "Hydraulic Pressure Low",
      severity: "warning",
      message: "Hydraulic system pressure below optimal range (150 bar). Check for leaks.",
      timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(), // 2 hours ago
      acknowledged: false,
      category: "Mechanical",
      related_to: "Hydraulic System",
      crane_id: "CRANE-001"
    },
    {
      id: "4",
      alert_type: "Brake Pad Wear",
      severity: "info",
      message: "Brake pad wear at 70%. Plan replacement within next maintenance cycle.",
      timestamp: new Date(Date.now() - 3 * 60 * 60 * 1000).toISOString(), // 3 hours ago
      acknowledged: true,
      category: "Mechanical",
      related_to: "Brake System",
      crane_id: "CRANE-001"
    },
    {
      id: "5",
      alert_type: "Wind Speed Alert",
      severity: "critical",
      message: "Wind speed exceeding safe operation limit (25 m/s). Cease operations immediately.",
      timestamp: new Date(Date.now() - 10 * 60 * 1000).toISOString(), // 10 mins ago
      acknowledged: false,
      category: "Safety",
      related_to: "Weather Monitoring",
      crane_id: "CRANE-001"
    },
    {
      id: "6",
      alert_type: "Oil Temperature High",
      severity: "warning",
      message: "Hydraulic oil temperature at 65°C. Monitor system for overheating.",
      timestamp: new Date(Date.now() - 90 * 60 * 1000).toISOString(), // 1.5 hours ago
      acknowledged: false,
      category: "Mechanical",
      related_to: "Hydraulic System",
      crane_id: "CRANE-001"
    },
    {
      id: "7",
      alert_type: "Battery Low",
      severity: "info",
      message: "Backup battery at 30% capacity. Consider charging during next maintenance.",
      timestamp: new Date(Date.now() - 5 * 60 * 60 * 1000).toISOString(), // 5 hours ago
      acknowledged: true,
      category: "Electrical",
      related_to: "Power System",
      crane_id: "CRANE-001"
    },
    {
      id: "8",
      alert_type: "Load Cell Error",
      severity: "critical",
      message: "Load cell readings inconsistent. Safety systems compromised.",
      timestamp: new Date(Date.now() - 25 * 60 * 1000).toISOString(), // 25 mins ago
      acknowledged: false,
      category: "Safety",
      related_to: "Load Monitoring",
      crane_id: "CRANE-001"
    },
    {
      id: "9",
      alert_type: "Motor Efficiency Low",
      severity: "warning",
      message: "Main motor efficiency dropped to 85%. Energy consumption increased.",
      timestamp: new Date(Date.now() - 4 * 60 * 60 * 1000).toISOString(), // 4 hours ago
      acknowledged: false,
      category: "Energy Optimization",
      related_to: "Main Motor",
      crane_id: "CRANE-001"
    },
    {
      id: "10",
      alert_type: "Maintenance Reminder",
      severity: "info",
      message: "Scheduled maintenance due in 3 days. Check maintenance schedule.",
      timestamp: new Date(Date.now() - 6 * 60 * 60 * 1000).toISOString(), // 6 hours ago
      acknowledged: true,
      category: "Operational",
      related_to: "System Maintenance",
      crane_id: "CRANE-001"
    }
  ])
  const [filteredAlerts, setFilteredAlerts] = useState<Alert[]>([])
  const [searchQuery, setSearchQuery] = useState("")
  const [severityFilter, setSeverityFilter] = useState<string>("all")
  const [categoryFilter, setCategoryFilter] = useState<string>("all")
  const [statusFilter, setStatusFilter] = useState<string>("all")
  const [timeRange, setTimeRange] = useState<string>("24h")

  useEffect(() => {
    const fetchCranes = async () => {
      try {
        // Use dummy crane data instead of fetching from Supabase
        const dummyCranes = [
          {
            id: "CRANE-001",
            name: "HC-5000",
            model: "HC-5000",
            location: "Port A"
          },
          {
            id: "CRANE-002",
            name: "HC-6000",
            model: "HC-6000",
            location: "Port B"
          }
        ];

        setCranes(dummyCranes)
        setSelectedCrane(dummyCranes[0].id)
        setIsLoading(false)
      } catch (err) {
        console.error("Error setting up cranes:", err)
        setIsLoading(false)
      }
    }

    fetchCranes()
  }, [])

  useEffect(() => {
    if (!selectedCrane) return

    const fetchAlerts = async () => {
      try {
        // Comment out the Supabase fetch to keep dummy data
        /*const { data, error } = await supabase
          .from("alerts")
          .select("*")
          .eq("crane_id", selectedCrane)
          .order("timestamp", { ascending: false })

        if (error) {
          console.error("Error fetching alerts:", error)
          return
        }*/

        // Instead of fetching, just use the initial alerts
        setFilteredAlerts(alerts)
      } catch (err) {
        console.error("Error fetching alerts:", err)
      }
    }

    fetchAlerts()

    // Comment out the real-time subscription since we're using dummy data
    /*const subscription = supabase
      .channel("alerts-changes")
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "alerts",
          filter: `crane_id=eq.${selectedCrane}`,
        },
        (payload) => {
          const newAlert = {
            ...(payload.new as Alert),
            category: getRandomCategory(),
            related_to: getRandomComponent(),
          }
          setAlerts((prev) => [newAlert, ...prev])
          applyFilters([newAlert, ...alerts], searchQuery, severityFilter, categoryFilter, statusFilter, timeRange)
        },
      )
      .subscribe()

    return () => {
      subscription.unsubscribe()
    }*/
  }, [selectedCrane])

  // Helper functions for mock data
  const getRandomCategory = () => {
    const categories = ["Fuel System", "Energy Optimization", "Electrical", "Mechanical", "Safety", "Operational"]
    return categories[Math.floor(Math.random() * categories.length)]
  }

  const getRandomComponent = () => {
    const components = ["Engine", "Motor", "Hydraulic System", "Control Panel", "Brakes", "Hoist", "Fuel Pump"]
    return components[Math.floor(Math.random() * components.length)]
  }

  // Apply filters when any filter changes
  useEffect(() => {
    applyFilters(alerts, searchQuery, severityFilter, categoryFilter, statusFilter, timeRange)
  }, [alerts, searchQuery, severityFilter, categoryFilter, statusFilter, timeRange])

  const applyFilters = (
    alertsToFilter: Alert[],
    search: string,
    severity: string,
    category: string,
    status: string,
    time: string,
  ) => {
    let filtered = [...alertsToFilter]

    // Apply search filter
    if (search) {
      const searchLower = search.toLowerCase()
      filtered = filtered.filter(
        (alert) =>
          alert.alert_type.toLowerCase().includes(searchLower) ||
          alert.message.toLowerCase().includes(searchLower) ||
          (alert.category && alert.category.toLowerCase().includes(searchLower)) ||
          (alert.related_to && alert.related_to.toLowerCase().includes(searchLower)),
      )
    }

    // Apply severity filter
    if (severity !== "all") {
      filtered = filtered.filter((alert) => alert.severity === severity)
    }

    // Apply category filter
    if (category !== "all") {
      filtered = filtered.filter((alert) => alert.category === category)
    }

    // Apply status filter
    if (status !== "all") {
      filtered = filtered.filter((alert) => (status === "acknowledged" ? alert.acknowledged : !alert.acknowledged))
    }

    // Apply time range filter
    const now = new Date()
    let timeLimit: Date

    switch (time) {
      case "1h":
        timeLimit = new Date(now.getTime() - 60 * 60 * 1000)
        break
      case "24h":
        timeLimit = new Date(now.getTime() - 24 * 60 * 60 * 1000)
        break
      case "7d":
        timeLimit = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000)
        break
      case "30d":
        timeLimit = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000)
        break
      default:
        timeLimit = new Date(0) // All time
    }

    if (time !== "all") {
      filtered = filtered.filter((alert) => new Date(alert.timestamp) > timeLimit)
    }

    setFilteredAlerts(filtered)
  }

  const handleCraneChange = (craneId: string) => {
    setSelectedCrane(craneId)
  }

  const handleAcknowledge = async (alertId: string) => {
    // Update local state only since we're using dummy data
    setAlerts((prev) => prev.map((alert) => 
      alert.id === alertId ? { ...alert, acknowledged: true } : alert
    ))
    // Update filtered alerts as well
    setFilteredAlerts((prev) => prev.map((alert) => 
      alert.id === alertId ? { ...alert, acknowledged: true } : alert
    ))
  }

  const handleClearFilters = () => {
    setSearchQuery("")
    setSeverityFilter("all")
    setCategoryFilter("all")
    setStatusFilter("all")
    setTimeRange("24h")
  }

  const getAlertIcon = (severity: string) => {
    switch (severity) {
      case "critical":
        return <AlertCircle className="h-5 w-5 text-red-500" />
      case "warning":
        return <AlertTriangle className="h-5 w-5 text-yellow-500" />
      case "info":
        return <Info className="h-5 w-5 text-blue-500" />
      default:
        return <Info className="h-5 w-5 text-blue-500" />
    }
  }

  const getAlertStats = () => {
    const total = alerts.length
    const critical = alerts.filter((a) => a.severity === "critical").length
    const warning = alerts.filter((a) => a.severity === "warning").length
    const info = alerts.filter((a) => a.severity === "info").length
    const unacknowledged = alerts.filter((a) => !a.acknowledged).length
    const fuelRelated = alerts.filter(
      (a) =>
        a.category === "Fuel System" ||
        a.message.toLowerCase().includes("fuel") ||
        a.alert_type.toLowerCase().includes("fuel"),
    ).length
    const energyRelated = alerts.filter(
      (a) =>
        a.category === "Energy Optimization" ||
        a.message.toLowerCase().includes("energy") ||
        a.alert_type.toLowerCase().includes("energy"),
    ).length

    return { total, critical, warning, info, unacknowledged, fuelRelated, energyRelated }
  }

  if (isLoading) {
    return (
      <div className="flex h-full items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent" />
      </div>
    )
  }

  const stats = getAlertStats()

  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-4 md:flex-row md:items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Alerts & Notifications</h1>
          <p className="text-muted-foreground">Monitor and manage system alerts and notifications</p>
        </div>
        <CraneSelector cranes={cranes} selectedCrane={selectedCrane} onChange={handleCraneChange} />
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
        <Card className="md:col-span-2 lg:col-span-1">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Alerts</CardTitle>
            <Bell className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.total}</div>
            <p className="text-xs text-muted-foreground">{stats.unacknowledged} unacknowledged</p>
          </CardContent>
        </Card>
        <Card className="md:col-span-2 lg:col-span-1">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Critical</CardTitle>
            <AlertCircle className="h-4 w-4 text-red-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.critical}</div>
            <p className="text-xs text-muted-foreground">
              {stats.critical > 0 ? "Requires immediate attention" : "No critical alerts"}
            </p>
          </CardContent>
        </Card>
        <Card className="md:col-span-2 lg:col-span-1">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Warning</CardTitle>
            <AlertTriangle className="h-4 w-4 text-yellow-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.warning}</div>
            <p className="text-xs text-muted-foreground">{stats.warning > 0 ? "Requires attention" : "No warnings"}</p>
          </CardContent>
        </Card>
        <Card className="md:col-span-2 lg:col-span-1">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Info</CardTitle>
            <Info className="h-4 w-4 text-blue-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.info}</div>
            <p className="text-xs text-muted-foreground">Informational notifications</p>
          </CardContent>
        </Card>
        <Card className="md:col-span-2 lg:col-span-3 border-l-4 border-l-blue-500">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <div>
              <CardTitle className="text-sm font-medium">Fuel & Energy Alerts</CardTitle>
              <CardDescription>Alerts related to fuel consumption and energy optimization</CardDescription>
            </div>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div>
                <div className="text-2xl font-bold">{stats.fuelRelated + stats.energyRelated}</div>
                <p className="text-xs text-muted-foreground">
                  {stats.fuelRelated} fuel-related, {stats.energyRelated} energy-related
                </p>
              </div>
              <Button variant="outline" size="sm">
                View Details
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <div className="flex flex-col space-y-4 md:flex-row md:items-center md:justify-between md:space-y-0">
            <div>
              <CardTitle>Alert Management</CardTitle>
              <CardDescription>Search, filter, and manage system alerts</CardDescription>
            </div>
            <div className="flex items-center space-x-2">
              <Button variant="outline" size="sm" onClick={handleClearFilters}>
                <X className="mr-2 h-4 w-4" />
                Clear Filters
              </Button>
              <Button variant="outline" size="sm">
                <Download className="mr-2 h-4 w-4" />
                Export
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex flex-col space-y-4 md:flex-row md:items-center md:space-x-4 md:space-y-0">
            <div className="relative flex-1">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search alerts..."
                className="w-full pl-8"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <div className="flex items-center space-x-2">
                <Filter className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm">Filters:</span>
              </div>
              <Select value={severityFilter} onValueChange={setSeverityFilter}>
                <SelectTrigger className="h-8 w-[130px]">
                  <SelectValue placeholder="Severity" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Severities</SelectItem>
                  <SelectItem value="critical">Critical</SelectItem>
                  <SelectItem value="warning">Warning</SelectItem>
                  <SelectItem value="info">Info</SelectItem>
                </SelectContent>
              </Select>
              <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                <SelectTrigger className="h-8 w-[160px]">
                  <SelectValue placeholder="Category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  <SelectItem value="Fuel System">Fuel System</SelectItem>
                  <SelectItem value="Energy Optimization">Energy Optimization</SelectItem>
                  <SelectItem value="Electrical">Electrical</SelectItem>
                  <SelectItem value="Mechanical">Mechanical</SelectItem>
                  <SelectItem value="Safety">Safety</SelectItem>
                  <SelectItem value="Operational">Operational</SelectItem>
                </SelectContent>
              </Select>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="h-8 w-[150px]">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Statuses</SelectItem>
                  <SelectItem value="unacknowledged">Unacknowledged</SelectItem>
                  <SelectItem value="acknowledged">Acknowledged</SelectItem>
                </SelectContent>
              </Select>
              <Select value={timeRange} onValueChange={setTimeRange}>
                <SelectTrigger className="h-8 w-[120px]">
                  <SelectValue placeholder="Time Range" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1h">Last Hour</SelectItem>
                  <SelectItem value="24h">Last 24 Hours</SelectItem>
                  <SelectItem value="7d">Last 7 Days</SelectItem>
                  <SelectItem value="30d">Last 30 Days</SelectItem>
                  <SelectItem value="all">All Time</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <Tabs defaultValue="all" className="w-full">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="all">All Alerts</TabsTrigger>
              <TabsTrigger value="fuel">Fuel Related</TabsTrigger>
              <TabsTrigger value="energy">Energy Related</TabsTrigger>
              <TabsTrigger value="unacknowledged">Unacknowledged</TabsTrigger>
            </TabsList>
            <TabsContent value="all" className="mt-4">
              <AlertsList alerts={filteredAlerts} onAcknowledge={handleAcknowledge} />
            </TabsContent>
            <TabsContent value="fuel" className="mt-4">
              <AlertsList
                alerts={filteredAlerts.filter(
                  (a) =>
                    a.category === "Fuel System" ||
                    a.message.toLowerCase().includes("fuel") ||
                    a.alert_type.toLowerCase().includes("fuel"),
                )}
                onAcknowledge={handleAcknowledge}
              />
            </TabsContent>
            <TabsContent value="energy" className="mt-4">
              <AlertsList
                alerts={filteredAlerts.filter(
                  (a) =>
                    a.category === "Energy Optimization" ||
                    a.message.toLowerCase().includes("energy") ||
                    a.alert_type.toLowerCase().includes("energy"),
                )}
                onAcknowledge={handleAcknowledge}
              />
            </TabsContent>
            <TabsContent value="unacknowledged" className="mt-4">
              <AlertsList alerts={filteredAlerts.filter((a) => !a.acknowledged)} onAcknowledge={handleAcknowledge} />
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  )
}

interface AlertsListProps {
  alerts: Alert[]
  onAcknowledge: (id: string) => void
}

function AlertsList({ alerts, onAcknowledge }: AlertsListProps) {
  if (alerts.length === 0) {
    return (
      <div className="flex h-[200px] items-center justify-center rounded-md border border-dashed">
        <div className="flex flex-col items-center text-center">
          <Bell className="h-8 w-8 text-muted-foreground/50" />
          <h3 className="mt-4 text-lg font-semibold">No alerts found</h3>
          <p className="mt-2 text-sm text-muted-foreground">No alerts match your current filters.</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      {alerts.map((alert) => (
        <div
          key={alert.id}
          className={cn(
            "flex items-start space-x-4 rounded-md border p-4",
            alert.severity === "critical" && "border-l-4 border-l-red-500",
            alert.severity === "warning" && "border-l-4 border-l-yellow-500",
            alert.severity === "info" && "border-l-4 border-l-blue-500",
            (alert.category === "Fuel System" ||
              alert.message.toLowerCase().includes("fuel") ||
              alert.alert_type.toLowerCase().includes("fuel")) &&
              "bg-blue-50/30",
            (alert.category === "Energy Optimization" ||
              alert.message.toLowerCase().includes("energy") ||
              alert.alert_type.toLowerCase().includes("energy")) &&
              "bg-green-50/30",
          )}
        >
          <div className="flex-shrink-0 pt-1">
            {alert.severity === "critical" && <AlertCircle className="h-5 w-5 text-red-500" />}
            {alert.severity === "warning" && <AlertTriangle className="h-5 w-5 text-yellow-500" />}
            {alert.severity === "info" && <Info className="h-5 w-5 text-blue-500" />}
          </div>
          <div className="flex-1 space-y-2">
            <div className="flex flex-col justify-between space-y-1 md:flex-row md:items-center md:space-y-0">
              <div className="flex items-center space-x-2">
                <h4 className="font-medium">{alert.alert_type}</h4>
                <Badge
                  variant="outline"
                  className={cn(
                    "font-medium",
                    alert.severity === "critical" && "border-red-500 text-red-500",
                    alert.severity === "warning" && "border-yellow-500 text-yellow-500",
                    alert.severity === "info" && "border-blue-500 text-blue-500",
                  )}
                >
                  {alert.severity}
                </Badge>
                {alert.category && (
                  <Badge variant="secondary" className="font-normal">
                    {alert.category}
                  </Badge>
                )}
              </div>
              <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                <Calendar className="h-3.5 w-3.5" />
                <span>{format(new Date(alert.timestamp), "MMM d, yyyy h:mm a")}</span>
              </div>
            </div>
            <p className="text-sm">{alert.message}</p>
            {alert.related_to && <p className="text-xs text-muted-foreground">Related to: {alert.related_to}</p>}
            <div className="flex items-center justify-between pt-1">
              {alert.acknowledged ? (
                <div className="flex items-center text-sm text-green-600">
                  <Check className="mr-1 h-4 w-4" />
                  <span>Acknowledged</span>
                </div>
              ) : (
                <Button variant="outline" size="sm" onClick={() => onAcknowledge(alert.id)}>
                  Acknowledge
                </Button>
              )}
              <Button variant="ghost" size="sm">
                View Details
              </Button>
            </div>
          </div>
        </div>
      ))}
    </div>
  )
}

