"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { CraneSelector } from "@/components/dashboard/crane-selector"
import { Droplet, TrendingDown, LineChart, Download, ArrowDownToLine, Zap } from "lucide-react"
import { getSupabaseClient } from "@/lib/supabase/client"
import { RealtimePostgresChangesPayload } from '@supabase/supabase-js'
import { Button } from "@/components/ui/button"
import { toast } from "@/hooks/use-toast"
import { FuelConsumptionChart } from "@/components/dashboard/fuel-consumption-chart"

interface Crane {
  id: string
  name: string
  model: string
  location: string
}

interface FuelData {
  currentRate: number
  dailyUsage: number
  efficiency: number
  liftingConsumption: number
  idleConsumption: number
  movementConsumption: number
}

type DatabaseFuelData = {
  crane_id: string
  current_rate: number
  daily_usage: number
  efficiency: number
  lifting_consumption: number
  idle_consumption: number
  movement_consumption: number
}

const CRANE_MODELS = [
  {
    id: "CRANE-001",
    name: "Rhino 90C",
    model: "Rhino 90C",
    location: "Port A"
  },
  {
    id: "CRANE-002",
    name: "STC 600C",
    model: "STC 600C",
    location: "Port B"
  },
  {
    id: "CRANE-003",
    name: "STC 600T5P",
    model: "STC 600T5P",
    location: "Port C"
  },
  {
    id: "CRANE-004",
    name: "STC 800C",
    model: "STC 800C",
    location: "Port D"
  }
];

export default function FuelConsumptionPage() {
  const [selectedCrane, setSelectedCrane] = useState<string | null>(null)
  const [cranes, setCranes] = useState<Crane[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [fuelData, setFuelData] = useState<FuelData | null>(null)
  const [isOptimizing, setIsOptimizing] = useState(false)
  const [timeRange, setTimeRange] = useState<"hour" | "day" | "week" | "month">("day")

  useEffect(() => {
    const fetchCranes = async () => {
      try {
        // Use the predefined crane models instead of fetching from database
        setCranes(CRANE_MODELS)
        if (CRANE_MODELS.length > 0) {
          setSelectedCrane(CRANE_MODELS[0].id)
        }
      } catch (error) {
        console.error("Error setting up cranes:", error)
      } finally {
        setIsLoading(false)
      }
    }

    fetchCranes()
  }, [])

  useEffect(() => {
    const fetchFuelData = async () => {
      if (!selectedCrane) return

      try {
        const supabase = getSupabaseClient()
        
        // Fetch fuel consumption data
        const { data: fuelConsumptionData, error: fuelError } = await supabase
          .from("fuel_consumption")
          .select("*")
          .eq("crane_id", selectedCrane)
          .single()

        if (fuelError) {
          console.error("Error fetching fuel consumption data:", fuelError)
          // Set mock data if no real data exists
          setFuelData({
            currentRate: 5.2,
            dailyUsage: 42.5,
            efficiency: 92,
            liftingConsumption: 6.8,
            idleConsumption: 2.1,
            movementConsumption: 4.5
          })
          return
        }

        if (fuelConsumptionData) {
          const dbData = fuelConsumptionData as DatabaseFuelData
          setFuelData({
            currentRate: dbData.current_rate || 5.2,
            dailyUsage: dbData.daily_usage || 42.5,
            efficiency: dbData.efficiency || 92,
            liftingConsumption: dbData.lifting_consumption || 6.8,
            idleConsumption: dbData.idle_consumption || 2.1,
            movementConsumption: dbData.movement_consumption || 4.5
          })
        }

        // Set up real-time subscription
        const channel = supabase.channel('fuel_consumption_changes')
        
        channel
          .on(
            'postgres_changes' as any,
            {
              event: '*',
              schema: 'public',
              table: 'fuel_consumption',
              filter: `crane_id=eq.${selectedCrane}`
            },
            (payload: RealtimePostgresChangesPayload<DatabaseFuelData>) => {
              if (!payload.new) return

              const dbData = payload.new as DatabaseFuelData
              setFuelData({
                currentRate: dbData.current_rate || 5.2,
                dailyUsage: dbData.daily_usage || 42.5,
                efficiency: dbData.efficiency || 92,
                liftingConsumption: dbData.lifting_consumption || 6.8,
                idleConsumption: dbData.idle_consumption || 2.1,
                movementConsumption: dbData.movement_consumption || 4.5
              })
            }
          )
          .subscribe()

        return () => {
          channel.unsubscribe()
        }
      } catch (error) {
        console.error("Error in fetchFuelData:", error)
      }
    }

    fetchFuelData()
  }, [selectedCrane])

  const handleCraneChange = (craneId: string) => {
    setSelectedCrane(craneId)
  }

  // Handle export data
  const handleExportData = () => {
    try {
      // Create a data object to export
      const exportData = {
        crane: cranes.find(c => c.id === selectedCrane)?.name || "Unknown",
        timestamp: new Date().toISOString(),
        metrics: {
          currentRate: fuelData?.currentRate || 0,
          dailyUsage: fuelData?.dailyUsage || 0,
          efficiency: fuelData?.efficiency || 0,
        },
        operations: {
          lifting: fuelData?.liftingConsumption || 0,
          idle: fuelData?.idleConsumption || 0,
          movement: fuelData?.movementConsumption || 0,
        }
      }
      
      // Convert to JSON string with pretty formatting
      const jsonString = JSON.stringify(exportData, null, 2)
      
      // Create a blob and download link
      const blob = new Blob([jsonString], { type: 'application/json' })
      const url = URL.createObjectURL(blob)
      
      // Use an anchor with specific download attribute for better browser compatibility
      const link = document.createElement('a')
      link.href = url
      link.download = `fuel-data-${exportData.crane}-${new Date().toISOString().split('T')[0]}.json`
      link.style.display = 'none'
      document.body.appendChild(link)
      
      // Trigger the download with a small delay to ensure browser handles it
      setTimeout(() => {
        link.click()
        
        // Clean up after a delay
        setTimeout(() => {
          document.body.removeChild(link)
          URL.revokeObjectURL(url)
        }, 100)
      }, 0)
      
      toast({
        title: "Data exported successfully",
        description: "Fuel consumption data has been downloaded as a JSON file",
      })
    } catch (error) {
      console.error("Error exporting data:", error)
      toast({
        title: "Export failed",
        description: "There was an error exporting the data",
        variant: "destructive",
      })
    }
  }

  // Handle chart data export
  const handleChartDataExport = () => {
    try {
      // Create CSV data for the chart
      const csvHeader = "Time,Value\n";
      
      // Generate some sample data rows for the current time range
      const rows = [];
      const now = new Date();
      
      if (timeRange === "hour") {
        // Generate hourly data for the past 60 minutes
        for (let i = 59; i >= 0; i--) {
          const time = new Date(now.getTime() - i * 60000);
          const formattedTime = `${time.getHours().toString().padStart(2, '0')}:${time.getMinutes().toString().padStart(2, '0')}`;
          const value = (Math.random() * 2 + 4).toFixed(2); // Random value between 4-6
          rows.push(`${formattedTime},${value}`);
        }
      } else {
        // Generate daily data for the past 24 hours
        for (let i = 23; i >= 0; i--) {
          const time = new Date(now.getTime() - i * 3600000);
          const formattedTime = `${time.getHours().toString().padStart(2, '0')}:00`;
          const value = (Math.random() * 2 + 4).toFixed(2); // Random value between 4-6
          rows.push(`${formattedTime},${value}`);
        }
      }
      
      const csvContent = csvHeader + rows.join('\n');
      
      // Create a blob and download link
      const blob = new Blob([csvContent], { type: 'text/csv' });
      const url = URL.createObjectURL(blob);
      
      const link = document.createElement('a');
      link.href = url;
      link.download = `fuel-chart-data-${timeRange}-${new Date().toISOString().split('T')[0]}.csv`;
      link.style.display = 'none';
      document.body.appendChild(link);
      
      // Trigger the download with a small delay
      setTimeout(() => {
        link.click();
        
        // Clean up after a delay
        setTimeout(() => {
          document.body.removeChild(link);
          URL.revokeObjectURL(url);
        }, 100);
      }, 0);
      
      toast({
        title: "Chart data exported",
        description: `${timeRange} chart data has been downloaded as CSV`,
      });
    } catch (error) {
      console.error("Error exporting chart data:", error);
      toast({
        title: "Export failed",
        description: "There was an error exporting the chart data",
        variant: "destructive",
      });
    }
  };

  // Handle optimize
  const handleOptimize = () => {
    // Show optimizing state immediately
    setIsOptimizing(true)
    toast({
      title: "Optimization started",
      description: "Analyzing fuel consumption patterns...",
    })
    
    // Simulate optimization process
    setTimeout(() => {
      setIsOptimizing(false)
      
      // Update data with "optimized" values
      if (fuelData) {
        const optimizedCurrentRate = Number((fuelData.currentRate * 0.85).toFixed(1))
        const optimizedEfficiency = Math.min(100, Math.round(fuelData.efficiency * 1.15))
        
        setFuelData({
          ...fuelData,
          currentRate: optimizedCurrentRate,
          efficiency: optimizedEfficiency,
        })
        
        toast({
          title: "Optimization complete",
          description: `Fuel consumption reduced by 15% (${fuelData.currentRate} → ${optimizedCurrentRate} L/h)`,
        })
      } else {
        toast({
          title: "Optimization complete",
          description: "Fuel consumption has been optimized by 15%",
        })
      }
    }, 2000)
  }

  // Add a new handler for exporting patterns data
  const handleExportPatterns = () => {
    try {
      // Show feedback immediately
      toast({
        title: "Preparing patterns export",
        description: "Creating file for download...",
      });
      
      // Create a data object with consumption patterns
      const patternsData = {
        timestamp: new Date().toISOString(),
        crane: cranes.find(c => c.id === selectedCrane)?.name || "Unknown",
        patterns: {
          lifting: {
            description: "Average consumption during lifts",
            value: fuelData?.liftingConsumption || 6.8,
            unit: "L/h"
          },
          idle: {
            description: "Consumption while idle",
            value: fuelData?.idleConsumption || 2.1,
            unit: "L/h"
          },
          movement: {
            description: "During crane movement",
            value: fuelData?.movementConsumption || 4.5,
            unit: "L/h"
          }
        },
        metadata: {
          exportedBy: "Crane Monitoring System",
          version: "1.0"
        }
      };
      
      // Convert to JSON string with pretty formatting
      const jsonString = JSON.stringify(patternsData, null, 2);
      
      // Create a blob and download link
      const blob = new Blob([jsonString], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      
      const link = document.createElement('a');
      link.href = url;
      link.download = `fuel-patterns-${patternsData.crane}-${new Date().toISOString().split('T')[0]}.json`;
      link.style.display = 'none';
      document.body.appendChild(link);
      
      // Trigger the download with a small delay
      setTimeout(() => {
        link.click();
        
        // Clean up after a delay
        setTimeout(() => {
          document.body.removeChild(link);
          URL.revokeObjectURL(url);
          
          toast({
            title: "Patterns data exported",
            description: "Consumption patterns have been downloaded as JSON",
          });
        }, 100);
      }, 0);
    } catch (error) {
      console.error("Error exporting patterns data:", error);
      toast({
        title: "Export failed",
        description: "There was an error exporting the patterns data",
        variant: "destructive",
      });
    }
  };

  if (isLoading) {
    return (
      <div className="flex h-full items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent" />
      </div>
    )
  }

  // Show a message if no cranes are available
  if (!cranes || cranes.length === 0) {
    return (
      <div className="flex h-full flex-col items-center justify-center space-y-4">
        <h1 className="text-2xl font-bold">No Cranes Available</h1>
        <p className="text-muted-foreground">Please add cranes to view fuel consumption data.</p>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-4 md:flex-row md:items-center">
        <div>
          <p className="text-muted-foreground">Monitor and optimize fuel usage patterns</p>
        </div>
        <div className="flex items-center gap-2">
          <CraneSelector 
            cranes={cranes}
            selectedCrane={selectedCrane}
            onChange={handleCraneChange}
          />
          <Button 
            variant="outline" 
            size="sm" 
            className="flex items-center gap-1"
            onClick={handleExportData}
          >
            <ArrowDownToLine className="h-4 w-4" />
            <span className="hidden sm:inline">Export</span>
          </Button>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <Card>
          <CardHeader>
            <CardTitle>Current Rate</CardTitle>
            <CardDescription>Real-time consumption</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{fuelData?.currentRate || 0} L/h</div>
            <p className="text-sm text-muted-foreground mt-2">↓ 8% from average</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Daily Usage</CardTitle>
            <CardDescription>Total consumption today</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{fuelData?.dailyUsage || 0} L</div>
            <p className="text-sm text-muted-foreground mt-2">Since 00:00</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Efficiency Score</CardTitle>
            <CardDescription>Overall consumption efficiency</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{fuelData?.efficiency || 0}%</div>
            <p className="text-sm text-muted-foreground mt-2">Above target</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="analysis" className="space-y-4">
        <TabsList>
          <TabsTrigger value="analysis">Usage Analysis</TabsTrigger>
          <TabsTrigger value="patterns">Consumption Patterns</TabsTrigger>
          <TabsTrigger value="optimization">Optimization</TabsTrigger>
        </TabsList>

        <TabsContent value="analysis" className="space-y-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <div>
                <CardTitle>Fuel Analysis</CardTitle>
                <CardDescription>Consumption over time</CardDescription>
              </div>
              <div className="flex items-center gap-2">
                <div className="flex border rounded-md overflow-hidden">
                  <Button 
                    variant={timeRange === "hour" ? "secondary" : "ghost"} 
                    size="sm"
                    onClick={() => setTimeRange("hour")}
                    className="rounded-none border-r h-8 px-3"
                  >
                    Hour
                  </Button>
                  <Button 
                    variant={timeRange === "day" ? "secondary" : "ghost"} 
                    size="sm"
                    onClick={() => setTimeRange("day")}
                    className="rounded-none h-8 px-3"
                  >
                    Day
                  </Button>
                </div>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={handleChartDataExport}
                  className="flex items-center gap-1"
                >
                  <Download className="h-4 w-4" />
                  <span className="hidden sm:inline">CSV</span>
                </Button>
              </div>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="h-[400px]">
                {selectedCrane && (
                  <FuelConsumptionChart craneId={selectedCrane} timeRange={timeRange} />
                )}
              </div>
            </CardContent>
          </Card>

          <div className="flex justify-end">
            <Button
              variant="default"
              onClick={handleExportData}
              className="flex items-center gap-2"
            >
              <ArrowDownToLine className="h-4 w-4" />
              Export All Data
            </Button>
          </div>
        </TabsContent>

        <TabsContent value="patterns" className="space-y-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Usage Patterns</CardTitle>
                <CardDescription>Consumption patterns by operation type</CardDescription>
              </div>
              <Button 
                variant="outline" 
                size="sm" 
                className="flex items-center gap-1"
                onClick={handleExportPatterns}
              >
                <ArrowDownToLine className="h-4 w-4" />
                <span className="hidden sm:inline">Export</span>
              </Button>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">Lifting Operations</p>
                    <p className="text-sm text-muted-foreground">Average consumption during lifts</p>
                  </div>
                  <div className="text-2xl font-bold">6.8 L/h</div>
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">Idle Time</p>
                    <p className="text-sm text-muted-foreground">Consumption while idle</p>
                  </div>
                  <div className="text-2xl font-bold">2.1 L/h</div>
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">Movement Operations</p>
                    <p className="text-sm text-muted-foreground">During crane movement</p>
                  </div>
                  <div className="text-2xl font-bold">4.5 L/h</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="optimization" className="space-y-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Optimization Opportunities</CardTitle>
                <CardDescription>Ways to reduce fuel consumption</CardDescription>
              </div>
              <Button 
                variant="default" 
                size="sm"
                className="flex items-center gap-1"
                onClick={handleOptimize}
                disabled={isOptimizing}
              >
                {isOptimizing ? (
                  <>
                    <div className="h-3 w-3 animate-spin rounded-full border-2 border-primary-foreground border-t-transparent" />
                    <span>Optimizing...</span>
                  </>
                ) : (
                  <>
                    <Zap className="h-4 w-4" />
                    <span>Optimize Now</span>
                  </>
                )}
              </Button>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <TrendingDown className="h-5 w-5 text-green-500 mt-0.5" />
                  <div>
                    <p className="font-medium">Reduce Idle Time</p>
                    <p className="text-sm text-muted-foreground">
                      Current idle time: 25% of operation. Target: 15%
                    </p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <LineChart className="h-5 w-5 text-blue-500 mt-0.5" />
                  <div>
                    <p className="font-medium">Optimize Load Planning</p>
                    <p className="text-sm text-muted-foreground">
                      Better route planning can save up to 15% fuel
                    </p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <Droplet className="h-5 w-5 text-yellow-500 mt-0.5" />
                  <div>
                    <p className="font-medium">Maintenance Impact</p>
                    <p className="text-sm text-muted-foreground">
                      Regular maintenance can improve efficiency by 8-10%
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
} 