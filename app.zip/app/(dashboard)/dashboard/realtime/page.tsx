"use client"

import { useEffect, useState } from "react"
import { supabase } from "@/lib/supabase"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { RealtimePostgresChangesPayload } from '@supabase/supabase-js'
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from "recharts"
import { CircularProgressbar, buildStyles } from 'react-circular-progressbar'
import 'react-circular-progressbar/dist/styles.css'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface SensorData {
  id: number
  created_at: string
  bus_voltage: number
  shunt_voltage: number
  load_voltage: number
  current_ma: number
  power_mw: number
}

interface ThermocoupleData {
  id: number
  created_at: string
  temperature_c: number
  temperature_f: number
}

const DEMO_CRANES = [
  {
    id: "CRANE-001",
    name: "HC-5000",
    description: "Heavy-duty crawler crane with 5000-ton capacity. Current fuel level: 85%",
    model: "HC-5000",
    location: "Site A",
    status: "active"
  },
  {
    id: "CRANE-002",
    name: "RT-2000",
    description: "Rough terrain crane with 2000-ton capacity. Current fuel level: 65%",
    model: "RT-2000",
    location: "Site B",
    status: "active"
  },
  {
    id: "CRANE-003",
    name: "AT-1500",
    description: "All-terrain crane with 1500-ton capacity. Current fuel level: 45%",
    model: "AT-1500",
    location: "Site C",
    status: "maintenance"
  },
  {
    id: "CRANE-004",
    name: "LT-1000",
    description: "Lattice boom crawler crane with 1000-ton capacity. Current fuel level: 92%",
    model: "LT-1000",
    location: "Site D",
    status: "active"
  }
]

// Initial mock data
const generateMockSensorData = (): SensorData => {
  const now = Date.now();
  // Create a very slow sine wave pattern for voltage with tiny variations
  const timeOffset = now / 10000; // Much slower cycle
  const baseVoltage = 220 + Math.sin(timeOffset * 0.05) * 1; // Smaller variation (±1V)
  
  // Add very small random noise
  const busVoltage = Number((baseVoltage + (Math.random() * 0.2 - 0.1)).toFixed(1));
  const shuntVoltage = Number((0.8 + Math.sin(timeOffset * 0.02) * 0.05).toFixed(2));
  const loadVoltage = Number((busVoltage - shuntVoltage).toFixed(1));
  
  // Current varies very slowly
  const baseCurrent = 1000 + Math.sin(timeOffset * 0.02) * 50;
  const current = Math.round(baseCurrent + (Math.random() * 10 - 5));
  
  // Power calculated from voltage and current
  const power = Math.round(busVoltage * current / 1000);

  return {
    id: now,
    created_at: new Date(now).toISOString(),
    bus_voltage: busVoltage,
    shunt_voltage: shuntVoltage,
    load_voltage: loadVoltage,
    current_ma: current,
    power_mw: power
  }
}

const generateMockThermocoupleData = (): ThermocoupleData => {
  const now = Date.now();
  // Make temperature changes extremely slow with tiny variations
  const timeOffset = now / 20000; // Even slower cycle for temperature
  // Base temperature varies between 25-35°C over a very long period
  const baseTemp = 30 + Math.sin(timeOffset * 0.005) * 5; // Center at 30°C, vary by ±5°C
  // Add extremely small random variations (±0.05°C)
  const tempC = Number((baseTemp + (Math.random() * 0.1 - 0.05)).toFixed(1));
  const tempF = Number((tempC * 9/5 + 32).toFixed(1));

  return {
    id: now,
    created_at: new Date(now).toISOString(),
    temperature_c: tempC,
    temperature_f: tempF
  }
}

export default function RealTimeMonitoring() {
  const [sensorData, setSensorData] = useState<SensorData[]>([])
  const [currentReadings, setCurrentReadings] = useState<SensorData | null>(null)
  const [thermocoupleData, setThermocoupleData] = useState<ThermocoupleData[]>([])
  const [currentTempReadings, setCurrentTempReadings] = useState<ThermocoupleData | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Initial fetch of data
    fetchSensorData()
    fetchThermocoupleData()

    // Set up real-time subscriptions
    const sensorSubscription = supabase
      .channel('sensor_data_changes')
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'sensor_data'
      }, (payload: RealtimePostgresChangesPayload<SensorData>) => {
        console.log('New sensor data:', payload)
        fetchSensorData()
      })
      .subscribe()

    const thermocoupleSubscription = supabase
      .channel('thermocouple_changes')
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'K-thermocouple_log'
      }, (payload: RealtimePostgresChangesPayload<ThermocoupleData>) => {
        console.log('New thermocouple data:', payload)
        fetchThermocoupleData()
      })
      .subscribe()

    // Separate intervals for electrical and temperature data
    const electricalInterval = setInterval(() => {
      const newSensorData = generateMockSensorData()
      setSensorData(prev => {
        const newData = [...prev, newSensorData]
        if (newData.length > 50) newData.shift()
        return newData
      })
      setCurrentReadings(newSensorData)
    }, 10000) // Update electrical parameters every 10 seconds

    const temperatureInterval = setInterval(() => {
      const newThermocoupleData = generateMockThermocoupleData()
      setThermocoupleData(prev => {
        const newData = [...prev, newThermocoupleData]
        if (newData.length > 50) newData.shift()
        return newData
      })
      setCurrentTempReadings(newThermocoupleData)
    }, 15000) // Update temperature every 15 seconds

    // Initialize with historical data
    const initialSensorData: SensorData[] = Array.from({ length: 50 }, (_, i) => ({
      ...generateMockSensorData(),
      created_at: new Date(Date.now() - (50 - i) * 10000).toISOString() // Last 500 seconds
    }))
    setSensorData(initialSensorData)
    setCurrentReadings(initialSensorData[initialSensorData.length - 1])

    const initialThermocoupleData: ThermocoupleData[] = Array.from({ length: 50 }, (_, i) => ({
      ...generateMockThermocoupleData(),
      created_at: new Date(Date.now() - (50 - i) * 15000).toISOString() // Last 750 seconds for temperature
    }))
    setThermocoupleData(initialThermocoupleData)
    setCurrentTempReadings(initialThermocoupleData[initialThermocoupleData.length - 1])

    setIsLoading(false)

    return () => {
      clearInterval(electricalInterval)
      clearInterval(temperatureInterval)
      sensorSubscription.unsubscribe()
      thermocoupleSubscription.unsubscribe()
    }
  }, [])

  const fetchSensorData = async () => {
    const { data, error } = await supabase
      .from('sensor_data')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(50)

    if (error) {
      console.error('Error fetching sensor data:', error)
      return
    }

    if (data && data.length > 0) {
      setCurrentReadings(data[0])
      setSensorData(data.reverse())
    }
  }

  const fetchThermocoupleData = async () => {
    const { data, error } = await supabase
      .from('K-thermocouple_log')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(50)

    if (error) {
      console.error('Error fetching thermocouple data:', error)
      return
    }

    if (data && data.length > 0) {
      setCurrentTempReadings(data[0])
      setThermocoupleData(data.reverse())
    }
  }

  const GaugeCard = ({ title, value, unit, color }: { title: string; value: number; unit: string; color: string }) => (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg font-semibold">{title}</CardTitle>
      </CardHeader>
      <CardContent className="flex flex-col items-center">
        <div className="w-32 h-32">
          <CircularProgressbar
            value={unit === 'V' ? value / 3 : unit === 'mA' ? value / 20 : value / 5}
            maxValue={100}
            text={`${value.toFixed(unit === 'V' ? 1 : 0)}${unit}`}
            styles={buildStyles({
              pathColor: color,
              textColor: color,
              trailColor: '#1e293b',
              textSize: '16px',
            })}
          />
        </div>
      </CardContent>
    </Card>
  )

  const TemperatureGaugeCard = ({ tempC, tempF }: { tempC: number; tempF: number }) => {
    console.log('Temperature values:', { tempC, tempF }) // Debug log
    return (
      <Card className="col-span-2">
        <CardHeader>
          <CardTitle className="text-lg font-semibold">Current Temperature</CardTitle>
        </CardHeader>
        <CardContent className="flex justify-center gap-8 items-center p-6">
          <div className="flex flex-col items-center">
            <div className="w-40 h-40">
              <CircularProgressbar
                value={tempC}
                maxValue={150}
                text={`${tempC.toFixed(1)}°C`}
                styles={buildStyles({
                  pathColor: '#2563eb',
                  textColor: '#2563eb',
                  trailColor: '#1e293b',
                  textSize: '16px',
                })}
              />
            </div>
            <span className="mt-2 text-sm text-muted-foreground">Celsius</span>
          </div>
          <div className="flex flex-col items-center">
            <div className="w-40 h-40">
              <CircularProgressbar
                value={tempF}
                maxValue={300}
                text={`${tempF.toFixed(1)}°F`}
                styles={buildStyles({
                  pathColor: '#dc2626',
                  textColor: '#dc2626',
                  trailColor: '#1e293b',
                  textSize: '16px',
                })}
              />
            </div>
            <span className="mt-2 text-sm text-muted-foreground">Fahrenheit</span>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="flex-1 space-y-6 p-8 pt-6">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold tracking-tight">Real Time Monitoring</h2>
      </div>

      <Tabs defaultValue="electrical" className="space-y-4">
        <TabsList>
          <TabsTrigger value="electrical">Electrical Parameters</TabsTrigger>
          <TabsTrigger value="thermocouple">Temperature Monitoring</TabsTrigger>
        </TabsList>

        <TabsContent value="electrical" className="space-y-4">
          {/* Current Readings Section */}
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 mb-6">
            <GaugeCard
              title="Bus Voltage"
              value={currentReadings?.bus_voltage || 0}
              unit="V"
              color="#2563eb"
            />
            <GaugeCard
              title="Shunt Voltage"
              value={currentReadings?.shunt_voltage || 0}
              unit="V"
              color="#16a34a"
            />
            <GaugeCard
              title="Load Voltage"
              value={currentReadings?.load_voltage || 0}
              unit="V"
              color="#dc2626"
            />
            <GaugeCard
              title="Current"
              value={currentReadings?.current_ma || 0}
              unit="mA"
              color="#9333ea"
            />
            <GaugeCard
              title="Power"
              value={currentReadings?.power_mw || 0}
              unit="mW"
              color="#ea580c"
            />
          </div>

          {/* Trends Section */}
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            <Card>
              <CardHeader>
                <CardTitle>Voltage Monitoring</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={sensorData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis 
                      dataKey="created_at" 
                      tick={{ fontSize: 12 }}
                      tickFormatter={(value) => new Date(value).toLocaleTimeString()}
                    />
                    <YAxis tick={{ fontSize: 12 }} />
                    <Tooltip 
                      labelFormatter={(value) => new Date(value).toLocaleString()}
                      formatter={(value, name) => {
                        switch(name) {
                          case 'bus_voltage': return [`${value}V`, 'Bus Voltage']
                          case 'shunt_voltage': return [`${value}V`, 'Shunt Voltage']
                          case 'load_voltage': return [`${value}V`, 'Load Voltage']
                          default: return [value, name]
                        }
                      }}
                    />
                    <Legend />
                    <Line 
                      type="monotone" 
                      name="Bus Voltage"
                      dataKey="bus_voltage" 
                      stroke="#2563eb" 
                      strokeWidth={2}
                      dot={false}
                    />
                    <Line 
                      type="monotone" 
                      name="Shunt Voltage"
                      dataKey="shunt_voltage" 
                      stroke="#16a34a" 
                      strokeWidth={2}
                      dot={false}
                    />
                    <Line 
                      type="monotone" 
                      name="Load Voltage"
                      dataKey="load_voltage" 
                      stroke="#dc2626" 
                      strokeWidth={2}
                      dot={false}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Current Monitoring</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={sensorData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis 
                      dataKey="created_at"
                      tick={{ fontSize: 12 }}
                      tickFormatter={(value) => new Date(value).toLocaleTimeString()}
                    />
                    <YAxis tick={{ fontSize: 12 }} />
                    <Tooltip 
                      labelFormatter={(value) => new Date(value).toLocaleString()}
                      formatter={(value) => [`${value} mA`, 'Current']}
                    />
                    <Legend />
                    <Line 
                      type="monotone" 
                      name="Current"
                      dataKey="current_ma" 
                      stroke="#9333ea" 
                      strokeWidth={2}
                      dot={false}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Power Consumption</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={sensorData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis 
                      dataKey="created_at"
                      tick={{ fontSize: 12 }}
                      tickFormatter={(value) => new Date(value).toLocaleTimeString()}
                    />
                    <YAxis tick={{ fontSize: 12 }} />
                    <Tooltip 
                      labelFormatter={(value) => new Date(value).toLocaleString()}
                      formatter={(value) => [`${value} mW`, 'Power']}
                    />
                    <Legend />
                    <Line 
                      type="monotone" 
                      name="Power"
                      dataKey="power_mw" 
                      stroke="#ea580c" 
                      strokeWidth={2}
                      dot={false}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="thermocouple" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <TemperatureGaugeCard
              tempC={currentTempReadings?.temperature_c || 0}
              tempF={currentTempReadings?.temperature_f || 0}
            />
            <Card className="col-span-2">
              <CardHeader>
                <CardTitle>Temperature Trend</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[400px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={thermocoupleData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis 
                        dataKey="created_at"
                        tick={{ fontSize: 12 }}
                        tickFormatter={(value) => new Date(value).toLocaleTimeString()}
                      />
                      <YAxis 
                        yAxisId="celsius"
                        orientation="left"
                        tick={{ fontSize: 12 }}
                        label={{ value: 'Temperature (°C)', angle: -90, position: 'insideLeft' }}
                      />
                      <YAxis 
                        yAxisId="fahrenheit"
                        orientation="right"
                        tick={{ fontSize: 12 }}
                        label={{ value: 'Temperature (°F)', angle: 90, position: 'insideRight' }}
                      />
                      <Tooltip 
                        labelFormatter={(value) => new Date(value).toLocaleString()}
                        formatter={(value, name) => {
                          if (name === 'Celsius') return [`${value}°C`, name]
                          return [`${value}°F`, name]
                        }}
                      />
                      <Legend />
                      <Line 
                        yAxisId="celsius"
                        type="monotone" 
                        name="Celsius"
                        dataKey="temperature_c" 
                        stroke="#2563eb" 
                        strokeWidth={2}
                        dot={false}
                      />
                      <Line 
                        yAxisId="fahrenheit"
                        type="monotone" 
                        name="Fahrenheit"
                        dataKey="temperature_f" 
                        stroke="#dc2626" 
                        strokeWidth={2}
                        dot={false}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
} 