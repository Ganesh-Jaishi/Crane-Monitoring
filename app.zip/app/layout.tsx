import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import { ThemeProvider } from "@/components/theme-provider"
import { Toaster } from "@/components/ui/toaster"
import { Providers } from "@/components/providers"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Crane Monitor Pro",
  description: "Advanced monitoring system for crane operations",
}

function checkEnvironmentVariables() {
  return !!(
    process.env.NEXT_PUBLIC_SUPABASE_URL &&
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY
  )
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const envVarsPresent = checkEnvironmentVariables()

  return (
    <html lang="en" suppressHydrationWarning>
      <body className={inter.className}>
        <ThemeProvider
          attribute="class"
          defaultTheme="system"
          enableSystem
          disableTransitionOnChange
        >
          {envVarsPresent ? (
            <Providers>
              {children}
            </Providers>
          ) : (
            <div className="flex min-h-screen flex-col items-center justify-center">
              <div className="text-center">
                <h1 className="text-4xl font-bold text-red-500 mb-4">Environment Variables Missing</h1>
                <p className="text-lg text-gray-600">
                  Please ensure you have set up your Supabase environment variables correctly.
                </p>
              </div>
            </div>
          )}
          <Toaster />
        </ThemeProvider>
      </body>
    </html>
  )
}

import './globals.css'