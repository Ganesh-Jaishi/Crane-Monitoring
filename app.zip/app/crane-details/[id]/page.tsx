"use client"

import { useRouter } from "next/navigation"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"

const craneModels = [
  {
    id: 1,
    name: "Rhino 90C",
    description: "Heavy-duty mobile crane with exceptional lifting capacity",
    image: "/images/1.jpg",
    specs: {
      capacity: "90 tons",
      reach: "60 meters",
      type: "Mobile Crane"
    }
  },
  {
    id: 2,
    name: "STC 600C",
    description: "Versatile crawler crane for challenging terrains",
    image: "/images/2.jpg",
    specs: {
      capacity: "600 tons",
      reach: "80 meters",
      type: "Crawler Crane"
    }
  },
  {
    id: 3,
    name: "STC 600T5P",
    description: "Advanced telescopic crane with precision control",
    image: "/images/3.jpg",
    specs: {
      capacity: "600 tons",
      reach: "85 meters",
      type: "Telescopic Crane"
    }
  },
  {
    id: 4,
    name: "STC 800C",
    description: "High-performance crane for heavy industrial use",
    image: "/images/4.jpg",
    specs: {
      capacity: "800 tons",
      reach: "90 meters",
      type: "Heavy Lift Crane"
    }
  }
]

export default function CraneDetailsPage({ params }: { params: { id: string } }) {
  const router = useRouter()
  const crane = craneModels.find(c => c.id === parseInt(params.id))

  if (!crane) {
    return <div>Crane not found</div>
  }

  return (
    <div className="min-h-screen bg-gray-100">
      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-3xl font-bold text-gray-900">
            {crane.name} Details
          </h1>
          <Button
            variant="outline"
            onClick={() => router.push("/crane-selection")}
          >
            Back to Selection
          </Button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Left Column - Crane Image */}
          <Card className="p-6 bg-white shadow-lg">
            <div className="aspect-[4/3] relative rounded-lg overflow-hidden">
              <Image
                src={crane.image}
                alt={crane.name}
                fill
                className="object-cover"
                priority
              />
            </div>
          </Card>

          {/* Right Column - Crane Details */}
          <Card className="p-6 bg-white shadow-lg">
            <div className="space-y-6">
              <div>
                <h2 className="text-2xl font-bold text-gray-900">{crane.name}</h2>
                <p className="mt-2 text-gray-600">{crane.description}</p>
              </div>

              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-gray-900">Specifications</h3>
                <div className="grid grid-cols-1 gap-4">
                  <div className="flex justify-between items-center py-2 border-b">
                    <span className="font-medium text-gray-600">Capacity</span>
                    <span className="text-gray-900">{crane.specs.capacity}</span>
                  </div>
                  <div className="flex justify-between items-center py-2 border-b">
                    <span className="font-medium text-gray-600">Reach</span>
                    <span className="text-gray-900">{crane.specs.reach}</span>
                  </div>
                  <div className="flex justify-between items-center py-2 border-b">
                    <span className="font-medium text-gray-600">Type</span>
                    <span className="text-gray-900">{crane.specs.type}</span>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 mt-8">
                <Button 
                  className="w-full"
                  onClick={() => router.push('/dashboard')}
                >
                  View Dashboard
                </Button>
                <Button 
                  variant="outline"
                  className="w-full"
                  onClick={() => router.push('/crane-selection')}
                >
                  Back to Selection
                </Button>
              </div>
            </div>
          </Card>
        </div>

        {/* Features Section */}
        <div className="mt-12">
          <h3 className="text-2xl font-bold text-gray-900 mb-6">Key Features</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="p-6 bg-white shadow-lg">
              <h4 className="text-lg font-semibold mb-2">Real-time Monitoring</h4>
              <p className="text-gray-600">Live tracking and performance analysis</p>
            </Card>
            <Card className="p-6 bg-white shadow-lg">
              <h4 className="text-lg font-semibold mb-2">Energy Efficiency</h4>
              <p className="text-gray-600">Optimized power consumption management</p>
            </Card>
            <Card className="p-6 bg-white shadow-lg">
              <h4 className="text-lg font-semibold mb-2">Safety Features</h4>
              <p className="text-gray-600">Advanced safety monitoring and alerts</p>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
} 