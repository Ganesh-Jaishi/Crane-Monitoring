import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Real-time Crane Monitoring",
  description: "Professional real-time monitoring system for industrial cranes",
  generator: 'v0.dev'
} 