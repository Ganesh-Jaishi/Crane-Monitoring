"use client"

import { useRouter } from "next/navigation"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { createBrowserClient } from '@supabase/ssr'
import { useToast } from "@/components/ui/use-toast"
import { Settings, User, LogOut, Fuel } from "lucide-react"
import { Separator } from "@/components/ui/separator"

const craneModels = [
  {
    id: 1,
    name: "Rhino 90C",
    description: "Heavy-duty mobile crane with exceptional lifting capacity",
    image: "/images/1.jpg",
    specs: {
      capacity: "90 tons",
      reach: "60 meters",
      type: "Mobile Crane",
      fuelLevel: 85
    }
  },
  {
    id: 2,
    name: "STC 600C",
    description: "Versatile crawler crane for challenging terrains",
    image: "/images/2.jpg",
    specs: {
      capacity: "600 tons",
      reach: "80 meters",
      type: "Crawler Crane",
      fuelLevel: 65
    }
  },
  {
    id: 3,
    name: "STC 600T5P",
    description: "Advanced telescopic crane with precision control",
    image: "/images/3.jpg",
    specs: {
      capacity: "600 tons",
      reach: "85 meters",
      type: "Telescopic Crane",
      fuelLevel: 45
    }
  },
  {
    id: 4,
    name: "STC 800C",
    description: "High-performance crane for heavy industrial use",
    image: "/images/4.jpg",
    specs: {
      capacity: "800 tons",
      reach: "90 meters",
      type: "Heavy Lift Crane",
      fuelLevel: 92
    }
  }
]

const FuelGauge = ({ level }: { level: number }) => {
  // Calculate which segments should be lit based on fuel level
  const segments = 8; // Number of segments in the gauge
  const activeSegments = Math.ceil((level / 100) * segments);
  
  return (
    <div className="relative w-16 h-16 bg-gray-900 rounded-full border-4 border-gray-300 flex items-center justify-center">
      {/* Gauge segments */}
      <div className="absolute w-full h-full">
        {Array.from({ length: segments }).map((_, i) => {
          const rotation = -120 + (i * (240 / (segments - 1))); // -120 to 120 degrees
          const isActive = i < activeSegments;
          const color = level > 70 ? 'rgb(34 197 94)' : // green
                       level > 30 ? 'rgb(234 179 8)' : // yellow
                       'rgb(239 68 68)'; // red
          
          return (
            <div
              key={i}
              className="absolute w-1 h-3 origin-bottom transition-all duration-300"
              style={{
                left: '50%',
                bottom: '50%',
                transform: `rotate(${rotation}deg)`,
              }}
            >
              <div
                className={`w-full h-full rounded-full transition-all duration-300 ${
                  isActive ? 'opacity-100' : 'opacity-20'
                }`}
                style={{
                  backgroundColor: isActive ? color : '#4B5563',
                  boxShadow: isActive ? `0 0 8px ${color}` : 'none',
                }}
              />
            </div>
          );
        })}
      </div>
      
      {/* Fuel icon */}
      <Fuel 
        className={`h-6 w-6 ${
          level > 70 ? 'text-green-500' :
          level > 30 ? 'text-yellow-500' :
          'text-red-500'
        }`}
      />
      
      {/* Fuel percentage */}
      <div className="absolute -bottom-7 left-1/2 transform -translate-x-1/2 text-xs font-medium">
        {level}%
      </div>
    </div>
  );
};

export default function CraneSelectionPage() {
  const router = useRouter()
  const { toast } = useToast()

  const supabase = createBrowserClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  )

  const handleLogout = async () => {
    try {
      const { error } = await supabase.auth.signOut()
      if (error) {
        toast({
          variant: "destructive",
          title: "Error",
          description: "Failed to sign out. Please try again.",
        })
        return
      }
      router.push("/auth/login")
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "An error occurred while signing out.",
      })
    }
  }

  return (
    <div className="min-h-screen bg-gray-100">
      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">
              Pick Your Powerhouse: Select Your Mobile Crane Type
            </h1>
          </div>
          <div className="flex items-center gap-4">
            <Button 
              variant="outline"
              onClick={() => router.push("/crane-selection/settings")}
            >
              <Settings className="mr-2 h-4 w-4" />
              Settings
            </Button>
            <Button 
              variant="outline"
              onClick={() => router.push("/crane-selection/profile")}
            >
              <User className="mr-2 h-4 w-4" />
              Profile
            </Button>
            <Button 
              variant="destructive"
              onClick={handleLogout}
            >
              <LogOut className="mr-2 h-4 w-4" />
              Logout
            </Button>
          </div>
        </div>

        {/* Crane Models Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {craneModels.map((crane) => (
            <Card
              key={crane.id}
              className="hover:shadow-lg transition-shadow cursor-pointer"
              onClick={() => router.push('/dashboard')}
            >
              <CardHeader>
                <CardTitle>{crane.name}</CardTitle>
                <CardDescription>{crane.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="aspect-square relative mb-4">
                  <Image
                    src={crane.image}
                    alt={crane.name}
                    fill
                    className="object-cover rounded-md"
                    sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 25vw"
                  />
                </div>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="font-medium">Capacity:</span>
                    <span>{crane.specs.capacity}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-medium">Reach:</span>
                    <span>{crane.specs.reach}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-medium">Type:</span>
                    <span>{crane.specs.type}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="font-medium">Fuel Level:</span>
                    <FuelGauge level={crane.specs.fuelLevel} />
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* About Us Section with Logo */}
        <div className="max-w-6xl mx-auto">
          <Separator className="mb-12" />
          <div className="grid md:grid-cols-2 gap-12 items-start">
            {/* About Us Content */}
            <div>
              <div className="text-center md:text-left mb-8">
                <h2 className="text-3xl font-bold text-gray-900 mb-2">About Us</h2>
                <div className="h-1 w-20 bg-primary rounded-full md:mx-0 mx-auto"></div>
              </div>
              <div className="prose prose-lg max-w-none text-gray-600 space-y-6">
                <p className="leading-relaxed">
                  At Crane Monitor Pro, we are transforming crane operations with AI-driven fuel optimization, 
                  real-time monitoring, and predictive maintenance. Our advanced platform helps businesses 
                  reduce fuel consumption, minimize operational costs, and maximize crane efficiency with 
                  data-driven insights and smart automation. By continuously analyzing performance metrics, 
                  we enable operators to detect potential issues early, preventing costly breakdowns and 
                  ensuring uninterrupted productivity.
                </p>
                <p className="leading-relaxed">
                  Designed for seamless integration across various crane models, Crane Monitor Pro provides 
                  a user-friendly dashboard, real-time analytics, and intelligent recommendations to enhance 
                  decision-making and streamline operations. With a focus on efficiency, reliability, and 
                  sustainability, we empower businesses to get the most out of every lift while reducing 
                  their environmental impact.
                </p>
              </div>
            </div>

            {/* Logo */}
            <div className="flex justify-center items-center">
              <div className="w-full h-[400px] relative">
                <Image
                  src="/images/logo.jpg"
                  alt="Crane Monitor Pro Logo"
                  fill
                  style={{ objectFit: 'contain' }}
                  priority
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}