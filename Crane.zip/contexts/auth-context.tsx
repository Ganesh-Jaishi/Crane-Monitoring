"use client"

import type React from "react"

import { createContext, useContext, useEffect, useState } from "react"
import type { User, Session } from "@supabase/supabase-js"
import { getSupabaseClient } from "@/lib/supabase/client"

type AuthContextType = {
  user: User | null
  session: Session | null
  isLoading: boolean
  signIn: (email: string, password: string) => Promise<{ error: any }>
  signInWithPhone: (phone: string, password: string) => Promise<{ error: any }>
  signUp: (email: string, password: string, phone?: string) => Promise<{ error: any; data: any }>
  signOut: () => Promise<void>
  resetPassword: (email: string) => Promise<{ error: any }>
  updatePassword: (password: string) => Promise<{ error: any }>
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [session, setSession] = useState<Session | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const supabase = getSupabaseClient()

  useEffect(() => {
    const setData = async () => {
      try {
        const {
          data: { session },
          error,
        } = await supabase.auth.getSession()
        if (error) {
          console.error(error)
        }

        setSession(session)
        setUser(session?.user ?? null)
        setIsLoading(false)
      } catch (err) {
        console.error("Failed to initialize Supabase client:", err)
        setIsLoading(false)
      }
    }

    try {
      const {
        data: { subscription },
      } = supabase.auth.onAuthStateChange((_event, session) => {
        setSession(session)
        setUser(session?.user ?? null)
        setIsLoading(false)
      })

      setData()

      return () => {
        subscription.unsubscribe()
      }
    } catch (err) {
      console.error("Failed to initialize Supabase client:", err)
      setIsLoading(false)
      return () => {}
    }
  }, [])

  const signIn = async (email: string, password: string) => {
    try {
      const { data, error } = await supabase.auth.signInWithPassword({ email, password })

      if (!error && data.session) {
        // Hard redirect to dashboard on successful login
        window.location.href = "/dashboard"
      }

      return { error }
    } catch (err: any) {
      return { error: err }
    }
  }

  const signInWithPhone = async (phone: string, password: string) => {
    try {
      // In a real implementation, you would use Supabase phone auth
      // For now, we'll simulate it with email auth
      const { data, error } = await supabase.auth.signInWithPassword({
        email: `${phone}@phone.user`,
        password,
      })

      if (!error && data.session) {
        // Hard redirect to dashboard on successful login
        window.location.href = "/dashboard"
      }

      return { error }
    } catch (err: any) {
      return { error: err }
    }
  }

  const signUp = async (email: string, password: string, phone?: string) => {
    try {
      // Check if user already exists
      const { data: existingUsers, error: checkError } = await supabase.from("profiles").select("*").eq("email", email)

      if (checkError) {
        console.error("Error checking existing user:", checkError)
      } else if (existingUsers && existingUsers.length > 0) {
        return {
          error: { message: "User with this email already exists" },
          data: null,
        }
      }

      // Proceed with signup
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            phone: phone || null,
          },
        },
      })

      // Create profile entry
      if (!error && data.user) {
        const { error: profileError } = await supabase.from("profiles").insert([
          {
            id: data.user.id,
            email: email,
            phone: phone || null,
          },
        ])

        if (profileError) {
          console.error("Error creating profile:", profileError)
        }
      }

      return { data, error }
    } catch (err: any) {
      return { data: null, error: err }
    }
  }

  const signOut = async () => {
    try {
      await supabase.auth.signOut()
      // Hard redirect to login page
      window.location.href = "/login"
    } catch (err) {
      console.error("Error signing out:", err)
    }
  }

  const resetPassword = async (email: string) => {
    try {
      const { error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: `${window.location.origin}/reset-password`,
      })
      return { error }
    } catch (err: any) {
      return { error: err }
    }
  }

  const updatePassword = async (password: string) => {
    try {
      const { error } = await supabase.auth.updateUser({ password })
      return { error }
    } catch (err: any) {
      return { error: err }
    }
  }

  const value = {
    user,
    session,
    isLoading,
    signIn,
    signInWithPhone,
    signUp,
    signOut,
    resetPassword,
    updatePassword,
  }

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}

