import { Badge } from "@/components/ui/badge"
import { cn } from "@/lib/utils"
import { AlertCircle, AlertTriangle, Info } from "lucide-react"

interface Alert {
  id: string
  alert_type: string
  severity: string
  message: string
  timestamp: string
  acknowledged: boolean
}

interface RealTimeAlertsProps {
  alerts: Alert[]
}

export function RealTimeAlerts({ alerts }: RealTimeAlertsProps) {
  if (!alerts || alerts.length === 0) {
    return (
      <div className="flex h-[300px] items-center justify-center text-sm text-muted-foreground">No recent alerts</div>
    )
  }

  return (
    <div className="space-y-4 max-h-[300px] overflow-auto pr-2">
      {alerts.map((alert) => (
        <div key={alert.id} className="flex items-start space-x-3 rounded-md border p-3">
          <div className="flex-shrink-0">
            {alert.severity === "critical" && <AlertCircle className="h-5 w-5 text-red-500" />}
            {alert.severity === "warning" && <AlertTriangle className="h-5 w-5 text-yellow-500" />}
            {alert.severity === "info" && <Info className="h-5 w-5 text-blue-500" />}
          </div>
          <div className="flex-1 space-y-1">
            <div className="flex items-center justify-between">
              <p className="text-sm font-medium">{alert.alert_type}</p>
              <Badge
                variant="outline"
                className={cn(
                  alert.severity === "critical" && "border-red-500 text-red-500",
                  alert.severity === "warning" && "border-yellow-500 text-yellow-500",
                  alert.severity === "info" && "border-blue-500 text-blue-500",
                )}
              >
                {alert.severity}
              </Badge>
            </div>
            <p className="text-xs text-muted-foreground">{alert.message}</p>
            <div className="flex items-center justify-between pt-1">
              <p className="text-xs text-muted-foreground">{new Date(alert.timestamp).toLocaleString()}</p>
              {alert.acknowledged ? (
                <Badge variant="outline" className="text-xs">
                  Acknowledged
                </Badge>
              ) : (
                <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200 text-xs">
                  New
                </Badge>
              )}
            </div>
          </div>
        </div>
      ))}
    </div>
  )
}

