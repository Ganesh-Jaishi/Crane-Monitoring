"use client"

import { useEffect, useState } from "react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { CheckCircle2, Clock, FileText, XCircle } from "lucide-react"
import { cn } from "@/lib/utils"

interface MaintenanceHistoryProps {
  craneId: string | null
}

export function MaintenanceHistory({ craneId }: MaintenanceHistoryProps) {
  const [historyData, setHistoryData] = useState<any[]>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    if (!craneId) return

    const fetchData = async () => {
      setIsLoading(true)

      // In a real app, you would fetch this data from your API
      // For now, we'll use mock data
      const mockData = [
        {
          id: "1",
          date: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
          maintenance_type: "Preventive",
          description: "Monthly inspection and lubrication",
          duration: "3.5 hours",
          technician: "John Smith",
          status: "Completed",
          findings: "No issues found",
        },
        {
          id: "2",
          date: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000).toISOString(),
          maintenance_type: "Electrical",
          description: "Control system diagnostics",
          duration: "5 hours",
          technician: "Sarah Johnson",
          status: "Completed",
          findings: "Replaced worn contactors",
        },
        {
          id: "3",
          date: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
          maintenance_type: "Mechanical",
          description: "Brake system inspection",
          duration: "4 hours",
          technician: "Mike Davis",
          status: "Completed",
          findings: "Adjusted brake clearance",
        },
        {
          id: "4",
          date: new Date(Date.now() - 45 * 24 * 60 * 60 * 1000).toISOString(),
          maintenance_type: "Safety",
          description: "Limit switch testing",
          duration: "2 hours",
          technician: "Lisa Chen",
          status: "Incomplete",
          findings: "Replacement parts needed",
        },
        {
          id: "5",
          date: new Date(Date.now() - 60 * 24 * 60 * 60 * 1000).toISOString(),
          maintenance_type: "Preventive",
          description: "Quarterly comprehensive inspection",
          duration: "8 hours",
          technician: "John Smith",
          status: "Completed",
          findings: "Replaced worn wire rope",
        },
      ]

      setHistoryData(mockData)
      setIsLoading(false)
    }

    fetchData()
  }, [craneId])

  if (isLoading) {
    return (
      <div className="flex h-[300px] items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent" />
      </div>
    )
  }

  return (
    <div className="rounded-md border">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="w-[180px]">Date</TableHead>
            <TableHead>Type</TableHead>
            <TableHead className="hidden md:table-cell">Description</TableHead>
            <TableHead className="hidden md:table-cell">Duration</TableHead>
            <TableHead className="hidden md:table-cell">Technician</TableHead>
            <TableHead>Status</TableHead>
            <TableHead className="text-right">Report</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {historyData.map((item) => (
            <TableRow key={item.id}>
              <TableCell>{new Date(item.date).toLocaleDateString()}</TableCell>
              <TableCell>{item.maintenance_type}</TableCell>
              <TableCell className="hidden md:table-cell">{item.description}</TableCell>
              <TableCell className="hidden md:table-cell">
                <div className="flex items-center gap-2">
                  <Clock className="h-4 w-4 text-muted-foreground" />
                  {item.duration}
                </div>
              </TableCell>
              <TableCell className="hidden md:table-cell">{item.technician}</TableCell>
              <TableCell>
                <div className="flex items-center gap-2">
                  {item.status === "Completed" ? (
                    <CheckCircle2 className="h-4 w-4 text-green-500" />
                  ) : (
                    <XCircle className="h-4 w-4 text-red-500" />
                  )}
                  <span
                    className={cn(
                      item.status === "Completed" ? "text-green-600" : "text-red-600",
                      "text-sm font-medium",
                    )}
                  >
                    {item.status}
                  </span>
                </div>
              </TableCell>
              <TableCell className="text-right">
                <Button variant="outline" size="sm">
                  <FileText className="mr-2 h-4 w-4" />
                  View
                </Button>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}

