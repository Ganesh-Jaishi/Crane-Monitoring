"use client"

import { useEffect, useState } from "react"
import { Bar, BarChart, ResponsiveContainer, XAxis, YAxis } from "recharts"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"

interface EnergyComparisonChartProps {
  craneId: string | null
}

export function EnergyComparisonChart({ craneId }: EnergyComparisonChartProps) {
  const [data, setData] = useState<any[]>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    if (!craneId) return

    const fetchData = async () => {
      setIsLoading(true)

      // In a real app, you would fetch this data from your API
      // For now, we'll use mock data
      const mockData = [
        {
          name: "Your Crane",
          energy: 42.8,
          fuel: 5.2,
          co2: 12.5,
        },
        {
          name: "Fleet Average",
          energy: 58.3,
          fuel: 6.8,
          co2: 16.2,
        },
        {
          name: "Industry Benchmark",
          energy: 50.1,
          fuel: 6.1,
          co2: 14.8,
        },
        {
          name: "Best in Class",
          energy: 38.5,
          fuel: 4.7,
          co2: 11.2,
        },
      ]

      setData(mockData)
      setIsLoading(false)
    }

    fetchData()
  }, [craneId])

  if (isLoading) {
    return (
      <div className="flex h-[300px] items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent" />
      </div>
    )
  }

  return (
    <ChartContainer
      config={{
        energy: {
          label: "Energy (kWh)",
          color: "hsl(var(--chart-1))",
        },
        fuel: {
          label: "Fuel (L/h)",
          color: "hsl(var(--chart-2))",
        },
        co2: {
          label: "CO2 (tons)",
          color: "hsl(var(--chart-3))",
        },
      }}
      className="h-[300px]"
    >
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data}>
          <XAxis dataKey="name" stroke="#888888" fontSize={12} tickLine={false} axisLine={false} />
          <YAxis
            stroke="#888888"
            fontSize={12}
            tickLine={false}
            axisLine={false}
            tickFormatter={(value) => `${value}`}
          />
          <ChartTooltip content={<ChartTooltipContent />} />
          <Bar dataKey="energy" fill="var(--color-energy)" radius={[4, 4, 0, 0]} />
          <Bar dataKey="fuel" fill="var(--color-fuel)" radius={[4, 4, 0, 0]} />
          <Bar dataKey="co2" fill="var(--color-co2)" radius={[4, 4, 0, 0]} />
        </BarChart>
      </ResponsiveContainer>
    </ChartContainer>
  )
}

