"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Battery, Droplet, Leaf, Lightbulb, Zap } from "lucide-react"
import { cn } from "@/lib/utils"

interface EnergySuggestion {
  id: string
  title: string
  description: string
  impact: "high" | "medium" | "low"
  savings: string
  icon: React.ElementType
  actionable: boolean
}

interface EnergyOptimizationSuggestionsProps {
  craneId: string | null
  electricalData?: any
  mechanicalData?: any
  energyData?: any
}

export function EnergyOptimizationSuggestions({
  craneId,
  electricalData,
  mechanicalData,
  energyData,
}: EnergyOptimizationSuggestionsProps) {
  const [suggestions, setSuggestions] = useState<EnergySuggestion[]>([])

  useEffect(() => {
    if (!craneId || !electricalData || !mechanicalData) return

    // In a real app, you would analyze the real-time data to generate dynamic suggestions
    // Here we'll simulate this by creating suggestions based on the data

    const currentSuggestions: EnergySuggestion[] = []

    // Check power consumption
    const powerConsumption = electricalData.power_consumption || 0
    if (powerConsumption > 40) {
      currentSuggestions.push({
        id: "1",
        title: "High Power Consumption Detected",
        description:
          "Current power usage is above optimal levels. Consider reducing operational speed during non-critical tasks.",
        impact: "high",
        savings: "15-20% power reduction",
        icon: Zap,
        actionable: true,
      })
    }

    // Check load efficiency
    const loadWeight = mechanicalData.load_weight || 0
    const maxCapacity = 5000 // kg
    const loadPercentage = loadWeight / maxCapacity

    if (loadPercentage < 0.3 && loadWeight > 0) {
      currentSuggestions.push({
        id: "2",
        title: "Low Load Efficiency",
        description:
          "Current load is below 30% of capacity. Consider consolidating operations to improve fuel efficiency.",
        impact: "medium",
        savings: "10-15% fuel savings",
        icon: Droplet,
        actionable: true,
      })
    }

    // Check idle time
    const isIdle = mechanicalData.is_idle || false
    const idleTime = mechanicalData.idle_time || 0

    if (isIdle && idleTime > 5) {
      currentSuggestions.push({
        id: "3",
        title: "Extended Idle Time",
        description: `Crane has been idle for ${idleTime} minutes. Consider activating auto-shutdown to save fuel.`,
        impact: "high",
        savings: "Up to 25% fuel reduction",
        icon: Battery,
        actionable: true,
      })
    }

    // Check regenerative braking
    const regenerativeBrakingEnabled = energyData?.regenerative_braking_enabled || false

    if (!regenerativeBrakingEnabled) {
      currentSuggestions.push({
        id: "4",
        title: "Enable Regenerative Braking",
        description:
          "Regenerative braking is currently disabled. Enable it to recover energy during lowering operations.",
        impact: "high",
        savings: "Up to 20% energy recovery",
        icon: Leaf,
        actionable: true,
      })
    }

    // Add a general optimization tip
    currentSuggestions.push({
      id: "5",
      title: "Optimize Acceleration Profiles",
      description: "Gradual acceleration and deceleration can significantly reduce energy consumption.",
      impact: "medium",
      savings: "8-12% energy savings",
      icon: Lightbulb,
      actionable: false,
    })

    setSuggestions(currentSuggestions)
  }, [craneId, electricalData, mechanicalData, energyData])

  if (suggestions.length === 0) {
    return (
      <div className="flex h-[200px] items-center justify-center text-sm text-muted-foreground">
        No optimization suggestions available
      </div>
    )
  }

  return (
    <div className="space-y-4">
      {suggestions.map((suggestion) => (
        <Card
          key={suggestion.id}
          className={cn(
            "border-l-4",
            suggestion.impact === "high" && "border-l-red-500",
            suggestion.impact === "medium" && "border-l-yellow-500",
            suggestion.impact === "low" && "border-l-green-500",
          )}
        >
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-base font-medium flex items-center gap-2">
              <suggestion.icon
                className={cn(
                  "h-5 w-5",
                  suggestion.impact === "high" && "text-red-500",
                  suggestion.impact === "medium" && "text-yellow-500",
                  suggestion.impact === "low" && "text-green-500",
                )}
              />
              {suggestion.title}
            </CardTitle>
            <Badge
              variant="outline"
              className={cn(
                suggestion.impact === "high" && "border-red-500 text-red-500",
                suggestion.impact === "medium" && "border-yellow-500 text-yellow-500",
                suggestion.impact === "low" && "border-green-500 text-green-500",
              )}
            >
              {suggestion.impact === "high"
                ? "High Impact"
                : suggestion.impact === "medium"
                  ? "Medium Impact"
                  : "Low Impact"}
            </Badge>
          </CardHeader>
          <CardContent className="pb-4">
            <p className="text-sm text-muted-foreground mb-3">{suggestion.description}</p>
            <div className="flex items-center justify-between">
              <Badge variant="secondary" className="text-xs">
                Potential savings: {suggestion.savings}
              </Badge>
              {suggestion.actionable && (
                <Button size="sm" variant="outline">
                  Apply Optimization
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}

