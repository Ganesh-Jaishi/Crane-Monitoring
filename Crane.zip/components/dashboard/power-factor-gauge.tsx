"use client"

import { useEffect, useRef } from "react"

interface PowerFactorGaugeProps {
  value: number
}

export function PowerFactorGauge({ value }: PowerFactorGaugeProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    // Set dimensions
    const width = canvas.width
    const height = canvas.height
    const centerX = width / 2
    const centerY = height / 2
    const radius = Math.min(width, height) / 2 - 10

    // Draw background arc
    ctx.beginPath()
    ctx.arc(centerX, centerY, radius, Math.PI, 2 * Math.PI, false)
    ctx.lineWidth = 20
    ctx.strokeStyle = "#e5e7eb"
    ctx.stroke()

    // Calculate color based on value
    let color = "#ef4444" // red for low values
    if (value >= 0.85) {
      color = "#22c55e" // green for good values
    } else if (value >= 0.7) {
      color = "#f59e0b" // yellow for medium values
    }

    // Draw value arc
    const angle = Math.PI + value * Math.PI
    ctx.beginPath()
    ctx.arc(centerX, centerY, radius, Math.PI, angle, false)
    ctx.lineWidth = 20
    ctx.strokeStyle = color
    ctx.stroke()

    // Draw center circle
    ctx.beginPath()
    ctx.arc(centerX, centerY, radius - 40, 0, 2 * Math.PI, false)
    ctx.fillStyle = "#f8fafc"
    ctx.fill()
    ctx.lineWidth = 2
    ctx.strokeStyle = "#e2e8f0"
    ctx.stroke()

    // Draw value text
    ctx.font = "bold 24px Arial"
    ctx.fillStyle = "#0f172a"
    ctx.textAlign = "center"
    ctx.textBaseline = "middle"
    ctx.fillText(value.toFixed(2), centerX, centerY - 10)

    // Draw label
    ctx.font = "14px Arial"
    ctx.fillStyle = "#64748b"
    ctx.fillText("Power Factor", centerX, centerY + 20)
  }, [value])

  return <canvas ref={canvasRef} width={200} height={200} className="max-w-full h-auto" />
}

