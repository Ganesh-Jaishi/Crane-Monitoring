"use client"

import { useEffect, useState } from "react"
import { Line, LineChart, ResponsiveContainer, XAxis, YAxis } from "recharts"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"

interface WindSpeedChartProps {
  craneId: string | null
}

export function WindSpeedChart({ craneId }: WindSpeedChartProps) {
  const [data, setData] = useState<any[]>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    if (!craneId) return

    const fetchData = async () => {
      setIsLoading(true)

      // In a real app, you would fetch this data from your API
      // For now, we'll use mock data
      const mockData = Array.from({ length: 24 }, (_, i) => {
        const hour = i.toString().padStart(2, "0") + ":00"
        // Create wind speed pattern
        const windSpeed = 5 + Math.sin(i / 3) * 3 + Math.random() * 2
        return {
          time: hour,
          wind: Number.parseFloat(windSpeed.toFixed(1)),
        }
      })

      setData(mockData)
      setIsLoading(false)
    }

    fetchData()
  }, [craneId])

  if (isLoading) {
    return (
      <div className="flex h-[300px] items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent" />
      </div>
    )
  }

  return (
    <ChartContainer
      config={{
        wind: {
          label: "Wind Speed (m/s)",
          color: "hsl(var(--chart-1))",
        },
      }}
      className="h-[300px]"
    >
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data}>
          <XAxis dataKey="time" stroke="#888888" fontSize={12} tickLine={false} axisLine={false} />
          <YAxis
            stroke="#888888"
            fontSize={12}
            tickLine={false}
            axisLine={false}
            tickFormatter={(value) => `${value} m/s`}
          />
          <ChartTooltip content={<ChartTooltipContent />} />
          <Line type="monotone" dataKey="wind" stroke="var(--color-wind)" strokeWidth={2} dot={false} />
          {/* Add threshold lines */}
          <Line
            type="monotone"
            dataKey="threshold"
            stroke="#ef4444"
            strokeWidth={1}
            strokeDasharray="5 5"
            data={Array(24).fill({ threshold: 15 })}
            dot={false}
          />
        </LineChart>
      </ResponsiveContainer>
    </ChartContainer>
  )
}

