"use client"

import { useEffect, useState } from "react"
import { Line, LineChart, ResponsiveContainer, XAxis, YAxis } from "recharts"
import { getSupabaseClient } from "@/lib/supabase/client"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"

interface ElectricalChartProps {
  craneId: string | null
}

export function ElectricalChart({ craneId }: ElectricalChartProps) {
  const [data, setData] = useState<any[]>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    if (!craneId) return

    const fetchData = async () => {
      setIsLoading(true)
      const supabase = getSupabaseClient()
      const { data, error } = await supabase
        .from("electrical_parameters")
        .select("*")
        .eq("crane_id", craneId)
        .order("timestamp", { ascending: true })
        .limit(24)

      if (error) {
        console.error("Error fetching electrical data:", error)
        return
      }

      // Format the data for the chart
      const formattedData =
        data?.map((item) => ({
          time: new Date(item.timestamp).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
          voltage: item.voltage,
          current: item.current,
          power: item.power_consumption,
        })) || []

      setData(formattedData)
      setIsLoading(false)
    }

    fetchData()

    // In a real app, you might want to set up a subscription or polling here
  }, [craneId])

  if (isLoading) {
    return (
      <div className="flex h-[300px] items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent" />
      </div>
    )
  }

  // If no data, show a message
  if (data.length === 0) {
    return (
      <div className="flex h-[300px] items-center justify-center text-muted-foreground">
        No electrical data available
      </div>
    )
  }

  return (
    <ChartContainer
      config={{
        voltage: {
          label: "Voltage (V)",
          color: "hsl(var(--chart-1))",
        },
        current: {
          label: "Current (A)",
          color: "hsl(var(--chart-2))",
        },
        power: {
          label: "Power (kW)",
          color: "hsl(var(--chart-3))",
        },
      }}
      className="h-[300px]"
    >
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data}>
          <XAxis dataKey="time" stroke="#888888" fontSize={12} tickLine={false} axisLine={false} />
          <YAxis
            stroke="#888888"
            fontSize={12}
            tickLine={false}
            axisLine={false}
            tickFormatter={(value) => `${value}`}
          />
          <ChartTooltip content={<ChartTooltipContent />} />
          <Line type="monotone" dataKey="voltage" stroke="var(--color-voltage)" strokeWidth={2} dot={false} />
          <Line type="monotone" dataKey="current" stroke="var(--color-current)" strokeWidth={2} dot={false} />
          <Line type="monotone" dataKey="power" stroke="var(--color-power)" strokeWidth={2} dot={false} />
        </LineChart>
      </ResponsiveContainer>
    </ChartContainer>
  )
}

