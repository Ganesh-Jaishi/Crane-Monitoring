"use client"

import { useEffect, useRef } from "react"

// Update the RealTimeGaugesProps interface to include fuel and energy data
interface RealTimeGaugesProps {
  electricalData: any
  mechanicalData: any
  safetyData: any
  energyData?: any
}

// Update the component to include fuel consumption and energy efficiency gauges
export function RealTimeGauges({ electricalData, mechanicalData, safetyData, energyData }: RealTimeGaugesProps) {
  const powerGaugeRef = useRef<HTMLCanvasElement>(null)
  const loadGaugeRef = useRef<HTMLCanvasElement>(null)
  const fuelGaugeRef = useRef<HTMLCanvasElement>(null)
  const efficiencyGaugeRef = useRef<HTMLCanvasElement>(null)

  // Draw power gauge
  useEffect(() => {
    const canvas = powerGaugeRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const power = electricalData?.power_consumption || 0
    const maxPower = 100 // kW
    const percentage = Math.min(power / maxPower, 1)

    drawGauge(
      ctx,
      canvas.width,
      canvas.height,
      percentage,
      `${power} kW`,
      "Power Consumption",
      getColorForPercentage(percentage),
    )
  }, [electricalData])

  // Draw load gauge
  useEffect(() => {
    const canvas = loadGaugeRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const load = mechanicalData?.load_weight || 0
    const maxLoad = 5000 // kg
    const percentage = Math.min(load / maxLoad, 1)

    drawGauge(
      ctx,
      canvas.width,
      canvas.height,
      percentage,
      `${load} kg`,
      "Load Weight",
      getColorForPercentage(percentage),
    )
  }, [mechanicalData])

  // Draw fuel consumption gauge
  useEffect(() => {
    const canvas = fuelGaugeRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const fuel = energyData?.fuel_consumption || 5.2
    const maxFuel = 10 // L/h
    const percentage = Math.min(fuel / maxFuel, 1)
    // For fuel, lower is better, so invert the color logic
    const invertedPercentage = 1 - percentage

    drawGauge(
      ctx,
      canvas.width,
      canvas.height,
      percentage,
      `${fuel} L/h`,
      "Fuel Consumption",
      getColorForPercentage(invertedPercentage),
    )
  }, [energyData])

  // Draw energy efficiency gauge
  useEffect(() => {
    const canvas = efficiencyGaugeRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const efficiency = energyData?.energy_efficiency || 87
    const percentage = efficiency / 100

    drawGauge(
      ctx,
      canvas.width,
      canvas.height,
      percentage,
      `${efficiency}%`,
      "Energy Efficiency",
      getColorForPercentage(percentage),
    )
  }, [energyData])

  // Helper function to draw a gauge
  const drawGauge = (
    ctx: CanvasRenderingContext2D,
    width: number,
    height: number,
    percentage: number,
    value: string,
    label: string,
    color: string,
  ) => {
    // Clear canvas
    ctx.clearRect(0, 0, width, height)

    // Set dimensions
    const centerX = width / 2
    const centerY = height / 2
    const radius = Math.min(width, height) / 2 - 10

    // Draw background arc
    ctx.beginPath()
    ctx.arc(centerX, centerY, radius, Math.PI, 2 * Math.PI, false)
    ctx.lineWidth = 15
    ctx.strokeStyle = "#e5e7eb"
    ctx.stroke()

    // Draw value arc
    const angle = Math.PI + percentage * Math.PI
    ctx.beginPath()
    ctx.arc(centerX, centerY, radius, Math.PI, angle, false)
    ctx.lineWidth = 15
    ctx.strokeStyle = color
    ctx.stroke()

    // Draw center circle
    ctx.beginPath()
    ctx.arc(centerX, centerY, radius - 30, 0, 2 * Math.PI, false)
    ctx.fillStyle = "#f8fafc"
    ctx.fill()
    ctx.lineWidth = 2
    ctx.strokeStyle = "#e2e8f0"
    ctx.stroke()

    // Draw value text
    ctx.font = "bold 16px Arial"
    ctx.fillStyle = "#0f172a"
    ctx.textAlign = "center"
    ctx.textBaseline = "middle"
    ctx.fillText(value, centerX, centerY - 5)

    // Draw label
    ctx.font = "12px Arial"
    ctx.fillStyle = "#64748b"
    ctx.fillText(label, centerX, centerY + 15)
  }

  // Helper function to get color based on percentage
  const getColorForPercentage = (percentage: number) => {
    if (percentage < 0.6) {
      return "#ef4444" // red for poor
    } else if (percentage < 0.8) {
      return "#f59e0b" // yellow for average
    } else {
      return "#22c55e" // green for good
    }
  }

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
      <div className="flex flex-col items-center">
        <canvas ref={powerGaugeRef} width={150} height={150} className="max-w-full h-auto" />
      </div>
      <div className="flex flex-col items-center">
        <canvas ref={fuelGaugeRef} width={150} height={150} className="max-w-full h-auto" />
      </div>
      <div className="flex flex-col items-center">
        <canvas ref={efficiencyGaugeRef} width={150} height={150} className="max-w-full h-auto" />
      </div>
      <div className="flex flex-col items-center">
        <canvas ref={loadGaugeRef} width={150} height={150} className="max-w-full h-auto" />
      </div>
    </div>
  )
}

