import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { cn } from "@/lib/utils"

interface SafetyStatusCardProps {
  title: string
  status: string
  description: string
  variant: "success" | "warning" | "danger"
}

export function SafetyStatusCard({ title, status, description, variant }: SafetyStatusCardProps) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        <div
          className={cn(
            "h-3 w-3 rounded-full",
            variant === "success" && "bg-green-500",
            variant === "warning" && "bg-yellow-500",
            variant === "danger" && "bg-red-500",
          )}
        />
      </CardHeader>
      <CardContent>
        <div
          className={cn(
            "text-2xl font-bold",
            variant === "success" && "text-green-700 dark:text-green-500",
            variant === "warning" && "text-yellow-700 dark:text-yellow-500",
            variant === "danger" && "text-red-700 dark:text-red-500",
          )}
        >
          {status}
        </div>
        <p className="text-xs text-muted-foreground">{description}</p>
      </CardContent>
    </Card>
  )
}

