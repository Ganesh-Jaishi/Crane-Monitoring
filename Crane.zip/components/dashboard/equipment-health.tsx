"use client"

import { useEffect, useState } from "react"
import { Progress } from "@/components/ui/progress"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { cn } from "@/lib/utils"

interface EquipmentHealthProps {
  craneId: string | null
}

export function EquipmentHealth({ craneId }: EquipmentHealthProps) {
  const [healthData, setHealthData] = useState<any[]>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    if (!craneId) return

    const fetchData = async () => {
      setIsLoading(true)

      // In a real app, you would fetch this data from your API
      // For now, we'll use mock data
      const mockData = [
        {
          id: "1",
          component: "Main Hoist Motor",
          health_score: 92,
          last_inspection: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000).toISOString(),
          estimated_lifespan: "85%",
          notes: "Operating within normal parameters",
        },
        {
          id: "2",
          component: "Gearbox",
          health_score: 78,
          last_inspection: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000).toISOString(),
          estimated_lifespan: "60%",
          notes: "Showing signs of wear, monitor closely",
        },
        {
          id: "3",
          component: "Wire Rope",
          health_score: 85,
          last_inspection: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000).toISOString(),
          estimated_lifespan: "70%",
          notes: "Some wear detected, within acceptable limits",
        },
        {
          id: "4",
          component: "Control System",
          health_score: 95,
          last_inspection: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000).toISOString(),
          estimated_lifespan: "90%",
          notes: "Recently upgraded, excellent condition",
        },
        {
          id: "5",
          component: "Brake System",
          health_score: 88,
          last_inspection: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000).toISOString(),
          estimated_lifespan: "75%",
          notes: "Functioning properly, routine maintenance recommended",
        },
        {
          id: "6",
          component: "Structural Components",
          health_score: 90,
          last_inspection: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000).toISOString(),
          estimated_lifespan: "80%",
          notes: "No structural issues detected",
        },
      ]

      setHealthData(mockData)
      setIsLoading(false)
    }

    fetchData()
  }, [craneId])

  if (isLoading) {
    return (
      <div className="flex h-[300px] items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent" />
      </div>
    )
  }

  const getHealthColor = (score: number) => {
    if (score >= 90) return "bg-green-500"
    if (score >= 70) return "bg-yellow-500"
    return "bg-red-500"
  }

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
      {healthData.map((item) => (
        <Card key={item.id}>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">{item.component}</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Health Score</span>
              <span
                className={cn(
                  "text-sm font-medium",
                  item.health_score >= 90 && "text-green-600",
                  item.health_score >= 70 && item.health_score < 90 && "text-yellow-600",
                  item.health_score < 70 && "text-red-600",
                )}
              >
                {item.health_score}%
              </span>
            </div>
            <Progress
              value={item.health_score}
              className="h-2 w-full bg-muted"
              indicatorClassName={cn(
                item.health_score >= 90 && "bg-green-500",
                item.health_score >= 70 && item.health_score < 90 && "bg-yellow-500",
                item.health_score < 70 && "bg-red-500",
              )}
            />
            <div className="flex items-center justify-between text-xs">
              <span className="text-muted-foreground">Last Inspection:</span>
              <span>{new Date(item.last_inspection).toLocaleDateString()}</span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-muted-foreground">Estimated Lifespan:</span>
              <span>{item.estimated_lifespan}</span>
            </div>
            <p className="text-xs text-muted-foreground">{item.notes}</p>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}

