"use client"

import { useState } from "react"
import { Line, LineChart, ResponsiveContainer, XAxis, YAxis } from "recharts"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"

// Sample data - in a real app, this would come from your API
const data = [
  { time: "00:00", power: 32, load: 2100, temp: 58 },
  { time: "01:00", power: 28, load: 1800, temp: 55 },
  { time: "02:00", power: 25, load: 1600, temp: 53 },
  { time: "03:00", power: 24, load: 1500, temp: 52 },
  { time: "04:00", power: 26, load: 1700, temp: 54 },
  { time: "05:00", power: 30, load: 2000, temp: 56 },
  { time: "06:00", power: 35, load: 2300, temp: 59 },
  { time: "07:00", power: 42, load: 2800, temp: 62 },
  { time: "08:00", power: 45, load: 3000, temp: 64 },
  { time: "09:00", power: 48, load: 3200, temp: 65 },
  { time: "10:00", power: 50, load: 3300, temp: 66 },
  { time: "11:00", power: 47, load: 3100, temp: 65 },
  { time: "12:00", power: 45, load: 3000, temp: 64 },
  { time: "13:00", power: 43, load: 2900, temp: 63 },
  { time: "14:00", power: 42, load: 2800, temp: 62 },
  { time: "15:00", power: 40, load: 2700, temp: 61 },
  { time: "16:00", power: 38, load: 2500, temp: 60 },
  { time: "17:00", power: 35, load: 2300, temp: 59 },
  { time: "18:00", power: 32, load: 2100, temp: 58 },
  { time: "19:00", power: 30, load: 2000, temp: 57 },
  { time: "20:00", power: 28, load: 1800, temp: 56 },
  { time: "21:00", power: 26, load: 1700, temp: 55 },
  { time: "22:00", power: 25, load: 1600, temp: 54 },
  { time: "23:00", power: 24, load: 1500, temp: 53 },
]

export function OverviewChart() {
  const [activeMetrics, setActiveMetrics] = useState({
    power: true,
    load: true,
    temp: true,
  })

  const toggleMetric = (metric: keyof typeof activeMetrics) => {
    setActiveMetrics((prev) => ({
      ...prev,
      [metric]: !prev[metric],
    }))
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap gap-2">
        <button
          onClick={() => toggleMetric("power")}
          className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ${
            activeMetrics.power
              ? "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300"
              : "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300"
          }`}
        >
          Power Consumption (kW)
        </button>
        <button
          onClick={() => toggleMetric("load")}
          className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ${
            activeMetrics.load
              ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300"
              : "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300"
          }`}
        >
          Load Weight (kg)
        </button>
        <button
          onClick={() => toggleMetric("temp")}
          className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ${
            activeMetrics.temp
              ? "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300"
              : "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300"
          }`}
        >
          Motor Temperature (°C)
        </button>
      </div>

      <ChartContainer
        config={{
          power: {
            label: "Power Consumption (kW)",
            color: "hsl(var(--chart-1))",
          },
          load: {
            label: "Load Weight (kg)",
            color: "hsl(var(--chart-2))",
          },
          temp: {
            label: "Motor Temperature (°C)",
            color: "hsl(var(--chart-3))",
          },
        }}
        className="h-[300px]"
      >
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data}>
            <XAxis dataKey="time" stroke="#888888" fontSize={12} tickLine={false} axisLine={false} />
            <YAxis
              stroke="#888888"
              fontSize={12}
              tickLine={false}
              axisLine={false}
              tickFormatter={(value) => `${value}`}
            />
            <ChartTooltip content={<ChartTooltipContent />} />
            {activeMetrics.power && (
              <Line type="monotone" dataKey="power" stroke="var(--color-power)" strokeWidth={2} dot={false} />
            )}
            {activeMetrics.load && (
              <Line type="monotone" dataKey="load" stroke="var(--color-load)" strokeWidth={2} dot={false} />
            )}
            {activeMetrics.temp && (
              <Line type="monotone" dataKey="temp" stroke="var(--color-temp)" strokeWidth={2} dot={false} />
            )}
          </LineChart>
        </ResponsiveContainer>
      </ChartContainer>
    </div>
  )
}

