"use client"

import { useEffect, useState } from "react"
import { Area, AreaChart, ResponsiveContainer, XAxis, YAxis } from "recharts"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"

interface FuelConsumptionChartProps {
  craneId: string | null
  timeRange?: "hour" | "day" | "week" | "month"
}

export function FuelConsumptionChart({ craneId, timeRange = "hour" }: FuelConsumptionChartProps) {
  const [data, setData] = useState<any[]>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    if (!craneId) return

    const fetchData = async () => {
      setIsLoading(true)

      // In a real app, you would fetch this data from your API
      // For now, we'll use mock data
      let mockData: any[] = []

      if (timeRange === "hour") {
        // Generate data for the last hour (in 5-minute intervals)
        mockData = Array.from({ length: 12 }, (_, i) => {
          const time = new Date()
          time.setMinutes(time.getMinutes() - (11 - i) * 5)

          // Create a pattern with some variation
          const baseFuel = 5 + Math.sin(i / 3) * 1.5
          const randomVariation = (Math.random() - 0.5) * 0.5

          return {
            time: time.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
            fuel: Number((baseFuel + randomVariation).toFixed(2)),
            optimal: 4.5,
          }
        })
      } else if (timeRange === "day") {
        // Generate data for the last 24 hours
        mockData = Array.from({ length: 24 }, (_, i) => {
          const time = new Date()
          time.setHours(time.getHours() - (23 - i))

          // Create a pattern with some variation
          const baseFuel = 5 + Math.sin(i / 6) * 1.5
          const randomVariation = (Math.random() - 0.5) * 0.5

          return {
            time: time.getHours() + ":00",
            fuel: Number((baseFuel + randomVariation).toFixed(2)),
            optimal: 4.5,
          }
        })
      }

      setData(mockData)
      setIsLoading(false)
    }

    fetchData()
  }, [craneId, timeRange])

  if (isLoading) {
    return (
      <div className="flex h-[300px] items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent" />
      </div>
    )
  }

  return (
    <ChartContainer
      config={{
        fuel: {
          label: "Fuel Consumption (L/h)",
          color: "hsl(var(--chart-1))",
        },
        optimal: {
          label: "Optimal Level",
          color: "hsl(var(--chart-2))",
        },
      }}
      className="h-[300px]"
    >
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={data}>
          <XAxis dataKey="time" stroke="#888888" fontSize={12} tickLine={false} axisLine={false} />
          <YAxis
            stroke="#888888"
            fontSize={12}
            tickLine={false}
            axisLine={false}
            tickFormatter={(value) => `${value}L/h`}
          />
          <ChartTooltip content={<ChartTooltipContent />} />
          <Area type="monotone" dataKey="fuel" stroke="var(--color-fuel)" fill="var(--color-fuel)" fillOpacity={0.2} />
          <Area
            type="monotone"
            dataKey="optimal"
            stroke="var(--color-optimal)"
            strokeDasharray="5 5"
            fill="transparent"
          />
        </AreaChart>
      </ResponsiveContainer>
    </ChartContainer>
  )
}

