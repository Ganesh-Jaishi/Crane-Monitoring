"use client"

import { useEffect, useState } from "react"
import { Line, LineChart, ResponsiveContainer, XAxis, YAxis } from "recharts"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"

interface RealTimeChartProps {
  electricalData: any
  mechanicalData: any
  safetyData: any
}

export function RealTimeChart({ electricalData, mechanicalData, safetyData }: RealTimeChartProps) {
  const [data, setData] = useState<any[]>([])

  useEffect(() => {
    // Initialize with some data points
    const initialData = Array.from({ length: 20 }, (_, i) => ({
      time: new Date(Date.now() - (19 - i) * 5000).toLocaleTimeString([], {
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
      }),
      power: Math.random() * 50 + 20,
      load: Math.random() * 3000 + 1000,
      temp: Math.random() * 20 + 50,
      vibration: Math.random() * 3 + 1,
    }))

    setData(initialData)

    // Set up interval to add new data points
    const interval = setInterval(() => {
      const newDataPoint = {
        time: new Date().toLocaleTimeString([], {
          hour: "2-digit",
          minute: "2-digit",
          second: "2-digit",
        }),
        power: electricalData?.power_consumption || Math.random() * 50 + 20,
        load: mechanicalData?.load_weight || Math.random() * 3000 + 1000,
        temp: mechanicalData?.motor_temperature || Math.random() * 20 + 50,
        vibration: mechanicalData?.vibration_level || Math.random() * 3 + 1,
      }

      setData((prev) => [...prev.slice(1), newDataPoint])
    }, 5000)

    return () => clearInterval(interval)
  }, [electricalData, mechanicalData, safetyData])

  return (
    <ChartContainer
      config={{
        power: {
          label: "Power (kW)",
          color: "hsl(var(--chart-1))",
        },
        load: {
          label: "Load (kg)",
          color: "hsl(var(--chart-2))",
        },
        temp: {
          label: "Temperature (°C)",
          color: "hsl(var(--chart-3))",
        },
        vibration: {
          label: "Vibration (mm/s)",
          color: "hsl(var(--chart-4))",
        },
      }}
      className="h-[300px]"
    >
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data}>
          <XAxis dataKey="time" stroke="#888888" fontSize={12} tickLine={false} axisLine={false} />
          <YAxis
            stroke="#888888"
            fontSize={12}
            tickLine={false}
            axisLine={false}
            tickFormatter={(value) => `${value}`}
          />
          <ChartTooltip content={<ChartTooltipContent />} />
          <Line type="monotone" dataKey="power" stroke="var(--color-power)" strokeWidth={2} dot={false} />
          <Line type="monotone" dataKey="load" stroke="var(--color-load)" strokeWidth={2} dot={false} />
          <Line type="monotone" dataKey="temp" stroke="var(--color-temp)" strokeWidth={2} dot={false} />
          <Line type="monotone" dataKey="vibration" stroke="var(--color-vibration)" strokeWidth={2} dot={false} />
        </LineChart>
      </ResponsiveContainer>
    </ChartContainer>
  )
}

