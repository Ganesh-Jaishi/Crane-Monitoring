"use client"

import { useEffect, useRef } from "react"

interface BrakeStatusGaugeProps {
  status: string
}

export function BrakeStatusGauge({ status }: BrakeStatusGaugeProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    // Set dimensions
    const width = canvas.width
    const height = canvas.height
    const centerX = width / 2
    const centerY = height / 2
    const radius = Math.min(width, height) / 2 - 10

    // Determine color based on status
    let color = "#22c55e" // green for good
    let percentage = 1

    if (status === "Warning") {
      color = "#f59e0b" // yellow for warning
      percentage = 0.6
    } else if (status === "Critical") {
      color = "#ef4444" // red for critical
      percentage = 0.3
    }

    // Draw background arc
    ctx.beginPath()
    ctx.arc(centerX, centerY, radius, 0, 2 * Math.PI, false)
    ctx.lineWidth = 20
    ctx.strokeStyle = "#e5e7eb"
    ctx.stroke()

    // Draw status arc
    ctx.beginPath()
    ctx.arc(centerX, centerY, radius, -Math.PI / 2, -Math.PI / 2 + percentage * 2 * Math.PI, false)
    ctx.lineWidth = 20
    ctx.strokeStyle = color
    ctx.stroke()

    // Draw center circle
    ctx.beginPath()
    ctx.arc(centerX, centerY, radius - 40, 0, 2 * Math.PI, false)
    ctx.fillStyle = "#f8fafc"
    ctx.fill()
    ctx.lineWidth = 2
    ctx.strokeStyle = "#e2e8f0"
    ctx.stroke()

    // Draw status text
    ctx.font = "bold 24px Arial"
    ctx.fillStyle = color
    ctx.textAlign = "center"
    ctx.textBaseline = "middle"
    ctx.fillText(status, centerX, centerY - 10)

    // Draw label
    ctx.font = "14px Arial"
    ctx.fillStyle = "#64748b"
    ctx.fillText("Brake Condition", centerX, centerY + 20)
  }, [status])

  return <canvas ref={canvasRef} width={200} height={200} className="max-w-full h-auto" />
}

