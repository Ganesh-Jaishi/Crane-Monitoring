"use client"

import { useState } from "react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { AlertCircle, CheckCircle2 } from "lucide-react"
import { cn } from "@/lib/utils"
import { getSupabaseClient } from "@/lib/supabase/client"

interface Alert {
  id: string
  alert_type: string
  severity: string
  message: string
  timestamp: string
  acknowledged: boolean
}

interface SafetyAlertsTableProps {
  alerts: Alert[]
}

export function SafetyAlertsTable({ alerts }: SafetyAlertsTableProps) {
  const [acknowledgedAlerts, setAcknowledgedAlerts] = useState<Record<string, boolean>>({})

  const handleAcknowledge = async (alertId: string) => {
    // In a real app, you would update the database
    const supabase = getSupabaseClient()

    try {
      const { error } = await supabase.from("alerts").update({ acknowledged: true }).eq("id", alertId)

      if (error) {
        console.error("Error acknowledging alert:", error)
        return
      }

      setAcknowledgedAlerts((prev) => ({
        ...prev,
        [alertId]: true,
      }))
    } catch (err) {
      console.error("Error acknowledging alert:", err)
    }
  }

  if (!alerts || alerts.length === 0) {
    return (
      <div className="flex h-[200px] items-center justify-center text-sm text-muted-foreground">
        No safety alerts found
      </div>
    )
  }

  return (
    <div className="rounded-md border">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="w-[100px]">Severity</TableHead>
            <TableHead>Alert Type</TableHead>
            <TableHead className="hidden md:table-cell">Message</TableHead>
            <TableHead className="hidden md:table-cell">Time</TableHead>
            <TableHead className="text-right">Action</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {alerts.map((alert) => {
            const isAcknowledged = acknowledgedAlerts[alert.id] || alert.acknowledged

            return (
              <TableRow key={alert.id}>
                <TableCell>
                  <Badge
                    variant="outline"
                    className={cn(
                      "font-medium",
                      alert.severity === "critical" && "border-red-500 text-red-500",
                      alert.severity === "warning" && "border-yellow-500 text-yellow-500",
                      alert.severity === "info" && "border-blue-500 text-blue-500",
                    )}
                  >
                    {alert.severity}
                  </Badge>
                </TableCell>
                <TableCell className="font-medium">
                  <div className="flex items-center gap-2">
                    <AlertCircle
                      className={cn(
                        "h-4 w-4",
                        alert.severity === "critical" && "text-red-500",
                        alert.severity === "warning" && "text-yellow-500",
                        alert.severity === "info" && "text-blue-500",
                      )}
                    />
                    {alert.alert_type}
                  </div>
                </TableCell>
                <TableCell className="hidden md:table-cell">{alert.message}</TableCell>
                <TableCell className="hidden md:table-cell">{new Date(alert.timestamp).toLocaleString()}</TableCell>
                <TableCell className="text-right">
                  {isAcknowledged ? (
                    <div className="flex items-center justify-end gap-1 text-sm text-green-600">
                      <CheckCircle2 className="h-4 w-4" />
                      <span>Acknowledged</span>
                    </div>
                  ) : (
                    <Button variant="outline" size="sm" onClick={() => handleAcknowledge(alert.id)}>
                      Acknowledge
                    </Button>
                  )}
                </TableCell>
              </TableRow>
            )
          })}
        </TableBody>
      </Table>
    </div>
  )
}

