"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Battery, Droplet, Leaf, Settings, Zap } from "lucide-react"
import { cn } from "@/lib/utils"

interface EnergyEfficiencyDashboardProps {
  craneId: string | null
}

export function EnergyEfficiencyDashboard({ craneId }: EnergyEfficiencyDashboardProps) {
  const [energyData, setEnergyData] = useState<any>({
    fuel_consumption: 5.2,
    energy_efficiency: 87,
    optimization_score: 78,
    fuel_savings: 12.5,
    co2_reduction: 8.3,
    cost_savings: 4250,
    regenerative_energy: 15.2,
  })
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    if (!craneId) return

    // In a real app, you would fetch this data from your API
    // For now, we'll use mock data
    setIsLoading(false)
  }, [craneId])

  if (isLoading) {
    return (
      <div className="flex h-[300px] items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent" />
      </div>
    )
  }

  return (
    <Card className="border-t-4 border-t-green-500">
      <CardHeader className="flex flex-row items-center justify-between space-y-0">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <Leaf className="h-5 w-5 text-green-500" />
            <CardTitle>Energy Efficiency Dashboard</CardTitle>
          </div>
          <CardDescription>Real-time energy and fuel optimization metrics</CardDescription>
        </div>
        <Button variant="outline" size="sm">
          <Settings className="mr-2 h-4 w-4" />
          Configure
        </Button>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="overview" className="space-y-4">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="savings">Savings</TabsTrigger>
            <TabsTrigger value="recommendations">Recommendations</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Droplet className="h-4 w-4 text-blue-500" />
                    <span className="text-sm font-medium">Fuel Consumption</span>
                  </div>
                  <span className="text-sm font-bold">{energyData.fuel_consumption} L/h</span>
                </div>
                <Progress value={70} className="h-2" indicatorClassName="bg-blue-500" />
                <p className="text-xs text-muted-foreground">8% below fleet average</p>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Zap className="h-4 w-4 text-yellow-500" />
                    <span className="text-sm font-medium">Energy Efficiency</span>
                  </div>
                  <span className="text-sm font-bold">{energyData.energy_efficiency}%</span>
                </div>
                <Progress value={energyData.energy_efficiency} className="h-2" indicatorClassName="bg-yellow-500" />
                <p className="text-xs text-muted-foreground">5% above fleet average</p>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Battery className="h-4 w-4 text-green-500" />
                    <span className="text-sm font-medium">Optimization Score</span>
                  </div>
                  <span className="text-sm font-bold">{energyData.optimization_score}/100</span>
                </div>
                <Progress
                  value={energyData.optimization_score}
                  className="h-2"
                  indicatorClassName={cn(
                    energyData.optimization_score >= 90
                      ? "bg-green-500"
                      : energyData.optimization_score >= 70
                        ? "bg-yellow-500"
                        : "bg-red-500",
                  )}
                />
                <p className="text-xs text-muted-foreground">Room for improvement</p>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Leaf className="h-4 w-4 text-green-500" />
                    <span className="text-sm font-medium">Regenerative Energy</span>
                  </div>
                  <span className="text-sm font-bold">{energyData.regenerative_energy} kWh</span>
                </div>
                <Progress value={60} className="h-2" indicatorClassName="bg-green-500" />
                <p className="text-xs text-muted-foreground">Energy recovered today</p>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="savings" className="space-y-4">
            <div className="grid grid-cols-3 gap-4">
              <div className="rounded-lg border p-3 text-center">
                <Droplet className="mx-auto mb-2 h-8 w-8 text-blue-500" />
                <div className="text-2xl font-bold">{energyData.fuel_savings}%</div>
                <p className="text-xs text-muted-foreground">Fuel Savings</p>
                <Badge variant="outline" className="mt-2 text-xs">
                  vs. Last Quarter
                </Badge>
              </div>

              <div className="rounded-lg border p-3 text-center">
                <Leaf className="mx-auto mb-2 h-8 w-8 text-green-500" />
                <div className="text-2xl font-bold">{energyData.co2_reduction} tons</div>
                <p className="text-xs text-muted-foreground">CO2 Reduction</p>
                <Badge variant="outline" className="mt-2 text-xs">
                  Year to Date
                </Badge>
              </div>

              <div className="rounded-lg border p-3 text-center">
                <Zap className="mx-auto mb-2 h-8 w-8 text-yellow-500" />
                <div className="text-2xl font-bold">${energyData.cost_savings}</div>
                <p className="text-xs text-muted-foreground">Cost Savings</p>
                <Badge variant="outline" className="mt-2 text-xs">
                  Year to Date
                </Badge>
              </div>
            </div>

            <div className="rounded-lg border p-4">
              <h4 className="mb-2 text-sm font-medium">Projected Annual Savings</h4>
              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <p className="text-sm">Current Trajectory</p>
                  <p className="text-2xl font-bold">$18,500</p>
                </div>
                <div className="space-y-1">
                  <p className="text-sm">With Optimizations</p>
                  <p className="text-2xl font-bold text-green-600">$24,750</p>
                </div>
                <div className="space-y-1">
                  <p className="text-sm">Additional Savings</p>
                  <p className="text-2xl font-bold text-green-600">+$6,250</p>
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="recommendations" className="space-y-4">
            <div className="space-y-3">
              <div className="flex items-start space-x-3 rounded-md border p-3">
                <div className="flex h-8 w-8 items-center justify-center rounded-full bg-blue-100 text-blue-700">
                  <span className="text-sm font-bold">1</span>
                </div>
                <div className="space-y-1">
                  <p className="text-sm font-medium">Implement Regenerative Braking</p>
                  <p className="text-xs text-muted-foreground">
                    Recover energy during lowering operations to reduce power consumption by up to 20%.
                  </p>
                  <div className="pt-1">
                    <Badge variant="outline" className="text-xs text-green-600">
                      Potential Savings: 15-20%
                    </Badge>
                  </div>
                </div>
              </div>

              <div className="flex items-start space-x-3 rounded-md border p-3">
                <div className="flex h-8 w-8 items-center justify-center rounded-full bg-blue-100 text-blue-700">
                  <span className="text-sm font-bold">2</span>
                </div>
                <div className="space-y-1">
                  <p className="text-sm font-medium">Optimize Idle Shutdown Timing</p>
                  <p className="text-xs text-muted-foreground">
                    Reduce idle time by automatically shutting down systems after 5 minutes of inactivity.
                  </p>
                  <div className="pt-1">
                    <Badge variant="outline" className="text-xs text-green-600">
                      Potential Savings: 8-12%
                    </Badge>
                  </div>
                </div>
              </div>

              <div className="flex items-start space-x-3 rounded-md border p-3">
                <div className="flex h-8 w-8 items-center justify-center rounded-full bg-blue-100 text-blue-700">
                  <span className="text-sm font-bold">3</span>
                </div>
                <div className="space-y-1">
                  <p className="text-sm font-medium">Implement Load-Dependent Power Management</p>
                  <p className="text-xs text-muted-foreground">
                    Adjust power output based on actual load weight to prevent energy waste.
                  </p>
                  <div className="pt-1">
                    <Badge variant="outline" className="text-xs text-green-600">
                      Potential Savings: 10-15%
                    </Badge>
                  </div>
                </div>
              </div>
            </div>

            <Button className="w-full">
              <Settings className="mr-2 h-4 w-4" />
              Apply Recommended Optimizations
            </Button>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}

