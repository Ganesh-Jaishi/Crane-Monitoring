"use client"

import { useEffect, useState, useRef } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Droplet, Download, TrendingDown, TrendingUp } from "lucide-react"
import { cn } from "@/lib/utils"

interface ProfessionalFuelChartProps {
  craneId: string | null
  className?: string
}

export function ProfessionalFuelChart({ craneId, className }: ProfessionalFuelChartProps) {
  const [chartType, setChartType] = useState<"line" | "bar" | "area">("area")
  const [timeRange, setTimeRange] = useState<"day" | "week" | "month">("day")
  const [isLoading, setIsLoading] = useState(true)
  const [data, setData] = useState<any[]>([])
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    if (!craneId) return

    const fetchData = async () => {
      setIsLoading(true)

      // In a real app, you would fetch this data from your API
      // For now, we'll use mock data
      let mockData: any[] = []

      if (timeRange === "day") {
        // Generate data for the last 24 hours
        mockData = Array.from({ length: 24 }, (_, i) => {
          const hour = i

          // Create a pattern with some variation
          const baseFuel = 5 + Math.sin(i / 6) * 1.5
          const randomVariation = (Math.random() - 0.5) * 0.5
          const optimalFuel = 4.5 + Math.sin(i / 8) * 0.5

          return {
            time: `${hour}:00`,
            fuel: Number((baseFuel + randomVariation).toFixed(2)),
            optimal: Number(optimalFuel.toFixed(2)),
            savings: Number((baseFuel + randomVariation - optimalFuel).toFixed(2)),
          }
        })
      } else if (timeRange === "week") {
        // Generate data for the last 7 days
        const days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
        mockData = Array.from({ length: 7 }, (_, i) => {
          const day = days[i]

          // Create a pattern with some variation
          const baseFuel = 5.5 + Math.sin(i / 2) * 1
          const randomVariation = (Math.random() - 0.5) * 0.3
          const optimalFuel = 4.5 + Math.sin(i / 3) * 0.3

          return {
            time: day,
            fuel: Number((baseFuel + randomVariation).toFixed(2)),
            optimal: Number(optimalFuel.toFixed(2)),
            savings: Number((baseFuel + randomVariation - optimalFuel).toFixed(2)),
          }
        })
      } else if (timeRange === "month") {
        // Generate data for the last 30 days
        mockData = Array.from({ length: 30 }, (_, i) => {
          const day = i + 1

          // Create a pattern with some variation
          const baseFuel = 5.5 + Math.sin(i / 5) * 1
          const randomVariation = (Math.random() - 0.5) * 0.3
          const optimalFuel = 4.5 + Math.sin(i / 7) * 0.3

          return {
            time: `Day ${day}`,
            fuel: Number((baseFuel + randomVariation).toFixed(2)),
            optimal: Number(optimalFuel.toFixed(2)),
            savings: Number((baseFuel + randomVariation - optimalFuel).toFixed(2)),
          }
        })
      }

      setData(mockData)
      setIsLoading(false)
    }

    fetchData()
  }, [craneId, timeRange])

  // Draw the chart whenever data, chartType, or canvas changes
  useEffect(() => {
    if (!canvasRef.current || isLoading || data.length === 0) return

    const canvas = canvasRef.current
    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    // Set dimensions
    const width = canvas.width
    const height = canvas.height
    const padding = { top: 40, right: 30, bottom: 60, left: 60 }
    const chartWidth = width - padding.left - padding.right
    const chartHeight = height - padding.top - padding.bottom

    // Find min and max values
    const allValues = data.flatMap((d) => [d.fuel, d.optimal])
    const maxValue = Math.max(...allValues) * 1.1 // Add 10% padding
    const minValue = Math.min(0, Math.min(...allValues) * 0.9) // Add 10% padding, but not below 0

    // Draw background
    ctx.fillStyle = "#f8fafc"
    ctx.fillRect(0, 0, width, height)

    // Draw title
    ctx.font = "bold 16px Arial"
    ctx.fillStyle = "#0f172a"
    ctx.textAlign = "center"
    ctx.fillText("Fuel Consumption Analysis", width / 2, 25)

    // Draw axes
    ctx.beginPath()
    ctx.moveTo(padding.left, padding.top)
    ctx.lineTo(padding.left, height - padding.bottom)
    ctx.lineTo(width - padding.right, height - padding.bottom)
    ctx.strokeStyle = "#cbd5e1"
    ctx.lineWidth = 1
    ctx.stroke()

    // Draw horizontal grid lines
    const yStep = chartHeight / 5
    for (let i = 0; i <= 5; i++) {
      const y = padding.top + i * yStep
      const value = maxValue - (i * (maxValue - minValue)) / 5

      ctx.beginPath()
      ctx.moveTo(padding.left, y)
      ctx.lineTo(width - padding.right, y)
      ctx.strokeStyle = "#e2e8f0"
      ctx.stroke()

      // Draw y-axis labels
      ctx.font = "12px Arial"
      ctx.fillStyle = "#64748b"
      ctx.textAlign = "right"
      ctx.fillText(value.toFixed(1) + " L/h", padding.left - 10, y + 4)
    }

    // Draw x-axis labels
    const xStep = chartWidth / (data.length - 1)
    data.forEach((d, i) => {
      const x = padding.left + i * xStep

      // Draw tick
      ctx.beginPath()
      ctx.moveTo(x, height - padding.bottom)
      ctx.lineTo(x, height - padding.bottom + 5)
      ctx.strokeStyle = "#cbd5e1"
      ctx.stroke()

      // Draw label
      ctx.font = "12px Arial"
      ctx.fillStyle = "#64748b"
      ctx.textAlign = "center"
      ctx.fillText(d.time, x, height - padding.bottom + 20)
    })

    // Draw x-axis title
    ctx.font = "14px Arial"
    ctx.fillStyle = "#475569"
    ctx.textAlign = "center"
    ctx.fillText(
      timeRange === "day" ? "Time (hours)" : timeRange === "week" ? "Day of Week" : "Day of Month",
      width / 2,
      height - 15,
    )

    // Draw y-axis title
    ctx.save()
    ctx.translate(15, height / 2)
    ctx.rotate(-Math.PI / 2)
    ctx.font = "14px Arial"
    ctx.fillStyle = "#475569"
    ctx.textAlign = "center"
    ctx.fillText("Fuel Consumption (L/h)", 0, 0)
    ctx.restore()

    // Function to convert data point to canvas coordinates
    const toCanvasX = (i: number) => padding.left + i * xStep
    const toCanvasY = (value: number) => padding.top + ((maxValue - value) / (maxValue - minValue)) * chartHeight

    // Draw optimal fuel line
    ctx.beginPath()
    data.forEach((d, i) => {
      const x = toCanvasX(i)
      const y = toCanvasY(d.optimal)

      if (i === 0) {
        ctx.moveTo(x, y)
      } else {
        ctx.lineTo(x, y)
      }
    })
    ctx.strokeStyle = "#22c55e" // green
    ctx.lineWidth = 2
    ctx.setLineDash([5, 3])
    ctx.stroke()
    ctx.setLineDash([])

    // Draw actual fuel consumption based on chart type
    if (chartType === "line" || chartType === "area") {
      // Draw line
      ctx.beginPath()
      data.forEach((d, i) => {
        const x = toCanvasX(i)
        const y = toCanvasY(d.fuel)

        if (i === 0) {
          ctx.moveTo(x, y)
        } else {
          ctx.lineTo(x, y)
        }
      })
      ctx.strokeStyle = "#3b82f6" // blue
      ctx.lineWidth = 3
      ctx.stroke()

      // For area chart, fill the area
      if (chartType === "area") {
        ctx.lineTo(toCanvasX(data.length - 1), height - padding.bottom)
        ctx.lineTo(toCanvasX(0), height - padding.bottom)
        ctx.closePath()
        ctx.fillStyle = "rgba(59, 130, 246, 0.1)" // light blue
        ctx.fill()
      }

      // Draw data points
      data.forEach((d, i) => {
        const x = toCanvasX(i)
        const y = toCanvasY(d.fuel)

        ctx.beginPath()
        ctx.arc(x, y, 4, 0, 2 * Math.PI)
        ctx.fillStyle = "#3b82f6"
        ctx.fill()
        ctx.strokeStyle = "#ffffff"
        ctx.lineWidth = 2
        ctx.stroke()
      })
    } else if (chartType === "bar") {
      // Draw bars
      const barWidth = xStep * 0.6

      data.forEach((d, i) => {
        const x = toCanvasX(i) - barWidth / 2
        const y = toCanvasY(d.fuel)
        const barHeight = height - padding.bottom - y

        ctx.fillStyle = "rgba(59, 130, 246, 0.7)" // semi-transparent blue
        ctx.fillRect(x, y, barWidth, barHeight)

        // Draw optimal line on each bar
        const optimalY = toCanvasY(d.optimal)
        ctx.beginPath()
        ctx.moveTo(x, optimalY)
        ctx.lineTo(x + barWidth, optimalY)
        ctx.strokeStyle = "#22c55e"
        ctx.lineWidth = 2
        ctx.stroke()
      })
    }

    // Draw legend
    const legendX = width - padding.right - 150
    const legendY = padding.top + 20

    // Actual consumption
    ctx.beginPath()
    ctx.rect(legendX, legendY, 15, 15)
    ctx.fillStyle = "rgba(59, 130, 246, 0.7)"
    ctx.fill()
    ctx.font = "12px Arial"
    ctx.fillStyle = "#0f172a"
    ctx.textAlign = "left"
    ctx.fillText("Actual Consumption", legendX + 25, legendY + 12)

    // Optimal level
    ctx.beginPath()
    ctx.moveTo(legendX, legendY + 30)
    ctx.lineTo(legendX + 15, legendY + 30)
    ctx.strokeStyle = "#22c55e"
    ctx.lineWidth = 2
    ctx.setLineDash([5, 3])

    ctx.stroke()
    ctx.setLineDash([])
    ctx.font = "12px Arial"
    ctx.fillStyle = "#0f172a"
    ctx.textAlign = "left"
    ctx.fillText("Optimal Level", legendX + 25, legendY + 32)

    // Calculate and display statistics
    const avgFuel = data.reduce((sum, d) => sum + d.fuel, 0) / data.length
    const avgOptimal = data.reduce((sum, d) => sum + d.optimal, 0) / data.length
    const potentialSavings = data.reduce((sum, d) => sum + d.savings, 0) / data.length

    ctx.font = "bold 12px Arial"
    ctx.fillStyle = "#0f172a"
    ctx.textAlign = "left"
    ctx.fillText(`Avg: ${avgFuel.toFixed(2)} L/h`, padding.left, padding.top - 15)
    ctx.fillText(`Optimal: ${avgOptimal.toFixed(2)} L/h`, padding.left + 120, padding.top - 15)
    ctx.fillStyle = "#22c55e"
    ctx.fillText(`Potential Savings: ${potentialSavings.toFixed(2)} L/h`, padding.left + 240, padding.top - 15)
  }, [data, chartType, isLoading])

  // Calculate statistics
  const calculateStats = () => {
    if (data.length === 0) return { avg: 0, min: 0, max: 0, savings: 0 }

    const avg = data.reduce((sum, d) => sum + d.fuel, 0) / data.length
    const min = Math.min(...data.map((d) => d.fuel))
    const max = Math.max(...data.map((d) => d.fuel))
    const optimal = data.reduce((sum, d) => sum + d.optimal, 0) / data.length
    const savings = avg - optimal

    return { avg, min, max, savings }
  }

  const stats = calculateStats()

  return (
    <Card className={cn("border-0 shadow-md", className)}>
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Droplet className="h-5 w-5 text-blue-500" />
            <CardTitle>Fuel Consumption Analysis</CardTitle>
          </div>
          <Badge variant="outline" className="font-normal">
            {timeRange === "day" ? "Last 24 Hours" : timeRange === "week" ? "Last 7 Days" : "Last 30 Days"}
          </Badge>
        </div>
        <CardDescription>Monitor and analyze fuel consumption patterns to optimize efficiency</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex flex-wrap gap-2">
            <Select value={chartType} onValueChange={(value) => setChartType(value as any)}>
              <SelectTrigger className="h-8 w-[120px]">
                <SelectValue placeholder="Chart Type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="area">Area Chart</SelectItem>
                <SelectItem value="line">Line Chart</SelectItem>
                <SelectItem value="bar">Bar Chart</SelectItem>
              </SelectContent>
            </Select>
            <Select value={timeRange} onValueChange={(value) => setTimeRange(value as any)}>
              <SelectTrigger className="h-8 w-[120px]">
                <SelectValue placeholder="Time Range" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="day">Last 24 Hours</SelectItem>
                <SelectItem value="week">Last 7 Days</SelectItem>
                <SelectItem value="month">Last 30 Days</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <Button variant="outline" size="sm">
            <Download className="mr-2 h-4 w-4" />
            Export Data
          </Button>
        </div>

        <div className="grid gap-4 md:grid-cols-4">
          <Card className="bg-blue-50/50">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Average</p>
                  <p className="text-2xl font-bold">{stats.avg.toFixed(2)} L/h</p>
                </div>
                <div
                  className={cn(
                    "flex items-center rounded-full px-2 py-1 text-xs font-medium",
                    stats.avg > 5 ? "bg-red-100 text-red-800" : "bg-green-100 text-green-800",
                  )}
                >
                  {stats.avg > 5 ? (
                    <>
                      <TrendingUp className="mr-1 h-3 w-3" />
                      High
                    </>
                  ) : (
                    <>
                      <TrendingDown className="mr-1 h-3 w-3" />
                      Good
                    </>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="bg-blue-50/50">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Min/Max</p>
                  <p className="text-2xl font-bold">
                    {stats.min.toFixed(2)} - {stats.max.toFixed(2)}
                  </p>
                </div>
                <div className="text-xs text-muted-foreground">L/h</div>
              </div>
            </CardContent>
          </Card>
          <Card className="bg-green-50/50 md:col-span-2">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Potential Savings</p>
                  <div className="flex items-baseline gap-2">
                    <p className="text-2xl font-bold text-green-600">{stats.savings.toFixed(2)} L/h</p>
                    <p className="text-sm text-muted-foreground">
                      ({((stats.savings / stats.avg) * 100).toFixed(1)}% reduction possible)
                    </p>
                  </div>
                </div>
                <Button size="sm" className="bg-green-600 hover:bg-green-700">
                  Optimize
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="relative aspect-[16/9] w-full overflow-hidden rounded-lg border bg-background">
          {isLoading ? (
            <div className="flex h-full items-center justify-center">
              <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent" />
            </div>
          ) : (
            <canvas ref={canvasRef} width={800} height={450} className="h-full w-full" />
          )}
        </div>

        <Tabs defaultValue="insights" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="insights">Insights</TabsTrigger>
            <TabsTrigger value="recommendations">Recommendations</TabsTrigger>
            <TabsTrigger value="data">Raw Data</TabsTrigger>
          </TabsList>
          <TabsContent value="insights" className="mt-2 space-y-2">
            <div className="rounded-md bg-blue-50 p-3 text-sm">
              <p className="font-medium text-blue-800">Consumption Pattern Analysis</p>
              <p className="mt-1 text-blue-700">
                Your fuel consumption shows a {stats.avg > 5 ? "higher than optimal" : "near optimal"} pattern.
                {stats.avg > 5
                  ? " Peak usage occurs during operational hours, suggesting opportunities for optimization."
                  : " Continue maintaining current operational practices to sustain efficiency."}
              </p>
            </div>
            <div className="rounded-md bg-green-50 p-3 text-sm">
              <p className="font-medium text-green-800">Efficiency Insight</p>
              <p className="mt-1 text-green-700">
                Implementing recommended optimizations could reduce fuel consumption by up to{" "}
                {((stats.savings / stats.avg) * 100).toFixed(1)}%, resulting in significant cost savings and reduced
                environmental impact.
              </p>
            </div>
          </TabsContent>
          <TabsContent value="recommendations" className="mt-2 space-y-2">
            <div className="rounded-md border p-3 text-sm">
              <p className="font-medium">1. Optimize Idle Time Management</p>
              <p className="mt-1 text-muted-foreground">
                Reduce idle time by implementing automatic shutdown after 5 minutes of inactivity. Potential impact:
                10-15% fuel reduction.
              </p>
            </div>
            <div className="rounded-md border p-3 text-sm">
              <p className="font-medium">2. Load-Dependent Power Adjustment</p>
              <p className="mt-1 text-muted-foreground">
                Adjust engine power based on actual load requirements to prevent wasted fuel. Potential impact: 8-12%
                fuel reduction.
              </p>
            </div>
            <div className="rounded-md border p-3 text-sm">
              <p className="font-medium">3. Operator Training Program</p>
              <p className="mt-1 text-muted-foreground">
                Train operators on fuel-efficient operation techniques and best practices. Potential impact: 5-8% fuel
                reduction.
              </p>
            </div>
          </TabsContent>
          <TabsContent value="data" className="mt-2">
            <div className="max-h-[200px] overflow-auto rounded-md border">
              <table className="w-full">
                <thead>
                  <tr className="border-b bg-muted/50">
                    <th className="p-2 text-left text-sm font-medium">Time</th>
                    <th className="p-2 text-left text-sm font-medium">Actual (L/h)</th>
                    <th className="p-2 text-left text-sm font-medium">Optimal (L/h)</th>
                    <th className="p-2 text-left text-sm font-medium">Difference (L/h)</th>
                  </tr>
                </thead>
                <tbody>
                  {data.map((d, i) => (
                    <tr key={i} className="border-b">
                      <td className="p-2 text-sm">{d.time}</td>
                      <td className="p-2 text-sm">{d.fuel}</td>
                      <td className="p-2 text-sm">{d.optimal}</td>
                      <td className="p-2 text-sm">
                        <span className={d.savings > 0 ? "text-red-600" : "text-green-600"}>
                          {d.savings > 0 ? "+" : ""}
                          {d.savings}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}

