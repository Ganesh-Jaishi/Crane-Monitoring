"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { useAuth } from "@/contexts/auth-context"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import {
  Activity,
  AlertTriangle,
  BarChart3,
  Battery,
  Bell,
  Bolt,
  Droplet,
  Gauge,
  LayoutDashboard,
  Leaf,
  LogOut,
  Settings,
  Truck,
  User,
  Wrench,
  X,
  Menu,
} from "lucide-react"
import { useMediaQuery } from "@/hooks/use-media-query"

interface SidebarItemProps {
  icon: React.ElementType
  label: string
  href: string
  active?: boolean
  onClick?: () => void
  highlight?: boolean
  badge?: string | number
}

const SidebarItem = ({ icon: Icon, label, href, active, onClick, highlight, badge }: SidebarItemProps) => {
  return (
    <Link
      href={href}
      onClick={onClick}
      className={cn(
        "flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-all relative",
        active
          ? "bg-primary text-primary-foreground"
          : highlight
            ? "text-foreground hover:bg-blue-50 dark:hover:bg-blue-950"
            : "text-muted-foreground hover:bg-muted hover:text-foreground",
        highlight && !active && "font-medium",
      )}
    >
      <Icon className={cn("h-4 w-4", highlight && !active && "text-blue-600 dark:text-blue-400")} />
      <span>{label}</span>
      {badge && (
        <span className="ml-auto flex h-5 min-w-5 items-center justify-center rounded-full bg-primary px-1 text-xs font-medium text-primary-foreground">
          {badge}
        </span>
      )}
      {highlight && <span className="absolute inset-y-0 left-0 w-1 rounded-r-full bg-blue-500" />}
    </Link>
  )
}

export function Sidebar() {
  const pathname = usePathname()
  const { signOut } = useAuth()
  const [open, setOpen] = useState(false)
  const isDesktop = useMediaQuery("(min-width: 1024px)")

  const toggleSidebar = () => {
    setOpen(!open)
  }

  const closeSidebar = () => {
    if (!isDesktop) {
      setOpen(false)
    }
  }

  const sidebarContent = (
    <>
      <div className="flex h-14 items-center border-b px-4">
        <Link href="/dashboard" className="flex items-center gap-2 font-semibold">
          <Gauge className="h-6 w-6 text-primary" />
          <span>Crane Monitor Pro</span>
        </Link>
        {!isDesktop && (
          <Button variant="ghost" size="icon" className="ml-auto lg:hidden" onClick={toggleSidebar}>
            <X className="h-5 w-5" />
          </Button>
        )}
      </div>
      <div className="flex-1 overflow-auto py-2">
        <nav className="grid items-start px-2 text-sm font-medium">
          <div className="px-3 py-2">
            <h2 className="mb-2 px-4 text-xs font-semibold tracking-tight">Overview</h2>
            <div className="space-y-1">
              <SidebarItem
                icon={LayoutDashboard}
                label="Dashboard"
                href="/dashboard"
                active={pathname === "/dashboard"}
                onClick={closeSidebar}
              />
              <SidebarItem
                icon={Activity}
                label="Real-time Monitoring"
                href="/dashboard/real-time"
                active={pathname === "/dashboard/real-time"}
                onClick={closeSidebar}
              />
              <SidebarItem
                icon={Bell}
                label="Alerts"
                href="/dashboard/alerts"
                active={pathname === "/dashboard/alerts"}
                onClick={closeSidebar}
                badge={3}
              />
            </div>
          </div>
          <div className="px-3 py-2">
            <h2 className="mb-2 px-4 text-xs font-semibold tracking-tight text-blue-600 dark:text-blue-400">
              Energy & Fuel
            </h2>
            <div className="space-y-1 rounded-md bg-blue-50/50 p-2 dark:bg-blue-950/20">
              <SidebarItem
                icon={Droplet}
                label="Fuel Consumption"
                href="/dashboard/energy"
                active={pathname === "/dashboard/energy"}
                onClick={closeSidebar}
                highlight={true}
              />
              <SidebarItem
                icon={Leaf}
                label="Energy Optimization"
                href="/dashboard/energy"
                active={pathname === "/dashboard/energy"}
                onClick={closeSidebar}
                highlight={true}
              />
              <SidebarItem
                icon={Battery}
                label="Efficiency Analytics"
                href="/dashboard/energy"
                active={pathname === "/dashboard/energy"}
                onClick={closeSidebar}
                highlight={true}
              />
            </div>
          </div>
          <div className="px-3 py-2">
            <h2 className="mb-2 px-4 text-xs font-semibold tracking-tight">Parameters</h2>
            <div className="space-y-1">
              <SidebarItem
                icon={Bolt}
                label="Electrical"
                href="/dashboard/electrical"
                active={pathname === "/dashboard/electrical"}
                onClick={closeSidebar}
              />
              <SidebarItem
                icon={Truck}
                label="Mechanical"
                href="/dashboard/mechanical"
                active={pathname === "/dashboard/mechanical"}
                onClick={closeSidebar}
              />
              <SidebarItem
                icon={AlertTriangle}
                label="Safety"
                href="/dashboard/safety"
                active={pathname === "/dashboard/safety"}
                onClick={closeSidebar}
              />
            </div>
          </div>
          <div className="px-3 py-2">
            <h2 className="mb-2 px-4 text-xs font-semibold tracking-tight">Analytics</h2>
            <div className="space-y-1">
              <SidebarItem
                icon={BarChart3}
                label="Performance"
                href="/dashboard/performance"
                active={pathname === "/dashboard/performance"}
                onClick={closeSidebar}
              />
              <SidebarItem
                icon={Wrench}
                label="Maintenance"
                href="/dashboard/maintenance"
                active={pathname === "/dashboard/maintenance"}
                onClick={closeSidebar}
              />
            </div>
          </div>
          <div className="px-3 py-2">
            <h2 className="mb-2 px-4 text-xs font-semibold tracking-tight">Settings</h2>
            <div className="space-y-1">
              <SidebarItem
                icon={User}
                label="Profile"
                href="/dashboard/profile"
                active={pathname === "/dashboard/profile"}
                onClick={closeSidebar}
              />
              <SidebarItem
                icon={Settings}
                label="Settings"
                href="/dashboard/settings"
                active={pathname === "/dashboard/settings"}
                onClick={closeSidebar}
              />
              <button
                onClick={() => signOut()}
                className="flex w-full items-center gap-3 rounded-lg px-3 py-2 text-sm text-muted-foreground transition-all hover:bg-muted hover:text-foreground"
              >
                <LogOut className="h-4 w-4" />
                <span>Log out</span>
              </button>
            </div>
          </div>
        </nav>
      </div>
    </>
  )

  return (
    <>
      {!isDesktop && (
        <Button variant="outline" size="icon" className="fixed left-4 top-4 z-40 lg:hidden" onClick={toggleSidebar}>
          <Menu className="h-5 w-5" />
        </Button>
      )}
      {isDesktop ? (
        <div className="hidden w-64 flex-col border-r bg-background lg:flex">{sidebarContent}</div>
      ) : (
        open && (
          <>
            <div className="fixed inset-0 z-40 bg-background/80 backdrop-blur-sm" onClick={closeSidebar} />
            <div className="fixed inset-y-0 left-0 z-50 w-64 flex-col border-r bg-background">{sidebarContent}</div>
          </>
        )
      )}
    </>
  )
}

