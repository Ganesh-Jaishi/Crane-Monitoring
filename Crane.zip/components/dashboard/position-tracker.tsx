"use client"

import { useEffect, useRef } from "react"

interface PositionTrackerProps {
  x: number
  y: number
}

export function PositionTracker({ x, y }: PositionTrackerProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    // Set dimensions
    const width = canvas.width
    const height = canvas.height

    // Draw grid
    ctx.strokeStyle = "#e5e7eb"
    ctx.lineWidth = 1

    // Vertical grid lines
    for (let i = 0; i <= width; i += width / 10) {
      ctx.beginPath()
      ctx.moveTo(i, 0)
      ctx.lineTo(i, height)
      ctx.stroke()
    }

    // Horizontal grid lines
    for (let i = 0; i <= height; i += height / 10) {
      ctx.beginPath()
      ctx.moveTo(0, i)
      ctx.lineTo(width, i)
      ctx.stroke()
    }

    // Draw crane area outline
    ctx.strokeStyle = "#94a3b8"
    ctx.lineWidth = 2
    ctx.strokeRect(10, 10, width - 20, height - 20)

    // Calculate position within the canvas
    // Assuming x and y are normalized between 0 and 1
    const posX = 10 + (width - 20) * (x / 10)
    const posY = 10 + (height - 20) * (y / 10)

    // Draw hook position
    ctx.beginPath()
    ctx.arc(posX, posY, 8, 0, 2 * Math.PI)
    ctx.fillStyle = "#3b82f6"
    ctx.fill()
    ctx.strokeStyle = "#1d4ed8"
    ctx.lineWidth = 2
    ctx.stroke()

    // Draw crosshairs
    ctx.beginPath()
    ctx.moveTo(posX - 15, posY)
    ctx.lineTo(posX + 15, posY)
    ctx.moveTo(posX, posY - 15)
    ctx.lineTo(posX, posY + 15)
    ctx.strokeStyle = "#1d4ed8"
    ctx.lineWidth = 1
    ctx.stroke()

    // Draw position text
    ctx.font = "12px Arial"
    ctx.fillStyle = "#0f172a"
    ctx.textAlign = "left"
    ctx.textBaseline = "top"
    ctx.fillText(`X: ${x.toFixed(2)}m, Y: ${y.toFixed(2)}m`, 10, height - 25)
  }, [x, y])

  return <canvas ref={canvasRef} width={400} height={300} className="max-w-full h-auto border rounded-md" />
}

