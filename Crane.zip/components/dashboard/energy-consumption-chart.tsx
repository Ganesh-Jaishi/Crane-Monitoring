"use client"

import { useEffect, useState } from "react"
import { Bar, BarChart, ResponsiveContainer, XAxis, YAxis } from "recharts"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"

interface EnergyConsumptionChartProps {
  craneId: string | null
}

export function EnergyConsumptionChart({ craneId }: EnergyConsumptionChartProps) {
  const [data, setData] = useState<any[]>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    if (!craneId) return

    const fetchData = async () => {
      setIsLoading(true)

      // In a real app, you would fetch this data from your API
      // For now, we'll use mock data
      const mockData = [
        { day: "Mon", energy: 120 },
        { day: "Tue", energy: 132 },
        { day: "Wed", energy: 101 },
        { day: "Thu", energy: 134 },
        { day: "Fri", energy: 90 },
        { day: "Sat", energy: 30 },
        { day: "Sun", energy: 20 },
      ]

      setData(mockData)
      setIsLoading(false)
    }

    fetchData()
  }, [craneId])

  if (isLoading) {
    return (
      <div className="flex h-[300px] items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent" />
      </div>
    )
  }

  return (
    <ChartContainer
      config={{
        energy: {
          label: "Energy (kWh)",
          color: "hsl(var(--chart-1))",
        },
      }}
      className="h-[300px]"
    >
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data}>
          <XAxis dataKey="day" stroke="#888888" fontSize={12} tickLine={false} axisLine={false} />
          <YAxis
            stroke="#888888"
            fontSize={12}
            tickLine={false}
            axisLine={false}
            tickFormatter={(value) => `${value}kWh`}
          />
          <ChartTooltip content={<ChartTooltipContent />} />
          <Bar dataKey="energy" fill="var(--color-energy)" radius={[4, 4, 0, 0]} />
        </BarChart>
      </ResponsiveContainer>
    </ChartContainer>
  )
}

