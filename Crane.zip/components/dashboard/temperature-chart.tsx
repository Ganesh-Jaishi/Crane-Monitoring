"use client"

import { useEffect, useState } from "react"
import { Line, LineChart, ResponsiveContainer, XAxis, YAxis } from "recharts"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"

interface TemperatureChartProps {
  craneId: string | null
}

export function TemperatureChart({ craneId }: TemperatureChartProps) {
  const [data, setData] = useState<any[]>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    if (!craneId) return

    const fetchData = async () => {
      setIsLoading(true)

      // In a real app, you would fetch this data from your API
      // For now, we'll use mock data
      const mockData = Array.from({ length: 24 }, (_, i) => {
        const hour = i.toString().padStart(2, "0") + ":00"
        // Create temperature patterns
        const motorTemp = 50 + Math.sin(i / 4) * 15 + Math.random() * 5
        const gearboxTemp = 45 + Math.sin(i / 4) * 10 + Math.random() * 5
        return {
          time: hour,
          motor: Math.round(motorTemp),
          gearbox: Math.round(gearboxTemp),
        }
      })

      setData(mockData)
      setIsLoading(false)
    }

    fetchData()
  }, [craneId])

  if (isLoading) {
    return (
      <div className="flex h-[300px] items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent" />
      </div>
    )
  }

  return (
    <ChartContainer
      config={{
        motor: {
          label: "Motor Temperature (°C)",
          color: "hsl(var(--chart-1))",
        },
        gearbox: {
          label: "Gearbox Temperature (°C)",
          color: "hsl(var(--chart-2))",
        },
      }}
      className="h-[300px]"
    >
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data}>
          <XAxis dataKey="time" stroke="#888888" fontSize={12} tickLine={false} axisLine={false} />
          <YAxis
            stroke="#888888"
            fontSize={12}
            tickLine={false}
            axisLine={false}
            tickFormatter={(value) => `${value}°C`}
          />
          <ChartTooltip content={<ChartTooltipContent />} />
          <Line type="monotone" dataKey="motor" stroke="var(--color-motor)" strokeWidth={2} dot={false} />
          <Line type="monotone" dataKey="gearbox" stroke="var(--color-gearbox)" strokeWidth={2} dot={false} />
        </LineChart>
      </ResponsiveContainer>
    </ChartContainer>
  )
}

