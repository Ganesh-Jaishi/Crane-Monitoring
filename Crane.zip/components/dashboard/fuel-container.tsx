"use client"

import { useEffect, useRef, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Droplet, AlertTriangle, Gauge, ThermometerIcon } from "lucide-react"
import { cn } from "@/lib/utils"

interface FuelContainerProps {
  fuelLevel: number // 0-100 percentage
  fuelCapacity: number // in liters
  fuelConsumption: number // in L/h
  temperature: number // in Celsius
  className?: string
  onOptimize?: () => void
}

export function FuelContainer({
  fuelLevel = 75,
  fuelCapacity = 500,
  fuelConsumption = 5.2,
  temperature = 65,
  className,
  onOptimize,
}: FuelContainerProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [isOptimizing, setIsOptimizing] = useState(false)
  const [currentConsumption, setCurrentConsumption] = useState(fuelConsumption)
  const [currentTemperature, setCurrentTemperature] = useState(temperature)
  const [remainingTime, setRemainingTime] = useState(0)

  // Calculate remaining fuel and time
  useEffect(() => {
    const remainingFuel = (fuelLevel / 100) * fuelCapacity
    const timeInHours = remainingFuel / currentConsumption
    setRemainingTime(timeInHours)
  }, [fuelLevel, fuelCapacity, currentConsumption])

  // Draw the fuel container
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    // Set dimensions
    const width = canvas.width
    const height = canvas.height
    const containerWidth = width * 0.8
    const containerHeight = height * 0.7
    const containerX = (width - containerWidth) / 2
    const containerY = height * 0.15

    // Draw container outline
    ctx.beginPath()
    ctx.rect(containerX, containerY, containerWidth, containerHeight)
    ctx.strokeStyle = "#94a3b8"
    ctx.lineWidth = 3
    ctx.stroke()

    // Draw fuel level
    const fuelHeight = containerHeight * (fuelLevel / 100)
    const fuelY = containerY + containerHeight - fuelHeight

    // Create gradient for fuel
    const gradient = ctx.createLinearGradient(containerX, fuelY, containerX, containerY + containerHeight)

    if (fuelLevel > 60) {
      gradient.addColorStop(0, "#3b82f6") // Blue for high level
      gradient.addColorStop(1, "#1d4ed8")
    } else if (fuelLevel > 20) {
      gradient.addColorStop(0, "#f59e0b") // Yellow for medium level
      gradient.addColorStop(1, "#d97706")
    } else {
      gradient.addColorStop(0, "#ef4444") // Red for low level
      gradient.addColorStop(1, "#b91c1c")
    }

    ctx.fillStyle = gradient
    ctx.fillRect(containerX, fuelY, containerWidth, fuelHeight)

    // Draw fuel cap
    ctx.beginPath()
    ctx.arc(containerX + containerWidth / 2, containerY, 15, 0, Math.PI, true)
    ctx.fillStyle = "#64748b"
    ctx.fill()

    // Draw level markers
    for (let i = 1; i <= 10; i++) {
      const markerY = containerY + (containerHeight / 10) * i
      ctx.beginPath()
      ctx.moveTo(containerX - 5, markerY)
      ctx.lineTo(containerX, markerY)
      ctx.strokeStyle = "#94a3b8"
      ctx.lineWidth = 2
      ctx.stroke()

      // Add percentage labels for every 25%
      if (i % 2.5 === 0) {
        const percent = 100 - i * 10
        ctx.font = "12px Arial"
        ctx.fillStyle = "#64748b"
        ctx.textAlign = "right"
        ctx.fillText(`${percent}%`, containerX - 10, markerY + 4)
      }
    }

    // Draw fuel bubbles for animation effect
    for (let i = 0; i < 10; i++) {
      const bubbleX = containerX + Math.random() * containerWidth
      const bubbleY = fuelY + Math.random() * fuelHeight

      const bubbleSize = 2 + Math.random() * 4

      ctx.beginPath()
      ctx.arc(bubbleX, bubbleY, bubbleSize, 0, Math.PI * 2)
      ctx.fillStyle = "rgba(255, 255, 255, 0.3)"
      ctx.fill()
    }

    // Draw temperature gauge
    const gaugeX = containerX + containerWidth + 40
    const gaugeY = containerY + containerHeight / 2
    const gaugeRadius = 40

    // Draw gauge background
    ctx.beginPath()
    ctx.arc(gaugeX, gaugeY, gaugeRadius, -Math.PI * 0.75, Math.PI * 0.25, false)
    ctx.lineWidth = 10
    ctx.strokeStyle = "#e5e7eb"
    ctx.stroke()

    // Calculate temperature angle
    const minTemp = 0
    const maxTemp = 100
    const tempRatio = (currentTemperature - minTemp) / (maxTemp - minTemp)
    const tempAngle = -Math.PI * 0.75 + tempRatio * Math.PI

    // Draw temperature value
    ctx.beginPath()
    ctx.arc(gaugeX, gaugeY, gaugeRadius, -Math.PI * 0.75, tempAngle, false)

    // Color based on temperature
    let tempColor = "#22c55e" // Green for normal
    if (currentTemperature > 75) {
      tempColor = "#ef4444" // Red for high
    } else if (currentTemperature > 60) {
      tempColor = "#f59e0b" // Yellow for elevated
    }

    ctx.lineWidth = 10
    ctx.strokeStyle = tempColor
    ctx.stroke()

    // Draw temperature value
    ctx.font = "bold 16px Arial"
    ctx.fillStyle = tempColor
    ctx.textAlign = "center"
    ctx.fillText(`${Math.round(currentTemperature)}°C`, gaugeX, gaugeY + gaugeRadius + 20)

    // Draw temperature label
    ctx.font = "12px Arial"
    ctx.fillStyle = "#64748b"
    ctx.fillText("Temperature", gaugeX, gaugeY - gaugeRadius - 10)

    // Draw consumption indicator
    const consumptionX = containerX + containerWidth / 2
    const consumptionY = containerY + containerHeight + 40

    ctx.font = "bold 16px Arial"
    ctx.fillStyle = "#0f172a"
    ctx.textAlign = "center"
    ctx.fillText(`${currentConsumption.toFixed(1)} L/h`, consumptionX, consumptionY)

    ctx.font = "12px Arial"
    ctx.fillStyle = "#64748b"
    ctx.fillText("Current Consumption", consumptionX, consumptionY + 20)
  }, [fuelLevel, currentConsumption, currentTemperature])

  // Handle optimize button click
  const handleOptimize = () => {
    if (onOptimize) {
      onOptimize()
    }

    // Simulate optimization
    setIsOptimizing(true)

    // Gradually reduce temperature and consumption
    const startTemp = currentTemperature
    const targetTemp = Math.max(50, currentTemperature - 15)
    const startConsumption = currentConsumption
    const targetConsumption = currentConsumption * 0.8

    let progress = 0
    const interval = setInterval(() => {
      progress += 0.05
      if (progress >= 1) {
        clearInterval(interval)
        setIsOptimizing(false)
      }

      // Ease out function for smooth transition
      const easeOut = (t: number) => 1 - Math.pow(1 - t, 2)
      const easedProgress = easeOut(progress)

      // Update temperature and consumption
      setCurrentTemperature(startTemp - (startTemp - targetTemp) * easedProgress)
      setCurrentConsumption(startConsumption - (startConsumption - targetConsumption) * easedProgress)
    }, 50)
  }

  return (
    <Card className={cn("border-0 shadow-md", className)}>
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Droplet className="h-5 w-5 text-blue-500" />
            <CardTitle>Fuel Container</CardTitle>
          </div>
          {currentTemperature > 70 && (
            <div className="flex items-center gap-1 text-red-500 text-sm font-medium">
              <AlertTriangle className="h-4 w-4" />
              High Temperature
            </div>
          )}
        </div>
        <CardDescription>Real-time fuel level and consumption monitoring</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2">
              <Gauge className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm font-medium">Fuel Level:</span>
              <span className="text-sm font-bold">{fuelLevel}%</span>
            </div>
            <div className="mt-1 text-xs text-muted-foreground">
              {Math.round((fuelLevel / 100) * fuelCapacity)} / {fuelCapacity} liters
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <ThermometerIcon className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm font-medium">Temperature:</span>
              <span
                className={cn(
                  "text-sm font-bold",
                  currentTemperature > 75
                    ? "text-red-500"
                    : currentTemperature > 60
                      ? "text-yellow-500"
                      : "text-green-500",
                )}
              >
                {Math.round(currentTemperature)}°C
              </span>
            </div>
            <div className="mt-1 text-xs text-muted-foreground">
              {currentTemperature > 70
                ? "Critical - Reduce Usage"
                : currentTemperature > 60
                  ? "Warning - Monitor Closely"
                  : "Normal Operating Range"}
            </div>
          </div>
        </div>

        <div className="relative aspect-[4/3] w-full overflow-hidden rounded-lg border bg-background">
          <canvas ref={canvasRef} width={400} height={300} className="h-full w-full" />
        </div>

        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium">Remaining Operation Time:</span>
            <span className="text-sm font-bold">
              {Math.floor(remainingTime)} hours {Math.round((remainingTime % 1) * 60)} minutes
            </span>
          </div>
          <Progress
            value={Math.min(100, (remainingTime / 24) * 100)}
            className="h-2"
            indicatorClassName={cn(
              remainingTime < 4 ? "bg-red-500" : remainingTime < 8 ? "bg-yellow-500" : "bg-green-500",
            )}
          />
          <div className="flex justify-between text-xs text-muted-foreground">
            <span>0h</span>
            <span>12h</span>
            <span>24h</span>
          </div>
        </div>

        <Button
          onClick={handleOptimize}
          disabled={isOptimizing || currentTemperature < 60}
          className={cn(
            "w-full",
            currentTemperature > 70
              ? "bg-red-500 hover:bg-red-600"
              : currentTemperature > 60
                ? "bg-yellow-500 hover:bg-yellow-600"
                : "bg-green-600 hover:bg-green-700",
          )}
        >
          {isOptimizing
            ? "Optimizing..."
            : currentTemperature > 70
              ? "Reduce Temperature & Consumption"
              : currentTemperature > 60
                ? "Optimize Fuel Usage"
                : "System Optimized"}
        </Button>
      </CardContent>
    </Card>
  )
}

