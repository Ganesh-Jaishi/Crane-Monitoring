"use client"

import { useEffect, useState } from "react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Calendar, Clock, PenToolIcon as Tool } from "lucide-react"
import { cn } from "@/lib/utils"

interface MaintenanceScheduleProps {
  craneId: string | null
}

export function MaintenanceSchedule({ craneId }: MaintenanceScheduleProps) {
  const [scheduleData, setScheduleData] = useState<any[]>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    if (!craneId) return

    const fetchData = async () => {
      setIsLoading(true)

      // In a real app, you would fetch this data from your API
      // For now, we'll use mock data
      const mockData = [
        {
          id: "1",
          scheduled_date: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
          maintenance_type: "Preventive",
          description: "Monthly inspection and lubrication",
          estimated_duration: "4 hours",
          technician: "John Smith",
          priority: "Medium",
        },
        {
          id: "2",
          scheduled_date: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString(),
          maintenance_type: "Electrical",
          description: "Motor and control system check",
          estimated_duration: "6 hours",
          technician: "Sarah Johnson",
          priority: "High",
        },
        {
          id: "3",
          scheduled_date: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
          maintenance_type: "Mechanical",
          description: "Gearbox inspection and oil change",
          estimated_duration: "8 hours",
          technician: "Mike Davis",
          priority: "Medium",
        },
        {
          id: "4",
          scheduled_date: new Date(Date.now() + 45 * 24 * 60 * 60 * 1000).toISOString(),
          maintenance_type: "Safety",
          description: "Safety systems testing and certification",
          estimated_duration: "5 hours",
          technician: "Lisa Chen",
          priority: "Critical",
        },
        {
          id: "5",
          scheduled_date: new Date(Date.now() + 60 * 24 * 60 * 60 * 1000).toISOString(),
          maintenance_type: "Preventive",
          description: "Quarterly comprehensive inspection",
          estimated_duration: "10 hours",
          technician: "John Smith",
          priority: "High",
        },
      ]

      setScheduleData(mockData)
      setIsLoading(false)
    }

    fetchData()
  }, [craneId])

  if (isLoading) {
    return (
      <div className="flex h-[300px] items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent" />
      </div>
    )
  }

  return (
    <div className="rounded-md border">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="w-[180px]">Date</TableHead>
            <TableHead>Type</TableHead>
            <TableHead className="hidden md:table-cell">Description</TableHead>
            <TableHead className="hidden md:table-cell">Duration</TableHead>
            <TableHead className="hidden md:table-cell">Technician</TableHead>
            <TableHead>Priority</TableHead>
            <TableHead className="text-right">Action</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {scheduleData.map((item) => (
            <TableRow key={item.id}>
              <TableCell>
                <div className="flex items-center gap-2">
                  <Calendar className="h-4 w-4 text-muted-foreground" />
                  {new Date(item.scheduled_date).toLocaleDateString()}
                </div>
              </TableCell>
              <TableCell>{item.maintenance_type}</TableCell>
              <TableCell className="hidden md:table-cell">{item.description}</TableCell>
              <TableCell className="hidden md:table-cell">
                <div className="flex items-center gap-2">
                  <Clock className="h-4 w-4 text-muted-foreground" />
                  {item.estimated_duration}
                </div>
              </TableCell>
              <TableCell className="hidden md:table-cell">{item.technician}</TableCell>
              <TableCell>
                <Badge
                  variant="outline"
                  className={cn(
                    "font-medium",
                    item.priority === "Critical" && "border-red-500 text-red-500",
                    item.priority === "High" && "border-orange-500 text-orange-500",
                    item.priority === "Medium" && "border-blue-500 text-blue-500",
                    item.priority === "Low" && "border-green-500 text-green-500",
                  )}
                >
                  {item.priority}
                </Badge>
              </TableCell>
              <TableCell className="text-right">
                <Button variant="outline" size="sm">
                  <Tool className="mr-2 h-4 w-4" />
                  Details
                </Button>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}

