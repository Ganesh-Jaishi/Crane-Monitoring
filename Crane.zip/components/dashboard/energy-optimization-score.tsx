"use client"

import { useEffect, useRef } from "react"

interface EnergyOptimizationScoreProps {
  score: number
}

export function EnergyOptimizationScore({ score }: EnergyOptimizationScoreProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    // Set dimensions
    const width = canvas.width
    const height = canvas.height
    const centerX = width / 2
    const centerY = height / 2
    const radius = Math.min(width, height) / 2 - 10

    // Calculate color based on score
    let color = "#ef4444" // red for low scores
    if (score >= 80) {
      color = "#22c55e" // green for good scores
    } else if (score >= 60) {
      color = "#f59e0b" // yellow for medium scores
    }

    // Draw background arc
    ctx.beginPath()
    ctx.arc(centerX, centerY, radius, 0, 2 * Math.PI, false)
    ctx.lineWidth = 20
    ctx.strokeStyle = "#e5e7eb"
    ctx.stroke()

    // Draw score arc
    const angle = (score / 100) * 2 * Math.PI
    ctx.beginPath()
    ctx.arc(centerX, centerY, radius, -Math.PI / 2, angle - Math.PI / 2, false)
    ctx.lineWidth = 20
    ctx.strokeStyle = color
    ctx.stroke()

    // Draw center circle
    ctx.beginPath()
    ctx.arc(centerX, centerY, radius - 40, 0, 2 * Math.PI, false)
    ctx.fillStyle = "#f8fafc"
    ctx.fill()
    ctx.lineWidth = 2
    ctx.strokeStyle = "#e2e8f0"
    ctx.stroke()

    // Draw score text
    ctx.font = "bold 36px Arial"
    ctx.fillStyle = color
    ctx.textAlign = "center"
    ctx.textBaseline = "middle"
    ctx.fillText(score.toString(), centerX, centerY - 10)

    // Draw label
    ctx.font = "14px Arial"
    ctx.fillStyle = "#64748b"
    ctx.fillText("Optimization Score", centerX, centerY + 20)

    // Draw rating
    let rating = "Poor"
    if (score >= 90) rating = "Excellent"
    else if (score >= 80) rating = "Good"
    else if (score >= 60) rating = "Average"
    else if (score >= 40) rating = "Below Average"

    ctx.font = "16px Arial"
    ctx.fillStyle = "#0f172a"
    ctx.fillText(rating, centerX, centerY + 45)
  }, [score])

  return <canvas ref={canvasRef} width={250} height={250} className="max-w-full h-auto" />
}

