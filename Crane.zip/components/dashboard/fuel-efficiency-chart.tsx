"use client"

import { useEffect, useState } from "react"
import { Line, LineChart, ResponsiveContainer, XAxis, YAxis } from "recharts"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"

interface FuelEfficiencyChartProps {
  craneId: string | null
}

export function FuelEfficiencyChart({ craneId }: FuelEfficiencyChartProps) {
  const [data, setData] = useState<any[]>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    if (!craneId) return

    const fetchData = async () => {
      setIsLoading(true)

      // In a real app, you would fetch this data from your API
      // For now, we'll use mock data
      const mockData = Array.from({ length: 30 }, (_, i) => {
        const date = new Date()
        date.setDate(date.getDate() - (29 - i))

        // Create a pattern with gradual improvement
        const baseFuel = 6.5 - (i / 30) * 1.5
        const randomVariation = (Math.random() - 0.5) * 0.8

        return {
          date: date.toISOString().split("T")[0],
          fuel: Number((baseFuel + randomVariation).toFixed(2)),
          industry_avg: 5.8,
          target: 4.5,
        }
      })

      setData(mockData)
      setIsLoading(false)
    }

    fetchData()
  }, [craneId])

  if (isLoading) {
    return (
      <div className="flex h-[300px] items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent" />
      </div>
    )
  }

  return (
    <ChartContainer
      config={{
        fuel: {
          label: "Fuel Consumption (L/h)",
          color: "hsl(var(--chart-1))",
        },
        industry_avg: {
          label: "Industry Average",
          color: "hsl(var(--chart-2))",
        },
        target: {
          label: "Target",
          color: "hsl(var(--chart-3))",
        },
      }}
      className="h-[300px]"
    >
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data}>
          <XAxis
            dataKey="date"
            stroke="#888888"
            fontSize={12}
            tickLine={false}
            axisLine={false}
            tickFormatter={(value) => {
              const date = new Date(value)
              return `${date.getDate()}/${date.getMonth() + 1}`
            }}
          />
          <YAxis
            stroke="#888888"
            fontSize={12}
            tickLine={false}
            axisLine={false}
            tickFormatter={(value) => `${value}L/h`}
          />
          <ChartTooltip content={<ChartTooltipContent />} />
          <Line type="monotone" dataKey="fuel" stroke="var(--color-fuel)" strokeWidth={2} dot={false} />
          <Line
            type="monotone"
            dataKey="industry_avg"
            stroke="var(--color-industry_avg)"
            strokeWidth={2}
            strokeDasharray="5 5"
            dot={false}
          />
          <Line
            type="monotone"
            dataKey="target"
            stroke="var(--color-target)"
            strokeWidth={2}
            strokeDasharray="3 3"
            dot={false}
          />
        </LineChart>
      </ResponsiveContainer>
    </ChartContainer>
  )
}

