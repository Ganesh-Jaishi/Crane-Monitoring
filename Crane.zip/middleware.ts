import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"
import { createClient } from "@supabase/supabase-js"

export async function middleware(request: NextRequest) {
  try {
    // Create a Supabase client configured to use cookies
    const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
    const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

    if (!supabaseUrl || !supabaseAnonKey) {
      console.error("Supabase URL or Anon Key is missing in middleware")
      return NextResponse.redirect(new URL("/login", request.url))
    }

    const supabase = createClient(supabaseUrl, supabaseAnonKey, {
      auth: {
        persistSession: false,
      },
    })

    // Refresh session if expired
    const {
      data: { session },
    } = await supabase.auth.getSession()

    // Get the pathname
    const path = request.nextUrl.pathname

    // If no session and trying to access protected route, redirect to login
    if (
      !session &&
      !path.startsWith("/login") &&
      !path.startsWith("/signup") &&
      !path.startsWith("/forgot-password") &&
      !path.startsWith("/reset-password") &&
      !path.startsWith("/_next") &&
      !path.startsWith("/api")
    ) {
      // Use rewrite instead of redirect to avoid redirect loops
      return NextResponse.rewrite(new URL("/login", request.url))
    }

    // If session exists and trying to access auth pages, redirect to dashboard
    if (session && (path === "/login" || path === "/signup" || path === "/forgot-password" || path === "/")) {
      // Use rewrite instead of redirect to avoid redirect loops
      return NextResponse.rewrite(new URL("/dashboard", request.url))
    }

    return NextResponse.next()
  } catch (error) {
    console.error("Middleware error:", error)
    // If there's an error, redirect to login
    return NextResponse.redirect(new URL("/login", request.url))
  }
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico).*)"],
}

