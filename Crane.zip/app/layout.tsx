import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import { ThemeProvider } from "@/components/theme-provider"
import { AuthProvider } from "@/contexts/auth-context"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Real-time Crane Monitoring",
  description: "Professional real-time monitoring system for industrial cranes",
    generator: 'v0.dev'
}

// Add this function to check environment variables
function checkEnvironmentVariables() {
  const missingVars = []
  if (!process.env.NEXT_PUBLIC_SUPABASE_URL) missingVars.push("NEXT_PUBLIC_SUPABASE_URL")
  if (!process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY) missingVars.push("NEXT_PUBLIC_SUPABASE_ANON_KEY")

  if (missingVars.length > 0) {
    console.error(`Missing environment variables: ${missingVars.join(", ")}`)
    return false
  }
  return true
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  const envVarsPresent = checkEnvironmentVariables()

  return (
    <html lang="en" suppressHydrationWarning>
      <body className={inter.className}>
        <ThemeProvider attribute="class" defaultTheme="light" enableSystem disableTransitionOnChange>
          {envVarsPresent ? (
            <AuthProvider>{children}</AuthProvider>
          ) : (
            <div className="flex min-h-screen items-center justify-center bg-gray-50 p-4">
              <div className="w-full max-w-md rounded-lg border border-red-200 bg-red-50 p-6 text-center shadow-sm">
                <h1 className="mb-4 text-xl font-bold text-red-700">Environment Variables Missing</h1>
                <p className="text-red-600">
                  Please make sure you have set up the required environment variables in your .env.local file:
                </p>
                <ul className="mt-4 list-inside list-disc text-left text-red-600">
                  <li>NEXT_PUBLIC_SUPABASE_URL</li>
                  <li>NEXT_PUBLIC_SUPABASE_ANON_KEY</li>
                  <li>SUPABASE_SERVICE_ROLE_KEY (for server operations)</li>
                </ul>
              </div>
            </div>
          )}
        </ThemeProvider>
      </body>
    </html>
  )
}



import './globals.css'