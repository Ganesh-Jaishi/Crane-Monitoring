"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { getSupabaseClient } from "@/lib/supabase/client"
import { Battery, Download, Droplet, Leaf, Zap } from "lucide-react"
import { CraneSelector } from "@/components/dashboard/crane-selector"
import { RealTimeChart } from "@/components/dashboard/real-time-chart"
import { RealTimeGauges } from "@/components/dashboard/real-time-gauges"
import { RealTimeAlerts } from "@/components/dashboard/real-time-alerts"
import { EnergyOptimizationSuggestions } from "@/components/dashboard/energy-optimization-suggestions"
import { ProfessionalFuelChart } from "@/components/dashboard/professional-fuel-chart"
import { FuelContainer } from "@/components/dashboard/fuel-container"

export default function RealTimePage() {
  const [selectedCrane, setSelectedCrane] = useState<string | null>(null)
  const [cranes, setCranes] = useState<any[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [electricalData, setElectricalData] = useState<any>(null)
  const [mechanicalData, setMechanicalData] = useState<any>(null)
  const [safetyData, setSafetyData] = useState<any>(null)
  const [energyData, setEnergyData] = useState<any>(null)
  const [alerts, setAlerts] = useState<any[]>([])
  const [fuelLevel, setFuelLevel] = useState(75)
  const [temperature, setTemperature] = useState(65)

  useEffect(() => {
    const fetchCranes = async () => {
      const supabase = getSupabaseClient()
      const { data, error } = await supabase.from("cranes").select("*")

      if (error) {
        console.error("Error fetching cranes:", error)
        return
      }

      setCranes(data || [])
      if (data && data.length > 0) {
        setSelectedCrane(data[0].id)
      }
      setIsLoading(false)
    }

    fetchCranes()
  }, [])

  useEffect(() => {
    if (!selectedCrane) return

    const fetchData = async () => {
      const supabase = getSupabaseClient()

      // Fetch electrical data
      const { data: electricalData, error: electricalError } = await supabase
        .from("electrical_parameters")
        .select("*")
        .eq("crane_id", selectedCrane)
        .order("timestamp", { ascending: false })
        .limit(1)

      if (electricalError) {
        console.error("Error fetching electrical data:", electricalError)
      } else if (electricalData && electricalData.length > 0) {
        setElectricalData(electricalData[0])
      }

      // Fetch mechanical data
      const { data: mechanicalData, error: mechanicalError } = await supabase
        .from("mechanical_parameters")
        .select("*")
        .eq("crane_id", selectedCrane)
        .order("timestamp", { ascending: false })
        .limit(1)

      if (mechanicalError) {
        console.error("Error fetching mechanical data:", mechanicalError)
      } else if (mechanicalData && mechanicalData.length > 0) {
        setMechanicalData(mechanicalData[0])

        // Set temperature based on mechanical data
        if (mechanicalData[0].motor_temperature) {
          setTemperature(mechanicalData[0].motor_temperature)
        }
      }

      // Fetch safety data
      const { data: safetyData, error: safetyError } = await supabase
        .from("safety_parameters")
        .select("*")
        .eq("crane_id", selectedCrane)
        .order("timestamp", { ascending: false })
        .limit(1)

      if (safetyError) {
        console.error("Error fetching safety data:", safetyError)
      } else if (safetyData && safetyData.length > 0) {
        setSafetyData(safetyData[0])
      }

      // Fetch energy data
      const { data: energyData, error: energyError } = await supabase
        .from("energy_data")
        .select("*")
        .eq("crane_id", selectedCrane)
        .order("timestamp", { ascending: false })
        .limit(1)

      if (energyError) {
        console.error("Error fetching energy data:", energyError)
      } else if (energyData && energyData.length > 0) {
        setEnergyData(energyData[0])
      } else {
        // If no energy data exists, create mock data
        setEnergyData({
          fuel_consumption: 5.2,
          energy_efficiency: 87,
          regenerative_braking_enabled: false,
          optimization_score: 78,
          fuel_level: 75,
        })
      }

      // Fetch alerts
      const { data: alertsData, error: alertsError } = await supabase
        .from("alerts")
        .select("*")
        .eq("crane_id", selectedCrane)
        .order("timestamp", { ascending: false })
        .limit(5)

      if (alertsError) {
        console.error("Error fetching alerts:", alertsError)
      } else {
        setAlerts(alertsData || [])
      }
    }

    fetchData()

    // Set up real-time subscriptions
    const supabase = getSupabaseClient()

    const electricalSubscription = supabase
      .channel("electrical-rt-changes")
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "electrical_parameters",
          filter: `crane_id=eq.${selectedCrane}`,
        },
        (payload) => {
          setElectricalData(payload.new)
        },
      )
      .subscribe()

    const mechanicalSubscription = supabase
      .channel("mechanical-rt-changes")
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "mechanical_parameters",
          filter: `crane_id=eq.${selectedCrane}`,
        },
        (payload) => {
          setMechanicalData(payload.new)

          // Update temperature
          if (payload.new.motor_temperature) {
            setTemperature(payload.new.motor_temperature)
          }
        },
      )
      .subscribe()

    const safetySubscription = supabase
      .channel("safety-rt-changes")
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "safety_parameters",
          filter: `crane_id=eq.${selectedCrane}`,
        },
        (payload) => {
          setSafetyData(payload.new)
        },
      )
      .subscribe()

    const energySubscription = supabase
      .channel("energy-rt-changes")
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "energy_data",
          filter: `crane_id=eq.${selectedCrane}`,
        },
        (payload) => {
          setEnergyData(payload.new)

          // Update fuel level
          if (payload.new.fuel_level) {
            setFuelLevel(payload.new.fuel_level)
          }
        },
      )
      .subscribe()

    const alertsSubscription = supabase
      .channel("alerts-rt-changes")
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "alerts",
          filter: `crane_id=eq.${selectedCrane}`,
        },
        (payload) => {
          setAlerts((prev) => [payload.new, ...prev].slice(0, 5))
        },
      )
      .subscribe()

    // Simulate fuel consumption
    const fuelInterval = setInterval(() => {
      setFuelLevel((prev) => Math.max(0, prev - 0.1))
    }, 10000)

    return () => {
      supabase.removeChannel(electricalSubscription)
      supabase.removeChannel(mechanicalSubscription)
      supabase.removeChannel(safetySubscription)
      supabase.removeChannel(energySubscription)
      supabase.removeChannel(alertsSubscription)
      clearInterval(fuelInterval)
    }
  }, [selectedCrane])

  const handleCraneChange = (craneId: string) => {
    setSelectedCrane(craneId)
  }

  const handleOptimizeFuel = () => {
    // This function will be called when the optimize button is clicked
    // The actual optimization happens in the FuelContainer component

    // Create an alert for the optimization
    const newAlert = {
      id: `alert-${Date.now()}`,
      alert_type: "Fuel Optimization",
      severity: "info",
      message: "Automatic fuel optimization initiated. Reducing temperature and consumption.",
      timestamp: new Date().toISOString(),
      acknowledged: false,
      category: "Energy Optimization",
      crane_id: selectedCrane,
    }

    setAlerts((prev) => [newAlert, ...prev].slice(0, 5))
  }

  if (isLoading) {
    return (
      <div className="flex h-full items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent" />
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-4 md:flex-row md:items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Real-time Monitoring</h1>
          <p className="text-muted-foreground">Live data from all crane systems with energy optimization focus</p>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="outline" className="text-sm">
            <span className="mr-1 h-2 w-2 animate-pulse rounded-full bg-green-500"></span>
            Live Data
          </Badge>
          <CraneSelector cranes={cranes} selectedCrane={selectedCrane} onChange={handleCraneChange} />
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card className="border-l-4 border-l-primary">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Current Power</CardTitle>
            <Zap className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{electricalData?.power_consumption || "42.8"} kW</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-green-500">↓ 12%</span> from average
            </p>
          </CardContent>
        </Card>
        <Card className="border-l-4 border-l-blue-500">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Fuel Consumption</CardTitle>
            <Droplet className="h-4 w-4 text-blue-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{energyData?.fuel_consumption || "5.2"} L/h</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-green-500">↓ 8%</span> from last week
            </p>
          </CardContent>
        </Card>
        <Card className="border-l-4 border-l-green-500">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Energy Efficiency</CardTitle>
            <Leaf className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{energyData?.energy_efficiency || "87"}%</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-green-500">↑ 3%</span> from last month
            </p>
          </CardContent>
        </Card>
        <Card className="border-l-4 border-l-yellow-500">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Temperature</CardTitle>
            <Battery className="h-4 w-4 text-yellow-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{Math.round(temperature)}°C</div>
            <p className="text-xs text-muted-foreground">
              <span
                className={temperature > 70 ? "text-red-500" : temperature > 60 ? "text-yellow-500" : "text-green-500"}
              >
                {temperature > 70 ? "Critical" : temperature > 60 ? "Elevated" : "Normal"}
              </span>
            </p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="fuel" className="space-y-4">
        <TabsList>
          <TabsTrigger value="fuel" className="relative">
            Fuel Monitoring
            <span className="absolute -right-1 -top-1 flex h-3 w-3">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-blue-400 opacity-75"></span>
              <span className="relative inline-flex h-3 w-3 rounded-full bg-blue-500"></span>
            </span>
          </TabsTrigger>
          <TabsTrigger value="container">Fuel Container</TabsTrigger>
          <TabsTrigger value="optimization">Energy Optimization</TabsTrigger>
          <TabsTrigger value="parameters">System Parameters</TabsTrigger>
          <TabsTrigger value="alerts">Alerts</TabsTrigger>
        </TabsList>

        <TabsContent value="fuel" className="space-y-4">
          <ProfessionalFuelChart craneId={selectedCrane} />
        </TabsContent>

        <TabsContent value="container" className="space-y-4">
          <FuelContainer
            fuelLevel={fuelLevel}
            fuelCapacity={500}
            fuelConsumption={energyData?.fuel_consumption || 5.2}
            temperature={temperature}
            onOptimize={handleOptimizeFuel}
          />
        </TabsContent>

        <TabsContent value="optimization" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Energy Optimization Suggestions</CardTitle>
              <CardDescription>Real-time recommendations to improve efficiency</CardDescription>
            </CardHeader>
            <CardContent>
              <EnergyOptimizationSuggestions
                craneId={selectedCrane}
                electricalData={electricalData}
                mechanicalData={mechanicalData}
                energyData={energyData}
              />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="parameters" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Key Performance Indicators</CardTitle>
              <CardDescription>Critical system parameters</CardDescription>
            </CardHeader>
            <CardContent>
              <RealTimeGauges
                electricalData={electricalData}
                mechanicalData={mechanicalData}
                safetyData={safetyData}
                energyData={energyData}
              />
            </CardContent>
          </Card>
          <Card className="lg:col-span-2">
            <CardHeader className="flex flex-row items-center justify-between space-y-0">
              <div className="space-y-1">
                <CardTitle>Live Parameter Monitoring</CardTitle>
                <CardDescription>Real-time data visualization</CardDescription>
              </div>
              <Button variant="outline" size="sm">
                <Download className="mr-2 h-4 w-4" />
                Export
              </Button>
            </CardHeader>
            <CardContent>
              <RealTimeChart electricalData={electricalData} mechanicalData={mechanicalData} safetyData={safetyData} />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="alerts" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Live Alerts</CardTitle>
              <CardDescription>Recent system notifications</CardDescription>
            </CardHeader>
            <CardContent>
              <RealTimeAlerts alerts={alerts} />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <Alert className="bg-blue-50 border-blue-200">
        <Battery className="h-4 w-4 text-blue-500" />
        <AlertTitle>Temperature & Fuel Optimization</AlertTitle>
        <AlertDescription>
          Current temperature is {Math.round(temperature)}°C.
          {temperature > 70
            ? " This critical temperature level is causing excessive fuel consumption. The system will automatically reduce operations to lower temperature and save fuel."
            : temperature > 60
              ? " This elevated temperature increases fuel consumption. Consider optimizing operations to reduce temperature and improve efficiency."
              : " Temperature is within optimal range for fuel efficiency."}
        </AlertDescription>
      </Alert>
    </div>
  )
}

