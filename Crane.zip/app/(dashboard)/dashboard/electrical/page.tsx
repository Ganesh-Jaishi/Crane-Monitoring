"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { getSupabaseClient } from "@/lib/supabase/client"
import { AlertCircle, Download } from "lucide-react"
import { CraneSelector } from "@/components/dashboard/crane-selector"
import { ElectricalChart } from "@/components/dashboard/electrical-chart"
import { PowerFactorGauge } from "@/components/dashboard/power-factor-gauge"
import { EnergyConsumptionChart } from "@/components/dashboard/energy-consumption-chart"

export default function ElectricalPage() {
  const [selectedCrane, setSelectedCrane] = useState<string | null>(null)
  const [cranes, setCranes] = useState<any[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [electricalData, setElectricalData] = useState<any>(null)

  useEffect(() => {
    const fetchCranes = async () => {
      const supabase = getSupabaseClient()
      const { data, error } = await supabase.from("cranes").select("*")

      if (error) {
        console.error("Error fetching cranes:", error)
        return
      }

      setCranes(data || [])
      if (data && data.length > 0) {
        setSelectedCrane(data[0].id)
      }
      setIsLoading(false)
    }

    fetchCranes()
  }, [])

  useEffect(() => {
    if (!selectedCrane) return

    const fetchElectricalData = async () => {
      const supabase = getSupabaseClient()
      const { data, error } = await supabase
        .from("electrical_parameters")
        .select("*")
        .eq("crane_id", selectedCrane)
        .order("timestamp", { ascending: false })
        .limit(1)

      if (error) {
        console.error("Error fetching electrical data:", error)
        return
      }

      if (data && data.length > 0) {
        setElectricalData(data[0])
      }
    }

    fetchElectricalData()

    // Set up real-time subscription for electrical data
    const supabase = getSupabaseClient()
    const subscription = supabase
      .channel("electrical-changes")
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "electrical_parameters",
          filter: `crane_id=eq.${selectedCrane}`,
        },
        (payload) => {
          setElectricalData(payload.new)
        },
      )
      .subscribe()

    return () => {
      supabase.removeChannel(subscription)
    }
  }, [selectedCrane])

  const handleCraneChange = (craneId: string) => {
    setSelectedCrane(craneId)
  }

  if (isLoading) {
    return (
      <div className="flex h-full items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent" />
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-4 md:flex-row md:items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Electrical Parameters</h1>
          <p className="text-muted-foreground">
            Monitor voltage, current, power consumption and other electrical metrics
          </p>
        </div>
        <CraneSelector cranes={cranes} selectedCrane={selectedCrane} onChange={handleCraneChange} />
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Voltage</CardTitle>
            <svg
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
              className="h-4 w-4 text-muted-foreground"
            >
              <path d="M12 2v20M17 5H7M17 19H7" />
            </svg>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{electricalData?.voltage ? `${electricalData.voltage}V` : "N/A"}</div>
            <p className="text-xs text-muted-foreground">Nominal: 380V</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Current</CardTitle>
            <svg
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
              className="h-4 w-4 text-muted-foreground"
            >
              <path d="M12 2v20M17 5H7M17 19H7" />
            </svg>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{electricalData?.current ? `${electricalData.current}A` : "N/A"}</div>
            <p className="text-xs text-muted-foreground">Max: 100A</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Power Consumption</CardTitle>
            <svg
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
              className="h-4 w-4 text-muted-foreground"
            >
              <path d="M12 2v20M17 5H7M17 19H7" />
            </svg>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {electricalData?.power_consumption ? `${electricalData.power_consumption}kW` : "N/A"}
            </div>
            <p className="text-xs text-muted-foreground">Average: 35kW</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Regenerative Power</CardTitle>
            <svg
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
              className="h-4 w-4 text-muted-foreground"
            >
              <path d="M12 2v20M17 5H7M17 19H7" />
            </svg>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {electricalData?.regenerative_power ? `${electricalData.regenerative_power}kW` : "N/A"}
            </div>
            <p className="text-xs text-muted-foreground">Energy recovery</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
        <Card className="lg:col-span-5">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <div className="space-y-1">
              <CardTitle>Electrical Parameters Trend</CardTitle>
              <CardDescription>Real-time monitoring of voltage, current and power</CardDescription>
            </div>
            <div className="flex items-center space-x-2">
              <Button variant="outline" size="sm">
                <Download className="mr-2 h-4 w-4" />
                Export
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <ElectricalChart craneId={selectedCrane} />
          </CardContent>
        </Card>
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Power Factor</CardTitle>
            <CardDescription>Current power efficiency</CardDescription>
          </CardHeader>
          <CardContent className="flex justify-center">
            <PowerFactorGauge value={electricalData?.power_factor || 0.85} />
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0">
          <div className="space-y-1">
            <CardTitle>Energy Consumption</CardTitle>
            <CardDescription>Daily energy usage in kWh</CardDescription>
          </div>
          <div>
            <Badge variant="outline" className="ml-2">
              Last 7 days
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          <EnergyConsumptionChart craneId={selectedCrane} />
        </CardContent>
      </Card>

      <Alert>
        <AlertCircle className="h-4 w-4" />
        <AlertTitle>Energy Efficiency Tip</AlertTitle>
        <AlertDescription>
          Reducing the idle time of the crane can significantly decrease energy consumption. Consider implementing
          automatic shutdown during extended periods of inactivity.
        </AlertDescription>
      </Alert>
    </div>
  )
}

