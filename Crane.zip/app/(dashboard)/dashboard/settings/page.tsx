"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Slider } from "@/components/ui/slider"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { AlertCircle, Save } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

export default function SettingsPage() {
  const { toast } = useToast()
  const [notificationSettings, setNotificationSettings] = useState({
    emailAlerts: true,
    smsAlerts: false,
    pushNotifications: true,
    criticalAlertsOnly: false,
  })

  const [energySettings, setEnergySettings] = useState({
    optimizationLevel: 70,
    idleShutdownTime: "10",
    peakHoursAvoidance: true,
    regenerativeBraking: true,
  })

  const [displaySettings, setDisplaySettings] = useState({
    theme: "light",
    dataRefreshRate: "30",
    showRealTimeData: true,
    compactView: false,
  })

  const handleSaveNotifications = () => {
    toast({
      title: "Notification settings saved",
      description: "Your notification preferences have been updated.",
    })
  }

  const handleSaveEnergySettings = () => {
    toast({
      title: "Energy optimization settings saved",
      description: "Your energy settings have been updated.",
    })
  }

  const handleSaveDisplaySettings = () => {
    toast({
      title: "Display settings saved",
      description: "Your display preferences have been updated.",
    })
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Settings</h1>
        <p className="text-muted-foreground">Manage your account settings and preferences.</p>
      </div>

      <Tabs defaultValue="notifications" className="space-y-4">
        <TabsList>
          <TabsTrigger value="notifications">Notifications</TabsTrigger>
          <TabsTrigger value="energy">Energy Optimization</TabsTrigger>
          <TabsTrigger value="display">Display</TabsTrigger>
          <TabsTrigger value="system">System</TabsTrigger>
        </TabsList>

        <TabsContent value="notifications" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Notification Preferences</CardTitle>
              <CardDescription>Configure how you want to receive alerts and notifications.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="email-alerts">Email Alerts</Label>
                    <p className="text-sm text-muted-foreground">Receive alerts and notifications via email.</p>
                  </div>
                  <Switch
                    id="email-alerts"
                    checked={notificationSettings.emailAlerts}
                    onCheckedChange={(checked) =>
                      setNotificationSettings({ ...notificationSettings, emailAlerts: checked })
                    }
                  />
                </div>
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="sms-alerts">SMS Alerts</Label>
                    <p className="text-sm text-muted-foreground">Receive alerts and notifications via SMS.</p>
                  </div>
                  <Switch
                    id="sms-alerts"
                    checked={notificationSettings.smsAlerts}
                    onCheckedChange={(checked) =>
                      setNotificationSettings({ ...notificationSettings, smsAlerts: checked })
                    }
                  />
                </div>
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="push-notifications">Push Notifications</Label>
                    <p className="text-sm text-muted-foreground">Receive push notifications in the app.</p>
                  </div>
                  <Switch
                    id="push-notifications"
                    checked={notificationSettings.pushNotifications}
                    onCheckedChange={(checked) =>
                      setNotificationSettings({ ...notificationSettings, pushNotifications: checked })
                    }
                  />
                </div>
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="critical-alerts">Critical Alerts Only</Label>
                    <p className="text-sm text-muted-foreground">Only receive notifications for critical alerts.</p>
                  </div>
                  <Switch
                    id="critical-alerts"
                    checked={notificationSettings.criticalAlertsOnly}
                    onCheckedChange={(checked) =>
                      setNotificationSettings({ ...notificationSettings, criticalAlertsOnly: checked })
                    }
                  />
                </div>
              </div>
              <Button onClick={handleSaveNotifications}>
                <Save className="mr-2 h-4 w-4" />
                Save Notification Settings
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="energy" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Energy Optimization Settings</CardTitle>
              <CardDescription>
                Configure settings to optimize energy usage and reduce fuel consumption.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-4">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="optimization-level">Optimization Level: {energySettings.optimizationLevel}%</Label>
                  </div>
                  <Slider
                    id="optimization-level"
                    min={0}
                    max={100}
                    step={10}
                    value={[energySettings.optimizationLevel]}
                    onValueChange={(value) => setEnergySettings({ ...energySettings, optimizationLevel: value[0] })}
                  />
                  <p className="text-sm text-muted-foreground">
                    Higher levels may affect performance but save more energy.
                  </p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="idle-shutdown">Idle Shutdown Time (minutes)</Label>
                  <Select
                    value={energySettings.idleShutdownTime}
                    onValueChange={(value) => setEnergySettings({ ...energySettings, idleShutdownTime: value })}
                  >
                    <SelectTrigger id="idle-shutdown">
                      <SelectValue placeholder="Select idle shutdown time" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="5">5 minutes</SelectItem>
                      <SelectItem value="10">10 minutes</SelectItem>
                      <SelectItem value="15">15 minutes</SelectItem>
                      <SelectItem value="30">30 minutes</SelectItem>
                      <SelectItem value="never">Never</SelectItem>
                    </SelectContent>
                  </Select>
                  <p className="text-sm text-muted-foreground">
                    Automatically shut down systems after a period of inactivity.
                  </p>
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="peak-hours">Peak Hours Avoidance</Label>
                    <p className="text-sm text-muted-foreground">
                      Reduce operations during peak energy cost hours when possible.
                    </p>
                  </div>
                  <Switch
                    id="peak-hours"
                    checked={energySettings.peakHoursAvoidance}
                    onCheckedChange={(checked) => setEnergySettings({ ...energySettings, peakHoursAvoidance: checked })}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="regenerative-braking">Regenerative Braking</Label>
                    <p className="text-sm text-muted-foreground">
                      Recover energy during braking and lowering operations.
                    </p>
                  </div>
                  <Switch
                    id="regenerative-braking"
                    checked={energySettings.regenerativeBraking}
                    onCheckedChange={(checked) =>
                      setEnergySettings({ ...energySettings, regenerativeBraking: checked })
                    }
                  />
                </div>
              </div>
              <Button onClick={handleSaveEnergySettings}>
                <Save className="mr-2 h-4 w-4" />
                Save Energy Settings
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="display" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Display Settings</CardTitle>
              <CardDescription>Customize how data is displayed in the dashboard.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="theme">Theme</Label>
                  <Select
                    value={displaySettings.theme}
                    onValueChange={(value) => setDisplaySettings({ ...displaySettings, theme: value })}
                  >
                    <SelectTrigger id="theme">
                      <SelectValue placeholder="Select theme" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="light">Light</SelectItem>
                      <SelectItem value="dark">Dark</SelectItem>
                      <SelectItem value="system">System</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="refresh-rate">Data Refresh Rate (seconds)</Label>
                  <Select
                    value={displaySettings.dataRefreshRate}
                    onValueChange={(value) => setDisplaySettings({ ...displaySettings, dataRefreshRate: value })}
                  >
                    <SelectTrigger id="refresh-rate">
                      <SelectValue placeholder="Select refresh rate" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="5">5 seconds</SelectItem>
                      <SelectItem value="10">10 seconds</SelectItem>
                      <SelectItem value="30">30 seconds</SelectItem>
                      <SelectItem value="60">60 seconds</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="real-time-data">Show Real-Time Data</Label>
                    <p className="text-sm text-muted-foreground">
                      Display real-time data updates in charts and dashboards.
                    </p>
                  </div>
                  <Switch
                    id="real-time-data"
                    checked={displaySettings.showRealTimeData}
                    onCheckedChange={(checked) => setDisplaySettings({ ...displaySettings, showRealTimeData: checked })}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="compact-view">Compact View</Label>
                    <p className="text-sm text-muted-foreground">Use a more compact layout for dashboards.</p>
                  </div>
                  <Switch
                    id="compact-view"
                    checked={displaySettings.compactView}
                    onCheckedChange={(checked) => setDisplaySettings({ ...displaySettings, compactView: checked })}
                  />
                </div>
              </div>
              <Button onClick={handleSaveDisplaySettings}>
                <Save className="mr-2 h-4 w-4" />
                Save Display Settings
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="system" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>System Settings</CardTitle>
              <CardDescription>Configure system-wide settings and integrations.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="api-key">API Key</Label>
                  <div className="flex space-x-2">
                    <Input id="api-key" type="password" value="••••••••••••••••••••••••••" readOnly />
                    <Button variant="outline">Regenerate</Button>
                  </div>
                  <p className="text-sm text-muted-foreground">Used for external system integrations.</p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="data-retention">Data Retention Period</Label>
                  <Select defaultValue="90">
                    <SelectTrigger id="data-retention">
                      <SelectValue placeholder="Select data retention period" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="30">30 days</SelectItem>
                      <SelectItem value="60">60 days</SelectItem>
                      <SelectItem value="90">90 days</SelectItem>
                      <SelectItem value="180">180 days</SelectItem>
                      <SelectItem value="365">365 days</SelectItem>
                    </SelectContent>
                  </Select>
                  <p className="text-sm text-muted-foreground">How long to keep historical data.</p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="backup-frequency">Automated Backup Frequency</Label>
                  <Select defaultValue="daily">
                    <SelectTrigger id="backup-frequency">
                      <SelectValue placeholder="Select backup frequency" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="hourly">Hourly</SelectItem>
                      <SelectItem value="daily">Daily</SelectItem>
                      <SelectItem value="weekly">Weekly</SelectItem>
                      <SelectItem value="monthly">Monthly</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <Button>
                <Save className="mr-2 h-4 w-4" />
                Save System Settings
              </Button>
            </CardContent>
          </Card>

          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Danger Zone</AlertTitle>
            <AlertDescription>
              <p className="mb-4">
                The following actions are destructive and cannot be undone. Please proceed with caution.
              </p>
              <div className="flex space-x-2">
                <Button variant="outline" className="border-destructive text-destructive hover:bg-destructive/10">
                  Reset All Settings
                </Button>
                <Button variant="outline" className="border-destructive text-destructive hover:bg-destructive/10">
                  Clear All Data
                </Button>
              </div>
            </AlertDescription>
          </Alert>
        </TabsContent>
      </Tabs>
    </div>
  )
}

