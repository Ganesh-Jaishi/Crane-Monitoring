"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { getSupabaseClient } from "@/lib/supabase/client"
import { AlertCircle, AlertTriangle, ArrowUpRight, Bolt, Download, TrendingUp, Truck } from "lucide-react"
import { OverviewChart } from "@/components/dashboard/overview-chart"
import { StatusCard } from "@/components/dashboard/status-card"
import { RecentAlerts } from "@/components/dashboard/recent-alerts"
import { CraneSelector } from "@/components/dashboard/crane-selector"
import { EnergyEfficiencyDashboard } from "@/components/dashboard/energy-efficiency-dashboard"

export default function DashboardPage() {
  const [selectedCrane, setSelectedCrane] = useState<string | null>(null)
  const [cranes, setCranes] = useState<any[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [alerts, setAlerts] = useState<any[]>([])

  useEffect(() => {
    const fetchCranes = async () => {
      const supabase = getSupabaseClient()
      const { data, error } = await supabase.from("cranes").select("*")

      if (error) {
        console.error("Error fetching cranes:", error)
        return
      }

      setCranes(data || [])
      if (data && data.length > 0) {
        setSelectedCrane(data[0].id)
      }
      setIsLoading(false)
    }

    fetchCranes()
  }, [])

  useEffect(() => {
    if (!selectedCrane) return

    const fetchAlerts = async () => {
      const supabase = getSupabaseClient()
      const { data, error } = await supabase
        .from("alerts")
        .select("*")
        .eq("crane_id", selectedCrane)
        .order("timestamp", { ascending: false })
        .limit(5)

      if (error) {
        console.error("Error fetching alerts:", error)
        return
      }

      setAlerts(data || [])
    }

    fetchAlerts()

    // Set up real-time subscription for alerts
    const supabase = getSupabaseClient()
    const subscription = supabase
      .channel("alerts-changes")
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "alerts",
          filter: `crane_id=eq.${selectedCrane}`,
        },
        (payload) => {
          setAlerts((prev) => [payload.new, ...prev].slice(0, 5))
        },
      )
      .subscribe()

    return () => {
      supabase.removeChannel(subscription)
    }
  }, [selectedCrane])

  const handleCraneChange = (craneId: string) => {
    setSelectedCrane(craneId)
  }

  if (isLoading) {
    return (
      <div className="flex h-full items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent" />
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-4 md:flex-row md:items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
          <p className="text-muted-foreground">Monitor and analyze your crane performance in real-time</p>
        </div>
        <CraneSelector cranes={cranes} selectedCrane={selectedCrane} onChange={handleCraneChange} />
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatusCard
          title="Power Consumption"
          value="42.8 kW"
          description="Current usage"
          trend="+5%"
          trendDirection="up"
          icon={Bolt}
        />
        <StatusCard
          title="Load Weight"
          value="3,250 kg"
          description="Current load"
          trend="65%"
          trendDirection="neutral"
          icon={Truck}
        />
        <StatusCard
          title="Active Alerts"
          value="3"
          description="Requires attention"
          trend="+1"
          trendDirection="up"
          icon={AlertTriangle}
          variant="warning"
        />
        <StatusCard
          title="Efficiency"
          value="94.2%"
          description="Overall performance"
          trend="+2.4%"
          trendDirection="up"
          icon={TrendingUp}
          variant="success"
        />
      </div>

      <EnergyEfficiencyDashboard craneId={selectedCrane} />

      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="electrical">Electrical</TabsTrigger>
          <TabsTrigger value="mechanical">Mechanical</TabsTrigger>
          <TabsTrigger value="safety">Safety</TabsTrigger>
        </TabsList>
        <TabsContent value="overview" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
            <Card className="lg:col-span-5">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <div className="space-y-1">
                  <CardTitle>Performance Overview</CardTitle>
                  <CardDescription>Real-time monitoring of key parameters</CardDescription>
                </div>
                <div className="flex items-center space-x-2">
                  <Button variant="outline" size="sm">
                    <Download className="mr-2 h-4 w-4" />
                    Export
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <OverviewChart />
              </CardContent>
            </Card>
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle>Active Alerts</CardTitle>
                <CardDescription>Recent issues requiring attention</CardDescription>
              </CardHeader>
              <CardContent>
                <RecentAlerts alerts={alerts} />
              </CardContent>
            </Card>
          </div>

          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-base font-medium">Voltage Stability</CardTitle>
                <Badge variant="outline">Stable</Badge>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">380V</div>
                <p className="text-xs text-muted-foreground">Operating within normal parameters</p>
                <div className="mt-4 h-[80px]">{/* Mini chart would go here */}</div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-base font-medium">Motor Temperature</CardTitle>
                <Badge variant="outline">Normal</Badge>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">62°C</div>
                <p className="text-xs text-muted-foreground">Within operational limits</p>
                <div className="mt-4 h-[80px]">{/* Mini chart would go here */}</div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-base font-medium">Maintenance Status</CardTitle>
                <Badge>Upcoming</Badge>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">12 days</div>
                <p className="text-xs text-muted-foreground">Until next scheduled maintenance</p>
                <div className="mt-4">
                  <Button variant="outline" size="sm" className="w-full">
                    View Schedule
                    <ArrowUpRight className="ml-2 h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          <Alert>
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>System Notification</AlertTitle>
            <AlertDescription>
              Scheduled maintenance for Crane 01 is due in 12 days. Please review the maintenance schedule.
            </AlertDescription>
          </Alert>
        </TabsContent>

        <TabsContent value="electrical" className="space-y-4">
          {/* Electrical parameters content */}
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {/* Electrical parameter cards would go here */}
          </div>
        </TabsContent>

        <TabsContent value="mechanical" className="space-y-4">
          {/* Mechanical parameters content */}
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {/* Mechanical parameter cards would go here */}
          </div>
        </TabsContent>

        <TabsContent value="safety" className="space-y-4">
          {/* Safety parameters content */}
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">{/* Safety parameter cards would go here */}</div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

