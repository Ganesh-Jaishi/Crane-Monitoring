"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { getSupabaseClient } from "@/lib/supabase/client"
import { AlertCircle, Download } from "lucide-react"
import { CraneSelector } from "@/components/dashboard/crane-selector"
import { SafetyStatusCard } from "@/components/dashboard/safety-status-card"
import { WindSpeedChart } from "@/components/dashboard/wind-speed-chart"
import { BrakeStatusGauge } from "@/components/dashboard/brake-status-gauge"
import { SafetyAlertsTable } from "@/components/dashboard/safety-alerts-table"

export default function SafetyPage() {
  const [selectedCrane, setSelectedCrane] = useState<string | null>(null)
  const [cranes, setCranes] = useState<any[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [safetyData, setSafetyData] = useState<any>(null)
  const [alerts, setAlerts] = useState<any[]>([])

  useEffect(() => {
    const fetchCranes = async () => {
      const supabase = getSupabaseClient()
      const { data, error } = await supabase.from("cranes").select("*")

      if (error) {
        console.error("Error fetching cranes:", error)
        return
      }

      setCranes(data || [])
      if (data && data.length > 0) {
        setSelectedCrane(data[0].id)
      }
      setIsLoading(false)
    }

    fetchCranes()
  }, [])

  useEffect(() => {
    if (!selectedCrane) return

    const fetchSafetyData = async () => {
      const supabase = getSupabaseClient()
      const { data, error } = await supabase
        .from("safety_parameters")
        .select("*")
        .eq("crane_id", selectedCrane)
        .order("timestamp", { ascending: false })
        .limit(1)

      if (error) {
        console.error("Error fetching safety data:", error)
        return
      }

      if (data && data.length > 0) {
        setSafetyData(data[0])
      }
    }

    const fetchAlerts = async () => {
      const supabase = getSupabaseClient()
      const { data, error } = await supabase
        .from("alerts")
        .select("*")
        .eq("crane_id", selectedCrane)
        .eq("severity", "critical")
        .order("timestamp", { ascending: false })
        .limit(10)

      if (error) {
        console.error("Error fetching alerts:", error)
        return
      }

      setAlerts(data || [])
    }

    fetchSafetyData()
    fetchAlerts()

    // Set up real-time subscription for safety data
    const supabase = getSupabaseClient()
    const subscription = supabase
      .channel("safety-changes")
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "safety_parameters",
          filter: `crane_id=eq.${selectedCrane}`,
        },
        (payload) => {
          setSafetyData(payload.new)
        },
      )
      .subscribe()

    return () => {
      supabase.removeChannel(subscription)
    }
  }, [selectedCrane])

  const handleCraneChange = (craneId: string) => {
    setSelectedCrane(craneId)
  }

  if (isLoading) {
    return (
      <div className="flex h-full items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent" />
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-4 md:flex-row md:items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Safety Monitoring</h1>
          <p className="text-muted-foreground">Monitor critical safety parameters and alerts</p>
        </div>
        <CraneSelector cranes={cranes} selectedCrane={selectedCrane} onChange={handleCraneChange} />
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <SafetyStatusCard
          title="Overload Status"
          status={safetyData?.overload_detected ? "Warning" : "Normal"}
          description={safetyData?.overload_detected ? "Overload detected" : "Operating within limits"}
          variant={safetyData?.overload_detected ? "warning" : "success"}
        />
        <SafetyStatusCard
          title="Emergency Stop"
          status={safetyData?.emergency_stop_activated ? "Activated" : "Ready"}
          description={safetyData?.emergency_stop_activated ? "System halted" : "System operational"}
          variant={safetyData?.emergency_stop_activated ? "danger" : "success"}
        />
        <SafetyStatusCard
          title="Hoist Condition"
          status={safetyData?.hoist_condition || "Good"}
          description="Wire rope and drum status"
          variant={
            safetyData?.hoist_condition === "Critical"
              ? "danger"
              : safetyData?.hoist_condition === "Warning"
                ? "warning"
                : "success"
          }
        />
        <SafetyStatusCard
          title="Weather Condition"
          status={safetyData?.weather_condition || "Clear"}
          description={`Wind: ${safetyData?.wind_speed || 0} m/s`}
          variant={safetyData?.wind_speed > 15 ? "danger" : safetyData?.wind_speed > 10 ? "warning" : "success"}
        />
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0">
            <div className="space-y-1">
              <CardTitle>Wind Speed Monitoring</CardTitle>
              <CardDescription>Real-time wind speed data</CardDescription>
            </div>
            <Badge variant="outline">Last 24 hours</Badge>
          </CardHeader>
          <CardContent>
            <WindSpeedChart craneId={selectedCrane} />
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0">
            <div className="space-y-1">
              <CardTitle>Brake Status</CardTitle>
              <CardDescription>Current brake condition</CardDescription>
            </div>
            <Badge variant="outline">Real-time</Badge>
          </CardHeader>
          <CardContent className="flex justify-center">
            <BrakeStatusGauge status={safetyData?.brake_status || "Good"} />
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0">
          <div className="space-y-1">
            <CardTitle>Safety Alerts</CardTitle>
            <CardDescription>Recent critical safety alerts</CardDescription>
          </div>
          <Button variant="outline" size="sm">
            <Download className="mr-2 h-4 w-4" />
            Export
          </Button>
        </CardHeader>
        <CardContent>
          <SafetyAlertsTable alerts={alerts} />
        </CardContent>
      </Card>

      <Alert variant="destructive">
        <AlertCircle className="h-4 w-4" />
        <AlertTitle>Critical Safety Notice</AlertTitle>
        <AlertDescription>
          Always ensure that the load is properly secured before lifting. Never exceed the maximum load capacity of the
          crane.
        </AlertDescription>
      </Alert>
    </div>
  )
}

