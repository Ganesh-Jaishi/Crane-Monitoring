"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { getSupabaseClient } from "@/lib/supabase/client"
import { Battery, Download, Droplet, Flame, Leaf, Lightbulb, Zap } from "lucide-react"
import { CraneSelector } from "@/components/dashboard/crane-selector"
import { EnergyConsumptionChart } from "@/components/dashboard/energy-consumption-chart"
import { FuelEfficiencyChart } from "@/components/dashboard/fuel-efficiency-chart"
import { EnergyOptimizationScore } from "@/components/dashboard/energy-optimization-score"
import { EnergyComparisonChart } from "@/components/dashboard/energy-comparison-chart"

export default function EnergyPage() {
  const [selectedCrane, setSelectedCrane] = useState<string | null>(null)
  const [cranes, setCranes] = useState<any[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [energyData, setEnergyData] = useState<any>(null)

  useEffect(() => {
    const fetchCranes = async () => {
      const supabase = getSupabaseClient()
      const { data, error } = await supabase.from("cranes").select("*")

      if (error) {
        console.error("Error fetching cranes:", error)
        return
      }

      setCranes(data || [])
      if (data && data.length > 0) {
        setSelectedCrane(data[0].id)
      }
      setIsLoading(false)
    }

    fetchCranes()
  }, [])

  useEffect(() => {
    if (!selectedCrane) return

    const fetchEnergyData = async () => {
      const supabase = getSupabaseClient()
      const { data, error } = await supabase
        .from("energy_data")
        .select("*")
        .eq("crane_id", selectedCrane)
        .order("timestamp", { ascending: false })
        .limit(1)

      if (error) {
        console.error("Error fetching energy data:", error)
        return
      }

      if (data && data.length > 0) {
        setEnergyData(data[0])
      }
    }

    fetchEnergyData()

    // Set up real-time subscription for energy data
    const supabase = getSupabaseClient()
    const subscription = supabase
      .channel("energy-changes")
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "energy_data",
          filter: `crane_id=eq.${selectedCrane}`,
        },
        (payload) => {
          setEnergyData(payload.new)
        },
      )
      .subscribe()

    return () => {
      supabase.removeChannel(subscription)
    }
  }, [selectedCrane])

  const handleCraneChange = (craneId: string) => {
    setSelectedCrane(craneId)
  }

  if (isLoading) {
    return (
      <div className="flex h-full items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent" />
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-4 md:flex-row md:items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Energy Optimization</h1>
          <p className="text-muted-foreground">Monitor and optimize energy and fuel consumption</p>
        </div>
        <CraneSelector cranes={cranes} selectedCrane={selectedCrane} onChange={handleCraneChange} />
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Current Power</CardTitle>
            <Zap className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{energyData?.current_power || "42.8"} kW</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-green-500">↓ 12%</span> from average
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Fuel Consumption</CardTitle>
            <Droplet className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{energyData?.fuel_consumption || "5.2"} L/h</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-green-500">↓ 8%</span> from last week
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Energy Efficiency</CardTitle>
            <Leaf className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{energyData?.energy_efficiency || "87"}%</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-green-500">↑ 3%</span> from last month
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">CO2 Reduction</CardTitle>
            <Flame className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{energyData?.co2_reduction || "12.5"} tons</div>
            <p className="text-xs text-muted-foreground">Year to date</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="consumption" className="space-y-4">
        <TabsList>
          <TabsTrigger value="consumption">Energy Consumption</TabsTrigger>
          <TabsTrigger value="efficiency">Fuel Efficiency</TabsTrigger>
          <TabsTrigger value="optimization">Optimization</TabsTrigger>
          <TabsTrigger value="comparison">Comparison</TabsTrigger>
        </TabsList>
        <TabsContent value="consumption" className="space-y-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0">
              <div className="space-y-1">
                <CardTitle>Energy Consumption</CardTitle>
                <CardDescription>Daily energy usage in kWh</CardDescription>
              </div>
              <div className="flex items-center space-x-2">
                <Badge variant="outline">Last 7 days</Badge>
                <Button variant="outline" size="sm">
                  <Download className="mr-2 h-4 w-4" />
                  Export
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <EnergyConsumptionChart craneId={selectedCrane} />
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="efficiency" className="space-y-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0">
              <div className="space-y-1">
                <CardTitle>Fuel Efficiency</CardTitle>
                <CardDescription>Fuel consumption per operating hour</CardDescription>
              </div>
              <Badge variant="outline">Last 30 days</Badge>
            </CardHeader>
            <CardContent>
              <FuelEfficiencyChart craneId={selectedCrane} />
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="optimization" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-3">
            <Card className="md:col-span-1">
              <CardHeader>
                <CardTitle>Optimization Score</CardTitle>
                <CardDescription>Overall energy efficiency rating</CardDescription>
              </CardHeader>
              <CardContent className="flex justify-center">
                <EnergyOptimizationScore score={energyData?.optimization_score || 87} />
              </CardContent>
            </Card>
            <Card className="md:col-span-2">
              <CardHeader>
                <CardTitle>Optimization Recommendations</CardTitle>
                <CardDescription>Suggestions to improve energy efficiency</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-start space-x-3 rounded-md border p-3">
                    <Lightbulb className="mt-0.5 h-5 w-5 text-yellow-500" />
                    <div className="space-y-1">
                      <p className="text-sm font-medium">Implement regenerative braking</p>
                      <p className="text-xs text-muted-foreground">
                        Recover energy during lowering operations to reduce power consumption by up to 20%.
                      </p>
                      <div className="pt-1">
                        <Badge variant="outline" className="text-xs">
                          Potential Savings: 15-20%
                        </Badge>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3 rounded-md border p-3">
                    <Lightbulb className="mt-0.5 h-5 w-5 text-yellow-500" />
                    <div className="space-y-1">
                      <p className="text-sm font-medium">Optimize idle shutdown timing</p>
                      <p className="text-xs text-muted-foreground">
                        Reduce idle time by automatically shutting down systems after 5 minutes of inactivity.
                      </p>
                      <div className="pt-1">
                        <Badge variant="outline" className="text-xs">
                          Potential Savings: 8-12%
                        </Badge>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3 rounded-md border p-3">
                    <Lightbulb className="mt-0.5 h-5 w-5 text-yellow-500" />
                    <div className="space-y-1">
                      <p className="text-sm font-medium">Implement load-dependent power management</p>
                      <p className="text-xs text-muted-foreground">
                        Adjust power output based on actual load weight to prevent energy waste.
                      </p>
                      <div className="pt-1">
                        <Badge variant="outline" className="text-xs">
                          Potential Savings: 10-15%
                        </Badge>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        <TabsContent value="comparison" className="space-y-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0">
              <div className="space-y-1">
                <CardTitle>Energy Comparison</CardTitle>
                <CardDescription>Compare energy usage with similar cranes</CardDescription>
              </div>
              <Badge variant="outline">Last Quarter</Badge>
            </CardHeader>
            <CardContent>
              <EnergyComparisonChart craneId={selectedCrane} />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <Alert>
        <Battery className="h-4 w-4" />
        <AlertTitle>Energy Saving Opportunity</AlertTitle>
        <AlertDescription>
          Based on your current usage patterns, implementing the recommended optimizations could reduce your energy
          consumption by up to 25% and save approximately $12,500 annually.
        </AlertDescription>
      </Alert>
    </div>
  )
}

