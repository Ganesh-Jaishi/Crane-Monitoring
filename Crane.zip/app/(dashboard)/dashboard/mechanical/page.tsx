"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { getSupabaseClient } from "@/lib/supabase/client"
import { AlertCircle, Download } from "lucide-react"
import { CraneSelector } from "@/components/dashboard/crane-selector"
import { LoadWeightChart } from "@/components/dashboard/load-weight-chart"
import { PositionTracker } from "@/components/dashboard/position-tracker"
import { TemperatureChart } from "@/components/dashboard/temperature-chart"
import { VibrationChart } from "@/components/dashboard/vibration-chart"

export default function MechanicalPage() {
  const [selectedCrane, setSelectedCrane] = useState<string | null>(null)
  const [cranes, setCranes] = useState<any[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [mechanicalData, setMechanicalData] = useState<any>(null)

  useEffect(() => {
    const fetchCranes = async () => {
      const supabase = getSupabaseClient()
      const { data, error } = await supabase.from("cranes").select("*")

      if (error) {
        console.error("Error fetching cranes:", error)
        return
      }

      setCranes(data || [])
      if (data && data.length > 0) {
        setSelectedCrane(data[0].id)
      }
      setIsLoading(false)
    }

    fetchCranes()
  }, [])

  useEffect(() => {
    if (!selectedCrane) return

    const fetchMechanicalData = async () => {
      const supabase = getSupabaseClient()
      const { data, error } = await supabase
        .from("mechanical_parameters")
        .select("*")
        .eq("crane_id", selectedCrane)
        .order("timestamp", { ascending: false })
        .limit(1)

      if (error) {
        console.error("Error fetching mechanical data:", error)
        return
      }

      if (data && data.length > 0) {
        setMechanicalData(data[0])
      }
    }

    fetchMechanicalData()

    // Set up real-time subscription for mechanical data
    const supabase = getSupabaseClient()
    const subscription = supabase
      .channel("mechanical-changes")
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "mechanical_parameters",
          filter: `crane_id=eq.${selectedCrane}`,
        },
        (payload) => {
          setMechanicalData(payload.new)
        },
      )
      .subscribe()

    return () => {
      supabase.removeChannel(subscription)
    }
  }, [selectedCrane])

  const handleCraneChange = (craneId: string) => {
    setSelectedCrane(craneId)
  }

  if (isLoading) {
    return (
      <div className="flex h-full items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent" />
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-4 md:flex-row md:items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Mechanical Parameters</h1>
          <p className="text-muted-foreground">Monitor load weight, position, speed, temperature and vibration</p>
        </div>
        <CraneSelector cranes={cranes} selectedCrane={selectedCrane} onChange={handleCraneChange} />
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Load Weight</CardTitle>
            <svg
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
              className="h-4 w-4 text-muted-foreground"
            >
              <path d="M12 2v20M17 5H7M17 19H7" />
            </svg>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {mechanicalData?.load_weight ? `${mechanicalData.load_weight} kg` : "N/A"}
            </div>
            <p className="text-xs text-muted-foreground">Max capacity: 5000 kg</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Hook Height</CardTitle>
            <svg
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
              className="h-4 w-4 text-muted-foreground"
            >
              <path d="M12 2v20M17 5H7M17 19H7" />
            </svg>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {mechanicalData?.hook_height ? `${mechanicalData.hook_height} m` : "N/A"}
            </div>
            <p className="text-xs text-muted-foreground">Max height: 15 m</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Hoisting Speed</CardTitle>
            <svg
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
              className="h-4 w-4 text-muted-foreground"
            >
              <path d="M12 2v20M17 5H7M17 19H7" />
            </svg>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {mechanicalData?.hoisting_speed ? `${mechanicalData.hoisting_speed} m/s` : "N/A"}
            </div>
            <p className="text-xs text-muted-foreground">Max speed: 0.5 m/s</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Motor Temperature</CardTitle>
            <svg
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
              className="h-4 w-4 text-muted-foreground"
            >
              <path d="M12 2v20M17 5H7M17 19H7" />
            </svg>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {mechanicalData?.motor_temperature ? `${mechanicalData.motor_temperature}°C` : "N/A"}
            </div>
            <p className="text-xs text-muted-foreground">Warning threshold: 75°C</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0">
            <div className="space-y-1">
              <CardTitle>Load Weight History</CardTitle>
              <CardDescription>Load weight over time</CardDescription>
            </div>
            <Button variant="outline" size="sm">
              <Download className="mr-2 h-4 w-4" />
              Export
            </Button>
          </CardHeader>
          <CardContent>
            <LoadWeightChart craneId={selectedCrane} />
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0">
            <div className="space-y-1">
              <CardTitle>Hook Position</CardTitle>
              <CardDescription>Current X/Y position of the hook</CardDescription>
            </div>
            <Badge variant="outline">Real-time</Badge>
          </CardHeader>
          <CardContent>
            <PositionTracker x={mechanicalData?.hook_x_position || 0} y={mechanicalData?.hook_y_position || 0} />
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0">
            <div className="space-y-1">
              <CardTitle>Temperature Monitoring</CardTitle>
              <CardDescription>Motor and gearbox temperatures</CardDescription>
            </div>
            <Badge variant="outline">Last 24 hours</Badge>
          </CardHeader>
          <CardContent>
            <TemperatureChart craneId={selectedCrane} />
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0">
            <div className="space-y-1">
              <CardTitle>Vibration Analysis</CardTitle>
              <CardDescription>Vibration levels over time</CardDescription>
            </div>
            <Badge variant="outline">Last 24 hours</Badge>
          </CardHeader>
          <CardContent>
            <VibrationChart craneId={selectedCrane} />
          </CardContent>
        </Card>
      </div>

      <Alert>
        <AlertCircle className="h-4 w-4" />
        <AlertTitle>Maintenance Recommendation</AlertTitle>
        <AlertDescription>
          Increased vibration levels detected in the main hoist motor. Consider scheduling an inspection within the next
          2 weeks.
        </AlertDescription>
      </Alert>
    </div>
  )
}

